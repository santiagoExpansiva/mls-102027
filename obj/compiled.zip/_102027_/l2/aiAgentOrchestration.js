/// <mls fileReference="_102027_/l2/aiAgentOrchestration.ts" enhancement="_blank"/>
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { getNextPendentStep, getNextClarificationStep, getStepById, getInteractionStepId, findPreviousAgentStep, notifyTaskChange, notifyThreadChange, getRootAgent } from "/_102027_/l2/aiAgentHelper.js";
import * as storage from '/_102036_/l2/collabMessagesIndexedDB.js';
const agentName = 'aiAgentOrchestration';
// ── executeBeforePrompt (streaming version) ──────────────────────
export async function* executeBeforePromptStream(agent, context) {
    if (agent.beforePrompt) {
        await agent.beforePrompt(context);
        yield { type: 'done' };
        return;
    }
    const asyncAgent = agent;
    let content = context.message.content;
    if (content.startsWith("@@"))
        content = content.split(" ").slice(1).join(" ").trim();
    if (mls.isTraceAgent)
        console.log(`[executeBeforePromptStream] content:"${content}"`);
    let intents;
    if (asyncAgent.beforePromptAtomic) {
        const { jsonText, rest } = splitJsonAndText(content);
        const file = mls.stor.getFileStorFromJson(jsonText, {});
        if (mls.isTraceAgent)
            console.log(`[executeBeforePromptStream] isAtomic=${file ? "yes:" + JSON.stringify(file) : "no"}, userPromptAfterJson:${rest}`);
        if (file) {
            intents = await asyncAgent.beforePromptAtomic(asyncAgent, context, file, rest);
        }
    }
    if (!intents && asyncAgent.beforePromptImplicit) {
        if (mls.isTraceAgent)
            console.log(`[executeBeforePromptStream] implicit`);
        intents = await asyncAgent.beforePromptImplicit(asyncAgent, context, content);
    }
    if (!intents)
        throw new Error(`Invalid agent ${asyncAgent.agentName}, no beforePrompt`);
    yield* processIntentsStream(asyncAgent, context, intents);
}
/**
 * Backward-compatible wrapper: consome o generator inteiro e retorna void.
 * Quem não precisa de streaming continua usando essa.
 */
export async function executeBeforePrompt(agent, context) {
    for await (const _event of executeBeforePromptStream(agent, context)) {
        // consume all events silently
    }
}
// ── splitJsonAndText ─────────────────────────────────────────────
function splitJsonAndText(input) {
    const start = input.indexOf("{");
    const end = input.indexOf("}");
    if (start === -1 || end === -1 || end < start)
        return { jsonText: input, rest: "" };
    const jsonText = input.slice(start, end + 1).trim();
    const rest = input.slice(end + 1).trim();
    return { jsonText, rest };
}
// ── State ────────────────────────────────────────────────────────
const taskControllers = new Map();
const MAX_HOOKS_PER_TURN = 5;
const runningTasks = new Set();
// ── processIntents (streaming) ───────────────────────────────────
async function* processIntentsStream(agent, context, intents) {
    if (mls.isTraceAgent)
        console.log(`[processIntentsStream] intents length: ${intents.length}`);
    const messageId = context.message.createAt;
    if (!messageId)
        return;
    taskControllers.get(messageId)?.abort();
    const controller = new AbortController();
    taskControllers.set(messageId, controller);
    const signal = controller.signal;
    try {
        yield* _processIntentsStream(agent, context, intents, signal);
    }
    finally {
        if (taskControllers.get(messageId) === controller) {
            taskControllers.delete(messageId);
        }
    }
}
async function* _processIntentsStream(agent, context, intents, signal) {
    if (signal.aborted)
        return;
    const oldContextCreateAt = context.message.createAt;
    const isAddMessageAI = intents.some(i => i.type === 'add-message-ai');
    const value = await msgApplyIntents({
        userId: context.message.senderId,
        intents
    });
    if (!value)
        throw new Error(`[${agentName}] Error on msgApplyIntents`);
    if (value.statusCode !== 200)
        throw new Error(`[${agentName}] Error: ${value.msg || ''}`);
    if (signal.aborted)
        return;
    const ret = value;
    context.task = ret.task;
    if (ret.message)
        context.message = ret.message;
    // Persist before notifying: listeners react to 'task-change' synchronously
    // and resolve via storage.getTask (e.g. getAgentContext). Notifying before
    // the store is updated makes them read a stale task — which left the second
    // clarification stuck on "Processing..." until a manual task click.
    await storage.addOrUpdateTask(ret.task);
    notifyTaskChange(context, isAddMessageAI ? oldContextCreateAt : undefined);
    // ★ Yield: task criada / intents aplicados
    yield {
        type: 'task-created',
        taskId: ret.task.PK,
        task: ret.task,
        message: ret.message
    };
    yield {
        type: 'intents-applied',
        task: ret.task,
        message: context.message
    };
    if (!context.task?.iaCompressed) {
        yield { type: 'done' };
        return;
    }
    runningTasks.add(ret.task.PK);
    await storage.addPooling({
        taskId: ret.task.PK,
        userId: context.task?.owner ?? '',
        startAt: Date.now().toString()
    });
    yield { type: 'pooling-start', taskId: ret.task.PK };
    if (signal.aborted)
        return;
    let _hooks = context.task.iaCompressed.queueFrontEnd || [];
    const hooksToProcess = selectHooksToProcess(_hooks.filter(h => h.type !== 'pooling'));
    let newIntents = [];
    for (const hook of hooksToProcess) {
        // ★ Yield: hook iniciando
        yield { type: 'hook-start', hookType: hook.type, stepId: hook.stepId };
        const resolved = await resolveHookAgent(agent, context, hook);
        if (!resolved.agent) {
            const error = `[${agentName}](startNewAiTask) ${resolved.error || 'Invalid agent in hook step'}`;
            const combined = getHookFailureIntents(context, hook, error);
            yield { type: 'error', error, stepId: hook.stepId };
            yield { type: 'hook-done', hookType: hook.type, intents: combined };
            newIntents.push(...combined);
            continue;
        }
        agent = resolved.agent;
        const hookIntents = await processIntents2(resolved.agent, context, hook);
        const removeIntents = getRemoveIntent(context, hook);
        const combined = [...hookIntents, ...removeIntents];
        // ★ Yield: hook finalizado
        yield { type: 'hook-done', hookType: hook.type, intents: combined };
        newIntents.push(...combined);
    }
    await storage.addOrUpdateTask(context.task);
    if (signal.aborted)
        return;
    if (newIntents.length < 1) {
        newIntents = await processHookPooling(context);
        if (newIntents.length < 1) {
            runningTasks.delete(ret.task.PK);
            await storage.deletePooling(ret.task.PK);
            yield { type: 'pooling-end', taskId: ret.task.PK };
            yield { type: 'done' };
            return;
        }
    }
    // ★ Yield: ciclo concluído, informando quantos intents restam
    yield { type: 'cycle-done', remaining: newIntents.length };
    // Reentrada recursiva — continua emitindo eventos
    yield* _processIntentsStream(agent, context, newIntents, signal);
}
function selectHooksToProcess(hooks) {
    const selected = [];
    for (const hook of hooks) {
        selected.push(hook);
        // beforePromptStep commonly returns prompt_ready with a full LLM prompt.
        // Sending several large prompts in one applyIntents request can exceed
        // the backend request limit; later recursive cycles will process the rest.
        if (hook.type === 'beforePromptStep')
            break;
        if (selected.length >= MAX_HOOKS_PER_TURN)
            break;
    }
    return selected;
}
// ── processIntents (fire-and-forget, para uso interno) ───────────
async function processIntents(agent, context, intents) {
    for await (const _event of processIntentsStream(agent, context, intents)) {
        // consume silently — fire and forget behavior
    }
}
// ── _processIntents (legacy, para chamadas internas que não precisam stream) ─
async function _processIntents(agent, context, intents, signal) {
    for await (const _event of _processIntentsStream(agent, context, intents, signal)) {
        // consume silently
    }
}
async function resolveHookAgent(currentAgent, context, hook) {
    if (!context.task)
        return { error: 'Task not found while resolving hook agent' };
    const hookStep = getStepById(context.task, hook.stepId);
    if (!hookStep)
        return { error: `Step not found for hook stepId:${hook.stepId}` };
    if (hookStep.type !== 'agent')
        return { agent: currentAgent };
    const hookAgentName = hookStep.agentName;
    if (!hookAgentName)
        return { error: `Agent name not found for hook stepId:${hook.stepId}` };
    if (currentAgent.agentName === hookAgentName)
        return { agent: currentAgent };
    const hookAgent = await loadAgent(hookAgentName);
    if (!hookAgent)
        return { error: `Agent not found:${hookAgentName}` };
    return { agent: hookAgent };
}
function getHookFailureIntents(context, hook, error, removeHook = true) {
    console.error(error);
    if (!context.task)
        return [];
    const parentStepId = hook.parentStepId;
    const step = getStepById(context.task, hook.stepId);
    const parentStep = typeof parentStepId === 'number'
        ? getStepById(context.task, parentStepId)
        : null;
    const removeIntents = removeHook ? getRemoveIntent(context, hook) : [];
    if (!step || !parentStep)
        return removeIntents;
    const updateStatusFailed = {
        type: 'update-status',
        hookSequential: hook.hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status: 'failed',
        traceMsg: error,
    };
    return [updateStatusFailed, ...removeIntents];
}
// ── processIntents2 ─────────────────────────────────────────────
async function processIntents2(agent, context, hook) {
    try {
        if (mls.isTraceAgent)
            console.log(`[aiAgentOrchestration processIntents2] hook type:"${hook.type}"`, hook);
        if (hook.type === "beforePromptStep")
            return await processHookBeforePromptStep(agent, context, hook);
        if (hook.type === "afterPromptStep")
            return await processHookAfterPromptStep(agent, context, hook);
        if (hook.type === "beforeTool")
            return await processHookBeforeTool(agent, context, hook);
        throw new Error(`not implemented processIntents process hooks, type:${hook.type}`);
    }
    catch (e) {
        const error = `error processing taskid:${context.task?.PK}, hook:${hook.type}, message:${e.message || e}`;
        console.error(error);
        return getHookFailureIntents(context, hook, error, false);
    }
}
function getRemoveIntent(context, hook) {
    return [{
            type: 'remove-hook',
            hookSequential: hook.hookSequential,
            threadId: context.message.threadId,
            messageId: context.message.orderAt,
            taskId: context.task?.PK || ''
        }];
}
// ── Hook processors (sem mudanças) ──────────────────────────────
async function processHookBeforePromptStep(agent, context, hook) {
    if (!agent.beforePromptStep)
        throw new Error(`Agent ${agent.agentName} do not have beforePromptStep`);
    if (!context.task)
        throw new Error('[processHookBeforePromptStep] invalid task');
    const step = getStepById(context.task, hook.stepId);
    const parentStep = getStepById(context.task, hook.parentStepId);
    if (!step || !parentStep)
        throw new Error('[processHookBeforePromptStep] invalid stepId or parentStepId');
    const rc = await agent.beforePromptStep(agent, context, parentStep, step, hook.hookSequential, hook.args);
    return rc;
}
async function processHookAfterPromptStep(agent, context, hook) {
    if (!agent.afterPromptStep)
        throw new Error(`Agent ${agent.agentName} do not have afterPromptStep`);
    if (!context.task)
        throw new Error('[processHookAfterPromptStep] invalid task');
    const step = getStepById(context.task, hook.stepId);
    const parentStep = getStepById(context.task, hook.parentStepId);
    return await agent.afterPromptStep(agent, context, parentStep, step, hook.hookSequential);
}
async function processHookBeforeTool(agent, context, hook) {
    let intents = [];
    if (!context.task)
        throw new Error('[processHookBeforeTool] invalid task');
    const step = getStepById(context.task, hook.stepId);
    const parentStep = getStepById(context.task, hook.parentStepId);
    if (!step || !parentStep)
        throw new Error('[processHookBeforeTool] invalid stepId or parentStepId');
    const rc = await executeTool(step.toolName, step.args);
    if (typeof rc.result !== "string")
        throw new Error(`Tool ${step.toolName} did not return a string`);
    const existResults = rc.result.length > 0;
    if (existResults) {
        const stepInteraction = getStepById(context.task, parentStep.stepId);
        if (!stepInteraction || stepInteraction.type !== 'agent')
            throw new Error('Interaction must be type: agent');
        const oldPrompt = stepInteraction.interaction?.input.find((item) => item.type === 'human');
        const newStep = {
            type: "add-step",
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: parentStep.stepId,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: stepInteraction.agentName,
                prompt: `${oldPrompt?.content} \n\n Response from tool ${step.toolName}: ${rc.result} `,
                rags: null,
            }
        };
        intents.push(newStep);
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential: 0,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status: 'completed'
    };
    return [...intents, updateStatus];
}
async function processHookPooling(context) {
    const hook = (context.task?.iaCompressed?.queueFrontEnd.find(f => f.type === 'pooling'));
    let inClarification = false;
    if (context.task) {
        const step = getNextPendentStep(context.task);
        inClarification = (!!step && step.type === "clarification") || !!getNextClarificationStep(context.task);
        if (inClarification) {
            const threadId = context.message.threadId;
            const taskId = context.task.PK;
            const thread = await storage.updateThreadPendingTasks(threadId, taskId);
            notifyThreadChange(thread);
        }
    }
    if (!hook || !hook.afterMs || hook.afterMs < 1000 || context.task?.status === 'paused' || inClarification)
        return [];
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(getRemoveIntent(context, hook));
        }, hook.afterMs);
    });
}
// ── continuePoolingTask ─────────────────────────────────────────
export async function continuePoolingTask(context) {
    const { task } = context;
    if (!task)
        return;
    const taskId = task.PK;
    if (runningTasks.has(taskId)) {
        console.warn('Task already in pooling');
        return;
    }
    if (task.status !== 'in progress') {
        storage.deletePooling(taskId);
        return;
    }
    const ia = task.iaCompressed;
    if (!ia)
        throw new Error('Task has no AI interaction');
    if (!ia.queueFrontEnd)
        throw new Error('Task has no pending hooks');
    const firstStep = ia.nextSteps?.[0];
    if (!firstStep)
        throw new Error('No next step available');
    const agentNameLocal = firstStep.agentName;
    const agent = await loadAgent(agentNameLocal);
    if (!agent)
        throw new Error(`[${agentNameLocal}] createAgent function not found`);
    runningTasks.add(taskId);
    await storage.addPooling({
        taskId,
        userId: context.task?.owner ?? '',
        startAt: Date.now().toString()
    });
    const hooksToProcess = ia.queueFrontEnd
        .filter(h => h.type !== 'pooling')
        .slice(0, MAX_HOOKS_PER_TURN);
    const intentsFromHooks = (await Promise.all(hooksToProcess.map(async (hook) => {
        const resolved = await resolveHookAgent(agent, context, hook);
        if (!resolved.agent) {
            const error = `[${agentName}](continuePoolingTask) ${resolved.error || 'Invalid agent in hook step'}`;
            return getHookFailureIntents(context, hook, error);
        }
        return [
            ...(await processIntents2(resolved.agent, context, hook)),
            ...getRemoveIntent(context, hook),
        ];
    }))).flat();
    await storage.addOrUpdateTask(task);
    let intents = intentsFromHooks;
    if (intents.length === 0) {
        intents = await processHookPooling(context);
        if (intents.length === 0) {
            runningTasks.delete(taskId);
            await storage.deletePooling(taskId);
            return;
        }
    }
    void processIntents(agent, context, intents);
}
// ── pauseOrContinueTask ─────────────────────────────────────────
export async function pauseOrContinueTask(reason, context, action) {
    const task = context.task;
    if (!task)
        throw new Error(`(pauseOrContinueTask) task not found`);
    const ia = task.iaCompressed;
    if (!ia)
        throw new Error('(pauseOrContinueTask) Task has no AI interaction');
    if (['todo', 'done'].includes(task.status))
        throw new Error(`(pauseOrContinueTask) cannot change task with status "${task.status}". Only tasks in "paused" or "continued" state can be modified.`);
    if (task.status === 'paused' && action === 'paused')
        throw new Error(`(pauseOrContinueTask) task already paused`);
    const intentPauseOrContinue = {
        type: 'pause-or-continue',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        reason,
    };
    const intents = [intentPauseOrContinue];
    const agentRoot = getRootAgent(task);
    if (!agentRoot)
        throw new Error('(pauseOrContinueTask) Task has no AI agentRoot');
    const agent = await loadAgent(agentRoot.agentName);
    if (!agent)
        throw new Error(`(pauseOrContinueTask) Agent not found`);
    processIntents(agent, context, intents);
}
// ── restartStep ─────────────────────────────────────────────────
export async function restartStep(context, stepId, cleaner) {
    const task = context.task;
    if (!task)
        throw new Error('(restartStep) task not found');
    const step = getStepById(task, stepId);
    if (!step)
        throw new Error(`(restartStep) step not found: ${stepId}`);
    if (step.status !== 'failed')
        throw new Error('(restartStep) only failed steps can be restarted');
    const parentStep = findPreviousAgentStep(task, stepId);
    if (!parentStep)
        throw new Error(`(restartStep) parent step not found for step ${stepId}`);
    // parallel_dynamic children are created without `planning` (they are driven by the parent's
    // progress/args queue). They are still restartable — re-run with their own args (step.prompt).
    const isParallelChild = !!parentStep.progress;
    if (!step.planning && !isParallelChild)
        throw new Error('(restartStep) step has no planning');
    const parentStepId = parentStep.stepId;
    const intent = {
        type: 'update-status',
        hookSequential: 0,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: task.PK,
        parentStepId,
        stepId,
        status: 'waiting_dependency',
        cleaner,
    };
    const agentRoot = getRootAgent(task);
    if (!agentRoot)
        throw new Error('(restartStep) Task has no AI agentRoot');
    const agent = await loadAgent(agentRoot.agentName);
    if (!agent)
        throw new Error('(restartStep) Agent not found');
    processIntents(agent, context, [intent]);
}
// ── Tools ────────────────────────────────────────────────────────
export async function executeTool(toolName, args) {
    const rc = {
        status: false,
        error: "",
        result: []
    };
    if (!toolName) {
        rc.error = "Tool name is missing";
        return rc;
    }
    ;
    try {
        const tool = await loadTool(toolName);
        if (!args) {
            mls.common.argsValidator({}, tool.argsSchema);
            rc.result = await tool.execute();
        }
        else {
            const parsedArgs = mls.common.safeParseArgs(args);
            mls.common.argsValidator(parsedArgs, tool.argsSchema);
            rc.result = await tool.execute(parsedArgs);
        }
        rc.status = true;
    }
    catch (error) {
        console.error(`[executeTool] ${error.message || error} `);
        rc.error = error.message || error;
    }
    return rc;
}
// ── Clarification ────────────────────────────────────────────────
export async function finishClarification(agent, stepId, parentStepId, intents, context, value, action) {
    if (context.task) {
        const thread = await storage.updateThreadPendingTasks(context.message.threadId, context.task.PK);
        notifyThreadChange(thread);
    }
    if (action === 'cancel') {
        const updateStatusFailed = {
            type: 'update-status',
            hookSequential: 0,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId,
            stepId,
            status: 'failed'
        };
        const intentsFailed = [updateStatusFailed];
        return processIntents(agent, context, intentsFailed);
    }
    if (action === 'continue') {
        const intentAddStep = intents.find((step) => step.type === 'add-step');
        if (!intentAddStep)
            return;
        const agentStep = intentAddStep.step;
        if (agentStep.prompt) {
            const prompt = agentStep.prompt;
            agentStep.prompt = (prompt || '').replace('{{clarification}}', value);
        }
        const newAgent = await loadAgent(agentStep.agentName);
        if (!newAgent)
            throw new Error(`(pauseOrContinueTask) Agent not found`);
        await processIntents(newAgent, context, intents);
    }
}
// NOTE: clarification UI is rendered by the production frontend (mls-102025),
// not by the orchestration. The widget (widget-questions-for-clarification-102025)
// lives in mls-102025 so this shared library does not depend on Studio (mls-100554).
// Agents build the widget locally and wire it to `finishClarification`.
export async function getClarificationElement(context) {
    const task = context.task;
    if (!task)
        throw new Error('Task not find');
    const taskId = task.PK;
    if (task.status !== 'in progress')
        throw new Error('Task not in progress');
    const ia = task.iaCompressed;
    if (!ia)
        throw new Error('Task has no AI interaction');
    if (!ia.queueFrontEnd)
        throw new Error('Task has no pending hooks');
    const ret = await getAgentContext(taskId);
    if (ret.step.type !== "clarification")
        throw new Error(`[${agentName}](getClarificationElement) Clarification step not not found`);
    const agent = await loadAgent(ret.interaction.agentName);
    if (!agent)
        throw new Error(`[${agentName}](getClarificationElement) function not found`);
    const fn = agent.beforeClarificationStep;
    if (typeof fn !== "function")
        throw new Error(`[${agentName}](getClarificationElement) 'beforeClarificationStep' function not found in ${agentName} `);
    const parentId = getInteractionStepId(task, ret.step.stepId);
    if (!parentId)
        throw new Error(`[${agentName}](getClarificationElement) parentId not found`);
    const parentStep = getStepById(task, parentId);
    if (!parentStep)
        throw new Error(`[${agentName}](getClarificationElement) parentStep not found`);
    return fn(agent, context, parentStep, ret.step, 0, ret.step.json);
}
// ── Helpers ──────────────────────────────────────────────────────
export async function getAgentContext(taskId) {
    const task = await storage.getTask(taskId);
    if (!task || !task.messageid_created)
        throw new Error(`[${agentName}](getAgentContext) Invalid taskId ${taskId}`);
    let step = getNextPendentStep(task);
    if (!step || (step.type !== "clarification" && step.type !== "tool")) {
        const clarStep = getNextClarificationStep(task);
        if (clarStep)
            step = clarStep;
        else if (!step)
            throw new Error("[getAgentContext] No pending step");
        else
            throw new Error("[getAgentContext] No pending clarification or tool step");
    }
    const interactionId = getInteractionStepId(task, step.stepId);
    if (!interactionId)
        throw new Error("[getAgentContext] Not found interactionId in pending step");
    const interaction = getStepById(task, interactionId);
    if (!interaction || interaction.type !== "agent")
        throw new Error("[getAgentContext] Clarification or tool step not bellow a agent");
    const messageId = task.messageid_created;
    const message = await storage.getMessage(messageId);
    if (!message)
        throw new Error(`[${agentName}](getAgentContext) Message not found: ${messageId}`);
    const context = {
        message,
        task,
        isTest: task.iaCompressed?.isTest || false
    };
    return { context, interaction, step };
}
export async function loadAgent(agentName) {
    try {
        const agent = await getInstanceByName(agentName, 'agent');
        return agent;
    }
    catch (error) {
        console.error(`[loadAgent] ${error.message || error} `);
        return undefined;
    }
}
export async function loadTool(toolName) {
    try {
        const tool = await getInstanceByName(toolName, 'tool');
        return tool;
    }
    catch (error) {
        console.error(`[loadTool] ${error.message || error} `);
        return undefined;
    }
}
const FACTORY_MAP = {
    agent: 'createAgent',
    tool: 'createTool'
};
/**
 * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
 */
export async function getInstanceByName(nameOrPath, mode) {
    const projectActual = mls.actualProject;
    if (!projectActual)
        throw new Error('Not found project actual!');
    const fileInfo = mls.stor.getPathToFile(nameOrPath);
    const projectsToSearch = fileInfo.project > 0
        ? [fileInfo.project]
        : mls.l5.getProjectDependencies(projectActual, true);
    function searchInProject(projectId) {
        let foundInFolder;
        for (const file of Object.values(mls.stor.files)) {
            if (file.project !== projectId ||
                file.extension !== ".ts" ||
                file.shortName !== fileInfo.shortName)
                continue;
            if (mode === 'agent' && !file.shortName.startsWith('agent'))
                continue;
            if (mode === 'tool' && !file.shortName.startsWith('tool'))
                continue;
            if (file.folder === '' || file.folder === fileInfo.folder) {
                return file;
            }
            foundInFolder = file;
        }
        return foundInFolder;
    }
    // Search only in the current project and its dependencies (no hardcoded
    // Studio base project). getProjectDependencies(projectActual, true) already
    // includes the current project plus all of its dependencies.
    for (const projId of projectsToSearch) {
        const file = searchInProject(projId);
        if (!file)
            continue;
        try {
            // Cache-bust only files under development (editing mode / project=0):
            // those must always fetch the latest. Published files use their stable
            // versionRef so the browser can cache them and only re-fetch when the
            // version actually changes.
            const cacheKey = file.inLocalStorage ? Date.now() : encodeURIComponent(file.versionRef);
            const module = await import(`/_${file.project}_/l2/${file.folder ? file.folder.trim() + '/' : ''}${file.shortName}?t=${cacheKey}`);
            const factoryName = FACTORY_MAP[mode];
            const factory = module[factoryName];
            if (typeof factory !== "function") {
                throw new Error(`[getInstanceByName] ${factoryName} not found in ${file.shortName}`);
            }
            return factory();
        }
        catch (error) {
            console.error(`[load${mode}] ${error.message || error}`);
            return undefined;
        }
    }
    return undefined;
}
