/// <mls fileReference="_102027_/l2/libStor.ts" enhancement="_blank"/>
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { createModel, createAllModels } from '/_102027_/l2/libModel.js';
import { getBaseTemplate, verifyNeedAddTripleslach, isStorContentEqualTemplateDefault } from '/_102027_/l2/libCommom.js';
export async function createStorFile(req, needCreateModel, needCompile = true, awaitCompile = false) {
    const params = {
        project: req.project,
        level: req.level,
        shortName: req.shortName,
        extension: req.extension,
        versionRef: '0',
        folder: req.folder,
        updatedAt: new Date().toISOString()
    };
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[createStorFile] Invalid storFile');
    file.status = req.status ?? 'new';
    let source = req.source;
    if (req.level === 2) {
        source = verifyNeedAddTripleslach(params, req.source, req.extension);
    }
    const fileInfo = {
        content: source,
        contentType: 'string'
    };
    if (req.fileInfo) {
        fileInfo.originalFolder = req.fileInfo.originalFolder;
        fileInfo.originalProject = req.fileInfo.originalProject;
        fileInfo.originalShortName = req.fileInfo.originalShortName;
    }
    await mls.stor.localStor.setContent(file, fileInfo);
    if (needCreateModel && ['.ts', '.html', '.defs.ts', '.test.ts'].includes(file.extension))
        await createModel(file, needCompile, awaitCompile);
    // file.getModel = async () => _getModel(file);
    return file;
}
export async function createAllFiles(req, needCreateModel = true, awaitCompile = false) {
    const { folder, shortName, project } = req;
    const template = await getBaseTemplate({ folder, shortName, project, extension: '.ts' }, req.enhancement);
    const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
    const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
    const templateTest = await getBaseTemplate({ folder, shortName, project, extension: '.test.ts' });
    const templateDefs = await getBaseTemplate({ folder, shortName, project, extension: '.defs.ts' });
    const newTSSource = req.tsSource || template;
    const newHTMLSource = req.htmlSource || templateHTML;
    const newLessSource = req.lessSource || templateLess;
    const newTestSource = req.testSource || templateTest;
    const newDefsSource = req.defsSource || templateDefs;
    const param = {
        project: req.project,
        shortName: req.shortName,
        folder: req.folder,
        level: req.level,
        extension: '.ts',
        source: newTSSource,
        status: 'new'
    };
    const ret = {
        ts: await safeCreate(param, false)
    };
    ret.html = await safeCreate({ ...param, extension: '.html', source: newHTMLSource }, false);
    ret.less = await safeCreate({ ...param, extension: '.less', source: newLessSource }, false);
    ret.test = await safeCreate({ ...param, extension: '.test.ts', source: newTestSource }, false);
    ret.def = await safeCreate({ ...param, extension: '.defs.ts', source: newDefsSource }, false);
    if (needCreateModel && ret.ts && !(ret.ts instanceof Error))
        await createAllModels(ret.ts, true, awaitCompile);
    return ret;
}
export async function deleteFile(storFile) {
    if (storFile.status === 'new') {
        await deleteFileSystem(storFile);
        return;
    }
    storFile.status = 'deleted';
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    if (storFile.getValueInfo) {
        let valueInfo = mls.editor.models[keyToModel] ? await storFile.getValueInfo() : {};
        if (!valueInfo.content) {
            const src = await storFile.getContent();
            valueInfo = {
                content: src,
                contentType: 'string',
                originalShortName: storFile.shortName,
                originalProject: storFile.project,
                originalCRC: mls.common.crc.crc32(src).toString(16)
            };
        }
        await mls.stor.localStor.setContent(storFile, valueInfo);
    }
}
export async function deleteAllFiles(storFile) {
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        await deleteFile(mls.stor.files[key]);
    }
}
export async function removeNewStorFilesWithTemplateDefault() {
    const removed = [];
    const project = mls.actualProject;
    if (!project)
        return removed;
    // snapshot: deleteFile remove entradas de mls.stor.files durante o loop
    const files = Object.values(mls.stor.files).filter((f) => f && f.project === project && f.status === 'new');
    for await (const storFile of files) {
        const isTemplate = await isStorContentEqualTemplateDefault(storFile);
        if (!isTemplate)
            continue;
        await deleteFile(storFile); // status 'new' -> remoção real (deleteFileSystem)
        removed.push(storFile);
    }
    return removed;
}
export async function renameFile(storFile, newProject, newShortName, newFolder, needCompile = true) {
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[renameFile] Impossible rename this file:' + storFile.shortName);
    //if (!newFolder) newFolder = storFile.folder;
    source = replaceTripleslashAndTag(storFile, newProject, newShortName, newFolder, source);
    const param = {
        shortName: newShortName,
        project: newProject,
        folder: newFolder,
        level: storFile.level,
        source: source,
        extension: storFile.extension,
        status: storFile.status === 'new' ? 'new' : 'renamed',
        fileInfo: {
            originalFolder: storFile.folder,
            originalProject: storFile.project,
            originalShortName: storFile.shortName
        }
    };
    const needCreateModels = param.level === 2;
    const file = await createStorFile(param, needCreateModels, needCompile);
    await deleteFileSystem(storFile);
    return file;
}
export async function renameAllFiles(storFile, newProject, newShortName, newFolder, needCompile = true) {
    const ret = {};
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts', '.json']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        const prop = mapExt[ext];
        ret[prop] = await safeRename(mls.stor.files[key], newProject, newShortName, newFolder, needCompile);
    }
    return ret;
}
export async function cloneFile(storFile, newProject, newShortName) {
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[cloneFile] Impossible rename this file:' + storFile.shortName);
    source = replaceTripleslashAndTag(storFile, newProject, newShortName, storFile.folder, source);
    const param = {
        shortName: newShortName,
        project: newProject,
        folder: storFile.folder,
        level: storFile.level,
        source: source,
        extension: storFile.extension,
        status: 'new'
    };
    const file = await createStorFile(param, true);
    return file;
}
export async function cloneAllFiles(storFile, newProject, newShortName) {
    const ret = {};
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        const prop = mapExt[ext];
        ret[prop] = await safeClone(mls.stor.files[key], newProject, newShortName);
    }
    return ret;
}
export async function undoFile(storFile, removeProject = true) {
    storFile.getValueInfo = undefined;
    if (storFile.status === 'nochange' && !storFile.inLocalStorage) {
        return;
    }
    if (storFile.status === 'new') {
        await deleteFileSystem(storFile);
        return;
    }
    if (storFile.status === 'deleted') {
        storFile.status = 'nochange';
    }
    if (storFile.status === 'renamed') {
        await undoFileRenamed(storFile);
        return;
    }
    if (storFile.status === 'changed') {
        storFile.status = 'nochange';
        storFile.inLocalStorage = false;
        storFile.hasError = false;
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        if (storFile.isLocalVersionOutdated && storFile.newVersionRefIfOutdated) {
            storFile.versionRef = storFile.newVersionRefIfOutdated;
            storFile.isLocalVersionOutdated = false;
            storFile.newVersionRefIfOutdated = undefined;
        }
    }
    if (storFile.inLocalStorage) {
        storFile.inLocalStorage = false;
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    }
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    if (!mls.editor.models[keyToModel])
        return;
    const prop = mapExtUndo[storFile.extension];
    if (prop && mls.editor.models[keyToModel]?.[prop]) {
        mls.editor.models[keyToModel][prop]?.model.dispose();
        delete mls.editor.models[keyToModel][prop];
    }
    if (removeProject && storFile)
        await mls.stor.localDB.removePrjInfo(storFile.project);
}
export async function undoAllFiles(storFile) {
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        await undoFile(mls.stor.files[key], false);
    }
    await mls.stor.localDB.removePrjInfo(storFile.project);
    createAllModels(storFile, true, false, false);
}
function isNewNameValid(newShortName) {
    if (newShortName.length === 0 || newShortName.length > 255)
        return false;
    const invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
    return (!invalidCharacters.test(newShortName));
}
//---------AUXILIARY FUNCTIONS AND DEFINITIONS-------------
const mapExt = {
    '.ts': 'ts',
    '.html': 'html',
    '.less': 'less',
    '.test.ts': 'test',
    '.defs.ts': 'def'
};
const mapExtUndo = {
    '.ts': 'ts',
    '.html': 'html',
    '.less': 'style',
    '.test.ts': 'test',
    '.defs.ts': 'defs'
};
export function replaceTripleslashAndTag(storFile, newProject, newShortName, newFolder, src) {
    const { folder, project, shortName, level, extension } = storFile;
    const oldTag = convertFileNameToTag({ folder, project, shortName });
    const newTag = convertFileNameToTag({ folder: newFolder, project: newProject, shortName: newShortName });
    const fileReference = `_${newProject}_/l${level}/${newFolder ? newFolder + '/' : ''}${newShortName}${extension}`;
    const regex = new RegExp(oldTag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    src = src.replace(/fileReference="[^"]*"/, `fileReference="${fileReference}"`).replace(/shortName="[^"]*"/, `shortName="${newShortName}"`).replace(/project="[^"]*"/, `project="${newProject}"`).replace(/folder="[^"]*"/, `folder="${newFolder}"`);
    return src.replace(regex, newTag);
}
async function deleteFileSystem(storFile) {
    //mls.editor.deleteModels(storFile.project, storFile.shortName, storFile.folder, true, storFile.level);
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    if (mls.editor.models[keyToModel]) {
        const prop = mapExtUndo[storFile.extension];
        if (prop && mls.editor.models[keyToModel]?.[prop]) {
            mls.editor.models[keyToModel][prop]?.model.dispose();
            delete mls.editor.models[keyToModel][prop];
        }
    }
    const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    delete mls.stor.files[keyFiles];
}
async function safeCreate(param, createMdl) {
    try {
        return await createStorFile(param, createMdl);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function safeRename(storFile, newProject, newShortName, newFolder, needCompile = true) {
    try {
        return await renameFile(storFile, newProject, newShortName, newFolder, needCompile);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function safeClone(storFile, newProject, newShortName) {
    try {
        return await cloneFile(storFile, newProject, newShortName);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function undoFileRenamed(storFile) {
    if (!storFile.getValueInfo && mls.stor.localDB.getContentInfoOrNull)
        storFile.getValueInfo = mls.stor.localDB.getContentInfoOrNull;
    const info = storFile.getValueInfo ? await storFile.getValueInfo() : {};
    if (!info.originalProject || !info.originalShortName)
        throw new Error('[undoFileRenamed] Not found info base for rename');
    const originalKey = mls.stor.getKeyToFiles(info.originalProject, storFile.level, info.originalShortName, info.originalFolder || storFile.folder, storFile.extension);
    const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
    if (!mls.stor.files[originalKey]) {
        const params = {
            project: info.originalProject,
            level: storFile.level,
            shortName: info.originalShortName,
            extension: storFile.extension,
            versionRef: '0',
            folder: info.originalFolder || storFile.folder
        };
        await mls.stor.addOrUpdateFile(params);
    }
    if (mls.stor.files[key]) {
        await mls.stor.localStor.setContent(mls.stor.files[key], { contentType: 'string', content: null });
        delete mls.stor.files[key];
    }
}
