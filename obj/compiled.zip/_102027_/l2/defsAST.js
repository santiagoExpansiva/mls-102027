/// <mls fileReference="_102027_/l2/defsAST.ts" enhancement="_blank"/>
// ============================================================
// PARSE  –  extrai as 3 variáveis da string do arquivo
// ============================================================
export function parseDefsFile(source) {
    return {
        asis: getAsis(source),
        history: getHistory(source),
        skill: getSkill(source),
    };
}
// ============================================================
// ASIS  –  já é JSON puro, só extrai e faz JSON.parse
// ============================================================
export function getAsis(source) {
    const raw = extractBlock(source, 'asis', '{', '}');
    return JSON.parse(raw);
}
export function updateAsis(source, patch) {
    const current = getAsis(source);
    const updated = deepMerge(current, patch);
    return replaceVar(source, 'asis', JSON.stringify(updated, null, 2), 'export const asis: mls.defs.AsIs =');
}
export function replaceAsis(source, value) {
    return replaceVar(source, 'asis', JSON.stringify(value, null, 2), 'export const asis: mls.defs.AsIs =');
}
// ============================================================
// HISTORY  –  estilo TS (single-quotes, keys sem aspas), normaliza antes do parse
// ============================================================
export function getHistory(source) {
    const raw = extractBlock(source, 'history', '[', ']');
    return JSON.parse(normalizeTs(raw));
}
export function addHistoryItem(source, item) {
    const current = getHistory(source);
    current.push(item);
    return replaceVar(source, 'history', historyToTs(current), 'export const history: mls.defs.ChangeHistoryItem[] =');
}
export function updateHistoryItem(source, version, patch) {
    const current = getHistory(source);
    const idx = current.findIndex(h => h.version === version);
    if (idx === -1)
        throw new Error(`History version ${version} not found.`);
    current[idx] = { ...current[idx], ...patch };
    return replaceVar(source, 'history', historyToTs(current), 'export const history: mls.defs.ChangeHistoryItem[] =');
}
export function replaceHistory(source, value) {
    return replaceVar(source, 'history', historyToTs(value), 'export const history: mls.defs.ChangeHistoryItem[] =');
}
// ============================================================
// SKILL  –  template literal, extrai conteúdo entre backticks
// ============================================================
export function getSkill(source) {
    const { content } = extractTemplateLiteral(source);
    return content;
}
export function updateSkill(source, value) {
    const decl = 'export const skill =';
    const newLiteral = '`' + value + '`';
    if (!/export\s+const\s+skill\s*=/.test(source)) {
        return source.trimEnd() + '\n\n' + decl + ' ' + newLiteral + '\n';
    }
    const { start, end } = extractTemplateLiteral(source);
    return source.slice(0, start) + newLiteral + source.slice(end);
}
function extractTemplateLiteral(source) {
    const match = /export\s+const\s+skill\s*=\s*`/.exec(source);
    if (!match)
        throw new Error('Variable "skill" not found in source.');
    const start = match.index + match[0].length - 1; // posição do backtick de abertura
    let i = start + 1;
    while (i < source.length) {
        if (source[i] === '\\') {
            i += 2;
            continue;
        } // escapes: \` ou qualquer outro
        if (source[i] === '`') {
            return {
                content: source.slice(start + 1, i),
                start,
                end: i + 1,
            };
        }
        i++;
    }
    throw new Error('Unterminated template literal for "skill".');
}
// ============================================================
// INTERNAL – substitui bloco da variável na string original
// ============================================================
function replaceVar(source, varName, newBlock, declaration) {
    const match = new RegExp(`export\\s+const\\s+${varName}[^=]*=\\s*`).exec(source);
    if (!match) {
        // variável não existe — cria no final do arquivo
        return source.trimEnd() + '\n\n' + declaration + '\n' + newBlock + '\n';
    }
    const start = match.index + match[0].length;
    const open = source[start];
    const close = open === '{' ? '}' : ']';
    const old = balancedSlice(source, start, open, close);
    return source.slice(0, start) + newBlock + source.slice(start + old.length);
}
// ============================================================
// INTERNAL – extrai bloco balanceado da variável
// ============================================================
function extractBlock(source, varName, open, close) {
    const match = new RegExp(`export\\s+const\\s+${varName}[^=]*=\\s*`).exec(source);
    if (!match)
        throw new Error(`Variable "${varName}" not found in source.`);
    const start = match.index + match[0].length;
    if (source[start] !== open)
        throw new Error(`Expected "${open}" at start of "${varName}".`);
    return balancedSlice(source, start, open, close);
}
function balancedSlice(source, start, open, close) {
    let depth = 0;
    let inStr = false;
    let strCh = '';
    for (let i = start; i < source.length; i++) {
        const ch = source[i];
        if (inStr) {
            if (ch === '\\') {
                i++;
                continue;
            }
            if (ch === strCh)
                inStr = false;
            continue;
        }
        if (ch === '"' || ch === "'") {
            inStr = true;
            strCh = ch;
            continue;
        }
        if (ch === open)
            depth++;
        if (ch === close) {
            if (--depth === 0)
                return source.slice(start, i + 1);
        }
    }
    throw new Error('Unbalanced block.');
}
// ============================================================
// INTERNAL – normaliza TS → JSON (só para history)
// ============================================================
function normalizeTs(raw) {
    return raw
        .replace(/,\s*([}\]])/g, '$1') // trailing commas
        .replace(/([{,]\s*)([A-Za-z_$][\w$]*)\s*:/g, '$1"$2":') // keys sem aspas
        .replace(/:\s*'([^']*)'/g, ': "$1"'); // single-quote values
}
// ============================================================
// INTERNAL – serializa history de volta em estilo TS
// ============================================================
function historyToTs(items) {
    const lines = items.map(item => {
        const entries = Object.entries(item)
            .map(([k, v]) => `    ${k}: ${typeof v === 'number' ? v : `'${v}'`}`)
            .join(',\n');
        return `  {\n${entries}\n  }`;
    });
    return `[\n${lines.join(',\n')}\n]`;
}
function deepMerge(target, source) {
    const result = { ...target };
    for (const key in source) {
        const val = source[key];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            result[key] = deepMerge(target[key] ?? {}, val);
        }
        else if (val !== undefined) {
            result[key] = val;
        }
    }
    return result;
}
