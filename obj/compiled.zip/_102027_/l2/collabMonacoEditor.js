/// <mls fileReference="_102027_/l2/collabMonacoEditor.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabMonacoEditor = class CollabMonacoEditor extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-monaco-editor-102027 {
  z-index: 3000;
  position: absolute;
}
collab-monaco-editor-102027:hover {
  z-index: 4000;
}
`);
        this.msize = '';
    }
    get isMls2() {
        return !!this.closest('collab-page');
    }
    render() { return nothing; }
    updated(changed) {
        super.updated(changed);
        if (changed.has('msize'))
            this._onMsizeChange(this.msize);
    }
    _onMsizeChange(msize) {
        const [width, height] = msize.split(',');
        if (!width || !height)
            return;
        if (this.mlsEditor && typeof this.mlsEditor.layout === 'function') {
            this.mlsEditor.layout({ width: +width, height: +height });
        }
    }
};
__decorate([
    property({ attribute: 'msize', hasChanged: () => true })
], CollabMonacoEditor.prototype, "msize", void 0);
CollabMonacoEditor = __decorate([
    customElement('collab-monaco-editor-102027')
], CollabMonacoEditor);
export { CollabMonacoEditor };
