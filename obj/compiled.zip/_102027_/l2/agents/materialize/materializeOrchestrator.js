/// <mls fileReference="_102027_/l2/agents/materialize/materializeOrchestrator.ts" enhancement="_blank"/>
import { getMaterializeIndex } from '/_102027_/l2/defsAST.js';
import { collabImport } from '/_102027_/l2/collabImport.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
import { createModelAnyFile } from '/_102027_/l2/libModel.js';
const cacheMaterializeOrchestrator = new Map();
const buildCache = new Map();
let esbuildReady = null;
export function getMaterializeOrchestrator(defPath) {
    if (!cacheMaterializeOrchestrator.has(defPath)) {
        const orchestrator = new MaterializeOrchestrator(defPath);
        orchestrator.onAllCompleted = () => {
            console.info('kill path:' + defPath);
            cacheMaterializeOrchestrator.delete(defPath);
            buildCache.delete(defPath);
        };
        cacheMaterializeOrchestrator.set(defPath, orchestrator);
    }
    return cacheMaterializeOrchestrator.get(defPath);
}
async function getEsbuild() {
    const url = 'https://cdn.jsdelivr.net/npm/esbuild-wasm@0.25.4/esm/browser.js';
    const esbuild = await import(url);
    if (!esbuildReady) {
        esbuildReady = esbuild.initialize({
            wasmURL: 'https://cdn.jsdelivr.net/npm/esbuild-wasm@0.25.4/esbuild.wasm',
        });
    }
    await esbuildReady;
    return esbuild;
}
export class MaterializeOrchestrator {
    constructor(jsonPath) {
        this.jsonPath = jsonPath;
        this.items = [];
        this.completedIds = new Set();
        this.onAllCompleted = null;
    }
    async loadItems() {
        const sfInfo = await mls.stor.convertFileReferenceToFile(this.jsonPath);
        if (!sfInfo)
            return;
        const key = mls.stor.getKeyToFile(sfInfo);
        const sf = mls.stor.files[key];
        if (!sf)
            return;
        const data = await sf.getContent();
        this.items = getMaterializeIndex(data);
    }
    isAllCompleted() {
        return (this.items.length > 0 &&
            this.items.every((item) => this.completedIds.has(item.id)));
    }
    async process(trigger) {
        if (!this.items.length)
            await this.loadItems();
        if (trigger === 'init') {
            return this.items.filter((item) => item.dependsOn.length === 0);
        }
        this.completedIds.add(trigger);
        if (this.isAllCompleted()) {
            this.onAllCompleted?.();
            return [];
        }
        return this.items.filter((item) => {
            if (!item.dependsOn.includes(trigger))
                return false;
            if (this.completedIds.has(item.id))
                return false;
            if (item.dependsOn.length === 0)
                return false;
            return item.dependsOn.every((dep) => this.completedIds.has(dep));
        });
    }
    getStatus() {
        return {
            total: this.items.length,
            completed: this.completedIds.size,
            pending: this.items.length - this.completedIds.size,
            completedIds: [...this.completedIds],
            pendingIds: this.items
                .filter((item) => !this.completedIds.has(item.id))
                .map((item) => item.id),
            isAllCompleted: this.isAllCompleted(),
        };
    }
    reset() {
        this.completedIds.clear();
    }
    async getSkill(path) {
        try {
            if (path.startsWith('/'))
                path = path.slice(1);
            const f = mls.stor.convertFileReferenceToFile(path);
            if (!f)
                return '';
            const module = await collabImport(f);
            if (!module) {
                console.info(`[getSkill]Módulo não registrado: ${path}`);
                return '';
            }
            let src = module.skill;
            return await this.processTemplate(src);
        }
        catch (err) {
            console.error(`Erro em ${path}`, err);
            return '';
        }
    }
    async processTemplate(input) {
        const regex = /\[\[\((.*?)\)(?:\.(.*?))?\]\]/g;
        let result = input;
        const matches = [...input.matchAll(regex)];
        for (const match of matches) {
            const fullMatch = match[0];
            const filePath = match[1];
            const expression = match[2];
            if (!expression) {
                const f = mls.stor.convertFileReferenceToFile(filePath);
                if (!f)
                    continue;
                const key = mls.stor.getKeyToFile(f);
                const sf = mls.stor.files[key];
                if (!sf)
                    continue;
                let replacement = await sf.getContent();
                result = result.replace(fullMatch, JSON.stringify(replacement));
            }
            else {
                const isFunction = expression.endsWith("()");
                const exportName = isFunction
                    ? expression.replace("()", "")
                    : expression;
                try {
                    const f = mls.stor.convertFileReferenceToFile(filePath);
                    if (!f)
                        continue;
                    const module = await collabImport(f);
                    if (!module) {
                        console.info(`Módulo não registrado: ${filePath}`);
                        continue;
                    }
                    let replacement;
                    if (isFunction) {
                        replacement = await module[exportName]();
                    }
                    else {
                        replacement = module[exportName];
                    }
                    if (typeof replacement === "object") {
                        result = result.replace(fullMatch, JSON.stringify(replacement));
                    }
                    else {
                        result = result.replace(fullMatch, String(replacement));
                    }
                }
                catch (err) {
                    console.error(`Erro em ${fullMatch}`, err);
                }
            }
        }
        return result;
    }
    async processGroup(trigger) {
        if (!this.items.length)
            await this.loadItems();
        if (trigger === 'init') {
            return this.groupByAgent(this.items.filter((item) => item.dependsOn.length === 0));
        }
        this.completedIds.add(trigger);
        if (this.isAllCompleted()) {
            this.onAllCompleted?.();
            return {};
        }
        return this.groupByAgent(this.items.filter((item) => {
            if (!item.dependsOn.includes(trigger))
                return false;
            if (this.completedIds.has(item.id))
                return false;
            if (item.dependsOn.length === 0)
                return false;
            return item.dependsOn.every((dep) => this.completedIds.has(dep));
        }));
    }
    groupByAgent(tasks) {
        return tasks.reduce((acc, task) => {
            if (!acc[task.agent])
                acc[task.agent] = [];
            acc[task.agent].push(task);
            return acc;
        }, {});
    }
    async getVarOld(path, variable) {
        try {
            const f = mls.stor.convertFileReferenceToFile(path);
            if (!f)
                return '';
            const module = await collabImport(f);
            if (!module) {
                console.info(`Módulo não registrado: ${path}`);
                return '';
            }
            if (!module[variable]) {
                console.info(`Variable não registrado: ${path}; ${variable}`);
                return '';
            }
            let result = module[variable];
            if (typeof result === 'object') {
                return JSON.stringify(result);
            }
            return await this.processTemplate(result);
        }
        catch (err) {
            console.error(`Erro em ${path}`, err);
            return '';
        }
    }
    async createStorFile(fileRef, src) {
        if (!fileRef.startsWith('_'))
            fileRef = `_${mls.actualProject || 0}_${fileRef}`;
        const info = mls.stor.convertFileReferenceToFile(fileRef);
        const k = mls.stor.getKeyToFile(info);
        let sf = mls.stor.files[k];
        if (!sf) {
            const param = {
                ...info,
                source: src
            };
            sf = await createStorFile(param, false, false, false);
        }
        else {
            if (!['.ts', '.less', '.defs.ts', '.test.ts'].includes(sf.extension)) {
                const m = await createModelAnyFile(sf);
                if (m && m.model)
                    m.model.setValue(src);
            }
            else {
                const m = await sf.getOrCreateModel();
                if (m && m.model)
                    m.model.setValue(src);
            }
        }
        return sf;
    }
    async getVar(path, variable) {
        try {
            const f = mls.stor.convertFileReferenceToFile(path);
            if (!f)
                return '';
            const module = await collabImport(f);
            if (module && variable in module) {
                const result = module[variable];
                if (typeof result === 'object')
                    return JSON.stringify(result);
                return await this.processTemplate(result);
            }
            // Módulo não tinha a variável — tenta buildar via esbuild
            const built = await this.buildAndExtract(path, variable);
            if (built !== null)
                return built;
            console.warn(`[getVar] Variable não encontrada após build: ${path}; ${variable}`);
            return '';
        }
        catch (err) {
            console.error(`Erro em ${path}`, err);
            return '';
        }
    }
    async buildAndExtract(path, variable) {
        try {
            // Retorna do cache se já foi buildado
            if (buildCache.has(path)) {
                const cached = buildCache.get(path);
                if (variable in cached) {
                    const value = cached[variable];
                    if (typeof value === 'object')
                        return JSON.stringify(value);
                    return await this.processTemplate(String(value));
                }
                // Arquivo já foi buildado mas não tem a variável — não tenta de novo
                console.warn(`[buildAndExtract] Variável não encontrada no cache: ${path}; ${variable}`);
                return null;
            }
            const f = mls.stor.convertFileReferenceToFile(path);
            if (!f)
                return null;
            const key = mls.stor.getKeyToFile(f);
            const sf = mls.stor.files[key];
            if (!sf)
                return null;
            const src = await sf.getContent();
            console.info('Needed esbuild:' + path);
            const esbuild = await getEsbuild();
            const result = await esbuild.transform(src, {
                loader: 'ts',
                format: 'esm',
                target: 'esnext',
            });
            const blob = new Blob([result.code], { type: 'text/javascript' });
            const blobUrl = URL.createObjectURL(blob);
            try {
                const mod = await import(blobUrl);
                // Salva o módulo inteiro no cache — não só a variável pedida
                buildCache.set(path, mod);
                if (variable in mod) {
                    const value = mod[variable];
                    if (typeof value === 'object')
                        return JSON.stringify(value);
                    return await this.processTemplate(String(value));
                }
                return null;
            }
            finally {
                URL.revokeObjectURL(blobUrl);
            }
        }
        catch (err) {
            console.error(`[buildAndExtract] Erro ao buildar ${path}`, err);
            return null;
        }
    }
}
