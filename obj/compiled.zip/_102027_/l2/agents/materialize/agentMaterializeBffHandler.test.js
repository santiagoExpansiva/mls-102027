/// <mls fileReference="_102027_/l2/agents/materialize/agentMaterializeBffHandler.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
