/// <mls fileReference="_102027_/l2/aiAgentHelper.ts" enhancement="_blank"/>
import { msgAppendLongTermMemory } from '/_102036_/l2/shared/api.js';
/**
 * Helper function to collect all steps from a task in a flat array
 */
export const getAllSteps = (firstStep) => {
    if (!firstStep || firstStep.length < 1) {
        return [];
    }
    const allSteps = [];
    const queue = [...firstStep];
    // BFS approach to collect all steps
    while (queue.length > 0) {
        const currentStep = queue.shift();
        allSteps.push(currentStep);
        // Add nextSteps to queue if they exist
        if (currentStep.nextSteps) {
            queue.push(...currentStep.nextSteps);
        }
        // Add steps from interaction.payload if they exist
        if (currentStep.interaction?.payload) {
            queue.push(...currentStep.interaction.payload);
        }
    }
    return allSteps;
};
export const getAgentStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.find((step) => step.type === 'agent' && step.agentName === agentName);
    return agentSteps || null;
};
export const getAllAgentStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent' && step.agentName === agentName);
    return agentSteps || null;
};
export const getAgentsStepByAgentName = (task, agentName, status) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent' && step.agentName === agentName);
    if (!status)
        return agentSteps || [];
    return agentSteps.filter(step => step.status === status);
};
export const getStepById = (task, stepId) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.stepId === stepId) || null;
};
export const getNextPendentStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.status === 'pending') || null;
};
export const getNextResultStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'result');
    return agentSteps.find(step => step.status === 'completed') || null;
};
export const getNextClarificationStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'clarification');
    return agentSteps.find(step => step.status === 'pending' || step.status === 'in_progress') || null;
};
export const getNextPendingStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'pending' && step.agentName === agentName) || null;
};
export const getNextFlexiblePendingStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'flexible');
    return agentSteps.find(step => step.status === 'pending') || null;
};
export const getNextInProgressStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'in_progress' && step.agentName === agentName) || null;
};
export const getRootAgent = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps[0] || null;
};
export const getInteractionStepId = (task, stepId) => {
    // nextSteps []
    // | interaction
    // | | nextsSteps []
    // ...
    // this routine finds the parent agent stepId for a pending step
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    if (!allSteps)
        return null;
    for (const step of allSteps) {
        if (step.nextSteps?.find(s => s.stepId === stepId))
            return step.stepId;
        if (!step.interaction || !step.interaction.payload)
            continue;
        if (step.interaction.payload.length < 1)
            continue;
        if (step.interaction.payload.find(s => s.stepId === stepId))
            return step.stepId;
    }
    return null;
};
export const calculateStepsStatistics = (steps, removeFirstStep) => {
    const allSteps = getAllSteps(steps);
    if (removeFirstStep)
        allSteps.shift();
    return {
        agents: allSteps.filter(step => step.type === 'agent').length,
        tools: allSteps.filter(step => step.type === 'tool').length,
        clarification: allSteps.filter(step => step.type === 'clarification').length,
        result: allSteps.filter(step => step.type === 'result').length,
        flexible: allSteps.filter(step => step.type === 'flexible').length,
        totalCost: allSteps.reduce((sum, step) => sum + (step.interaction?.cost || 0), 0),
        totalSteps: allSteps.length
    };
};
export const calculateStepsByFilter = (task, filter) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    // example: calculateStepsByFilter(task, { toolName: "abc "})
    let result = 0;
    for (const step of allSteps) {
        let allPropertiesMatch = true;
        for (const [key, value] of Object.entries(filter)) {
            const value2 = step[key];
            if (value2 !== value) {
                allPropertiesMatch = false;
                break; // exit for
            }
        }
        if (allPropertiesMatch)
            result += 1;
    }
    return result;
};
export const getTemporaryContext = (threadId, userId, prompt) => {
    // create temporary context
    const now = new Date();
    const formattedDate = now.getFullYear().toString()
        + String(now.getMonth() + 1).padStart(2, '0')
        + String(now.getDate()).padStart(2, '0')
        + String(now.getHours() + 3).padStart(2, '0')
        + String(now.getMinutes()).padStart(2, '0')
        + String(now.getSeconds()).padStart(2, '0')
        + "." + Math.floor(1000 + Math.random() * 9000);
    const context = {
        task: undefined,
        message: {
            threadId: threadId,
            orderAt: "",
            createAt: formattedDate,
            senderId: userId,
            content: prompt.trim(),
        },
        isTest: false
    };
    return context;
};
export function notifyMessageSendChange(context) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-send', {
        detail: { context },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskChange(context, oldContextCreateAt) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-change', {
        detail: { context, oldContextCreateAt },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskCompleted(context, result) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-completed', {
        detail: { context, result },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadChange(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-change', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyMessageChange(message) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-change', {
        detail: message,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadCreate(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-create', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchDetailsTaskClose(taskId) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-details-close', {
        detail: taskId,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function getTotalCost(task) {
    let tot = 0;
    const nextSteps = task.iaCompressed?.nextSteps;
    if (!nextSteps || nextSteps.length === 0)
        return "$ 0.01"; // garante saída mínima
    const sumCosts = (payload) => {
        payload.forEach((pay) => {
            const { interaction, nextSteps } = pay;
            if (interaction) {
                tot += interaction.cost ? interaction.cost : 0;
                if (interaction.payload)
                    sumCosts(interaction.payload);
            }
            if (nextSteps) {
                nextSteps.forEach((next) => sumCosts([next]));
            }
        });
    };
    nextSteps.forEach((step) => sumCosts([step]));
    const rounded = Math.ceil(tot * 100) / 100;
    return `${rounded.toFixed(2)}`;
}
export async function appendLongTermMemory(context, longTermMemory) {
    if (!context.task)
        throw new Error('[appendLongTermMemory] invalid task');
    const messageId = context.task.messageid_created;
    if (!messageId)
        throw new Error("[appendLongTermMemory] Invalid messageId");
    try {
        const ret = await msgAppendLongTermMemory({
            longTermMemory,
            messageId,
            taskId: context.task.PK,
            userId: context.message.senderId,
        });
        if (!ret || ret.statusCode !== 200)
            throw new Error("error on AI appendLongTermMemory , stoped");
        return ret.task;
    }
    catch (err) {
        throw new Error('[appendLongTermMemory] ' + err.message);
    }
}
export function getNextStepIdAvaliable(task) {
    let nextStepId = 0;
    const nextSteps = task.iaCompressed?.nextSteps;
    if (!nextSteps || nextSteps.length === 0)
        return nextStepId + 1;
    const findNextStepId = (payload) => {
        payload.forEach((pay) => {
            const { interaction, nextSteps, stepId } = pay;
            if (stepId > nextStepId)
                nextStepId = stepId + 1;
            if (interaction) {
                if (interaction.payload)
                    findNextStepId(interaction.payload);
            }
            if (nextSteps) {
                nextSteps.forEach((next) => {
                    if (next.stepId > nextStepId)
                        nextStepId = next.stepId + 1;
                    findNextStepId([next]);
                });
            }
        });
    };
    nextSteps.forEach((step) => {
        if (step.stepId > nextStepId)
            nextStepId = step.stepId + 1;
        findNextStepId([step]);
    });
    return nextStepId;
}
export function findPreviousAgentStep(data, baseStep) {
    const nextSteps = data.iaCompressed?.nextSteps;
    // Percorre a árvore guardando o "pai" de cada stepId
    const traverse = (steps, parentStep = null) => {
        for (const step of steps) {
            if (step.type === "agent") {
                if (step.stepId === baseStep) {
                    return parentStep;
                }
                // Busca recursiva nos nextSteps do step atual
                if (step.nextSteps && step.nextSteps.length > 0) {
                    const found = traverse(step.nextSteps, step);
                    if (found !== undefined)
                        return found;
                }
                // Busca dentro do payload da interação (se existir e for objeto/array)
                if (step.interaction?.payload) {
                    const payload = step.interaction.payload;
                    const payloadSteps = Array.isArray(payload) ? payload : [payload];
                    const found = traverse(payloadSteps, step);
                    if (found !== undefined)
                        return found;
                }
            }
        }
        return undefined;
    };
    if (nextSteps === undefined) {
        return null;
    }
    const previousStep = traverse(nextSteps);
    if (previousStep === undefined) {
        return null;
    }
    return previousStep; // null = é root, objeto = step pai
}
