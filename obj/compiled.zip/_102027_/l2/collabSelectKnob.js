/// <mls fileReference="_102027_/l2/collabSelectKnob.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let SelectOneKnobWidget = class SelectOneKnobWidget extends StateLitElement {
    constructor() {
        super(...arguments);
        this.min = 1;
        this.max = 9;
        this.value = null;
        this.step = 1;
        this.disabled = false;
        this.active = false;
        this.selected = false;
        this.showTicks = false;
        this._focused = false;
        this._editing = false;
        this._dragStartY = 0;
        this._dragStartValue = 0;
        this._dragging = false;
        this._pendingDigit = '';
        this._digitTimeout = null;
        this._pendingDisplay = null;
        this._pendingInvalid = false;
    }
    get _hasValue() {
        return this.value !== null && this.value !== undefined;
    }
    get _rotation() {
        if (!this._hasValue)
            return -135;
        const range = this.max - this.min;
        const normalized = ((this.value - this.min) / range);
        return -135 + normalized * 270;
    }
    get _tickCount() {
        return Math.floor((this.max - this.min) / this.step) + 1;
    }
    get _displayValue() {
        if (this._pendingDisplay !== null)
            return this._pendingDisplay;
        if (this._hasValue)
            return String(this.value);
        return '';
    }
    get _displayHidden() {
        return !this._hasValue && this._pendingDisplay === null;
    }
    get _canInteract() {
        return !this.disabled && this.active;
    }
    _clamp(v) {
        return Math.min(this.max, Math.max(this.min, v));
    }
    _setValue(next) {
        const prev = this.value;
        this.value = next !== null ? this._clamp(next) : null;
        if (this.value !== prev) {
            this.dispatchEvent(new CustomEvent('knob-change', {
                bubbles: true,
                composed: false,
                detail: { value: this.value, previous: prev }
            }));
        }
    }
    _cycleValue() {
        if (!this._hasValue) {
            this._setValue(this.min);
            return;
        }
        const next = this.value + this.step;
        this._setValue(next > this.max ? this.min : next);
    }
    _onKeyDown(e) {
        if (!this._canInteract)
            return;
        if (e.key === 'ArrowUp' || e.key === 'ArrowRight') {
            e.preventDefault();
            this._cancelDigitInput();
            this._setValue((this._hasValue ? this.value : this.min - this.step) + this.step);
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') {
            e.preventDefault();
            this._cancelDigitInput();
            this._setValue((this._hasValue ? this.value : this.min) - this.step);
            return;
        }
        if (e.key === 'Escape') {
            this._editing = false;
            this._cancelDigitInput();
            this.renderRoot.blur?.();
            return;
        }
        if (e.key === 'Backspace') {
            e.preventDefault();
            this._cancelDigitInput();
            this._setValue(null);
            return;
        }
        if (/^[0-9]$/.test(e.key)) {
            e.preventDefault();
            this._pendingDigit += e.key;
            const parsed = parseInt(this._pendingDigit, 10);
            this._pendingDisplay = this._pendingDigit;
            this._pendingInvalid = parsed < this.min || parsed > this.max;
            if (this._digitTimeout)
                clearTimeout(this._digitTimeout);
            this._digitTimeout = setTimeout(() => {
                if (!isNaN(parsed) && parsed >= this.min && parsed <= this.max) {
                    this._setValue(parsed);
                }
                this._pendingDigit = '';
                this._pendingInvalid = false;
                this._pendingDisplay = null;
            }, 600);
        }
    }
    _cancelDigitInput() {
        if (this._digitTimeout)
            clearTimeout(this._digitTimeout);
        this._digitTimeout = null;
        this._pendingDigit = '';
        this._pendingDisplay = null;
        this._pendingInvalid = false;
    }
    _onMouseDown(e) {
        if (this.disabled)
            return;
        e.preventDefault();
        this._dragging = false;
        this._dragStartY = e.clientY;
        this._dragStartValue = this._hasValue ? this.value : this.min;
        const onMove = (ev) => {
            if (!this.active)
                return;
            const delta = this._dragStartY - ev.clientY;
            if (Math.abs(delta) > 3)
                this._dragging = true;
            const steps = Math.round(delta / 8);
            this._setValue(this._dragStartValue + steps * this.step);
        };
        const onUp = () => {
            window.removeEventListener('mousemove', onMove);
            window.removeEventListener('mouseup', onUp);
            this._dragging = false;
        };
        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
    }
    _onWheel(e) {
        if (!this._canInteract)
            return;
        e.preventDefault();
        const dir = e.deltaY < 0 ? 1 : -1;
        this._setValue((this._hasValue ? this.value : this.min) + dir * this.step);
    }
    _onFocus() {
        if (this.disabled)
            return;
        this._focused = true;
        this.dispatchEvent(new CustomEvent('knob-focus', { bubbles: true, composed: false }));
    }
    _onBlur() {
        this._focused = false;
        this._editing = false;
        this._cancelDigitInput();
        this.dispatchEvent(new CustomEvent('knob-blur', { bubbles: true, composed: false }));
    }
    _onDisplayClick(e) {
        if (this.disabled)
            return;
        e.stopPropagation();
        if (!this.active) {
            this.dispatchEvent(new CustomEvent('knob-click', { bubbles: true, composed: false }));
            return;
        }
        this._editing = true;
        const root = this.renderRoot.querySelector('[data-knob-root]');
        root?.focus();
    }
    _onClick() {
        if (this.disabled)
            return;
        if (this.active && !this._dragging) {
            this._cycleValue();
        }
        this.dispatchEvent(new CustomEvent('knob-click', { bubbles: true, composed: false }));
    }
    _renderTicks() {
        if (!this.showTicks)
            return '';
        const ticks = [];
        const total = this._tickCount;
        for (let i = 0; i < total; i++) {
            const angle = -135 + (i / (total - 1)) * 270;
            const isCurrent = this._hasValue && (this.min + i * this.step) === this.value;
            ticks.push(html `
        <div
          class="knob__tick ${isCurrent ? 'knob__tick--active' : ''}"
          style="transform: rotate(${angle}deg)"
        ></div>
      `);
        }
        return ticks;
    }
    render() {
        const rootClasses = [
            'widgets--select-one-knob-102027',
            this.active ? 'is-active' : '',
            this.selected ? 'is-selected' : '',
            this._focused ? 'is-focused' : '',
            this._editing ? 'is-editing' : '',
            this.disabled ? 'is-disabled' : '',
            this._hasValue ? 'has-value' : '',
            this._pendingDisplay !== null ? 'is-typing' : '',
            this._pendingInvalid ? 'is-invalid' : '',
            !this.showTicks ? 'no-ticks' : '',
        ].filter(Boolean).join(' ');
        return html `
      <div
        class="${rootClasses}"
        data-knob-root
        tabindex="${this.disabled ? -1 : 0}"
        role="spinbutton"
        aria-valuenow="${this._hasValue ? this.value : ''}"
        aria-valuemin="${this.min}"
        aria-valuemax="${this.max}"
        aria-disabled="${this.disabled}"
        @keydown="${this._onKeyDown}"
        @mousedown="${this._onMouseDown}"
        @wheel="${this._onWheel}"
        @focus="${this._onFocus}"
        @blur="${this._onBlur}"
        @click=${this._onClick}
      >
        <div class="knob__ticks-ring">
          ${this._renderTicks()}
        </div>

        <div
          class="knob__body"
          style="transform: rotate(${this._rotation}deg)"
        >
          <div class="knob__indicator"></div>
        </div>

        <div class="knob__display" @click=${this._onDisplayClick}>
          <span class="knob__value ${this._displayHidden ? 'knob__value--hidden' : ''}">
            ${this._displayValue}
          </span>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Number })
], SelectOneKnobWidget.prototype, "min", void 0);
__decorate([
    property({ type: Number })
], SelectOneKnobWidget.prototype, "max", void 0);
__decorate([
    property({ type: Number, reflect: true })
], SelectOneKnobWidget.prototype, "value", void 0);
__decorate([
    property({ type: Number })
], SelectOneKnobWidget.prototype, "step", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], SelectOneKnobWidget.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], SelectOneKnobWidget.prototype, "active", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], SelectOneKnobWidget.prototype, "selected", void 0);
__decorate([
    property({ type: Boolean, attribute: 'show-ticks' })
], SelectOneKnobWidget.prototype, "showTicks", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_focused", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_editing", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_pendingDisplay", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_pendingInvalid", void 0);
SelectOneKnobWidget = __decorate([
    customElement('collab-select-knob-102027')
], SelectOneKnobWidget);
export { SelectOneKnobWidget };
