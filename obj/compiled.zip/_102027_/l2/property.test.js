/// <mls fileReference="_102027_/l2/property.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
