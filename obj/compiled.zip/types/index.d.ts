declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "../l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "../l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "../l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from '_102027_/l2/aiAgentBase';
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102027_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class AiAgentDefaultFeedback102027 extends StateLitElement {
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private getChildren;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
        private collab_bell;
        private collab_play;
        private collab_pause;
    }
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from '_102027_/l2/aiAgentBase';
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "../l2/directive" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Disconnectable, Part } from '_102027_/l2/litHtml';
    export { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart, } from '_102027_/l2/litHtml';
    export interface DirectiveClass {
        new (part: PartInfo): Directive;
    }
    /**
     * This utility type extracts the signature of a directive class's render()
     * method so we can use it for the type of the generated directive function.
     */
    export type DirectiveParameters<C extends Directive> = Parameters<C['render']>;
    /**
     * A generated directive function doesn't evaluate the directive, but just
     * returns a DirectiveResult object that captures the arguments.
     */
    export interface DirectiveResult<C extends DirectiveClass = DirectiveClass> {
    }
    export const PartType: {
        readonly ATTRIBUTE: 1;
        readonly CHILD: 2;
        readonly PROPERTY: 3;
        readonly BOOLEAN_ATTRIBUTE: 4;
        readonly EVENT: 5;
        readonly ELEMENT: 6;
    };
    export type PartType = (typeof PartType)[keyof typeof PartType];
    export interface ChildPartInfo {
        readonly type: typeof PartType.CHILD;
    }
    export interface AttributePartInfo {
        readonly type: typeof PartType.ATTRIBUTE | typeof PartType.PROPERTY | typeof PartType.BOOLEAN_ATTRIBUTE | typeof PartType.EVENT;
        readonly strings?: ReadonlyArray<string>;
        readonly name: string;
        readonly tagName: string;
    }
    export interface ElementPartInfo {
        readonly type: typeof PartType.ELEMENT;
    }
    /**
     * Information about the part a directive is bound to.
     *
     * This is useful for checking that a directive is attached to a valid part,
     * such as with directive that can only be used on attribute bindings.
     */
    export type PartInfo = ChildPartInfo | AttributePartInfo | ElementPartInfo;
    /**
     * Creates a user-facing directive function from a Directive class. This
     * function has the same parameters as the directive's render() method.
     */
    export const directive: <C extends DirectiveClass>(c: C) => (...values: DirectiveParameters<InstanceType<C>>) => DirectiveResult<C>;
    /**
     * Base class for creating custom directives. Users should extend this class,
     * implement `render` and/or `update`, and then pass their subclass to
     * `directive`.
     */
    export abstract class Directive implements Disconnectable {
        constructor(_partInfo: PartInfo);
        get _$isConnected(): boolean;
        abstract render(...props: Array<unknown>): unknown;
        update(_part: Part, props: Array<unknown>): unknown;
    }
}
declare module "../l2/litHtml" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { Directive } from '_102027_/l2/directive';
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace LitUnstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = TemplatePrep | TemplateInstantiated | TemplateInstantiatedAndUpdated | TemplateUpdating | BeginRender | EndRender | CommitPartEntry | SetPartValue;
            interface TemplatePrep {
                kind: 'template prep';
                template: Template;
                strings: TemplateStringsArray;
                clonableTemplate: HTMLTemplateElement;
                parts: TemplatePart[];
            }
            interface BeginRender {
                kind: 'begin render';
                id: number;
                value: unknown;
                container: HTMLElement | DocumentFragment;
                options: RenderOptions | undefined;
                part: ChildPart | undefined;
            }
            interface EndRender {
                kind: 'end render';
                id: number;
                value: unknown;
                container: HTMLElement | DocumentFragment;
                options: RenderOptions | undefined;
                part: ChildPart;
            }
            interface TemplateInstantiated {
                kind: 'template instantiated';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                fragment: Node;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface TemplateInstantiatedAndUpdated {
                kind: 'template instantiated and updated';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                fragment: Node;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface TemplateUpdating {
                kind: 'template updating';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface SetPartValue {
                kind: 'set part';
                part: Part;
                value: unknown;
                valueIndex: number;
                values: unknown[];
                templateInstance: TemplateInstance;
            }
            type CommitPartEntry = CommitNothingToChildEntry | CommitText | CommitNode | CommitAttribute | CommitProperty | CommitBooleanAttribute | CommitEventListener | CommitToElementBinding;
            interface CommitNothingToChildEntry {
                kind: 'commit nothing to child';
                start: ChildNode;
                end: ChildNode | null;
                parent: Disconnectable | undefined;
                options: RenderOptions | undefined;
            }
            interface CommitText {
                kind: 'commit text';
                node: Text;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitNode {
                kind: 'commit node';
                start: Node;
                parent: Disconnectable | undefined;
                value: Node;
                options: RenderOptions | undefined;
            }
            interface CommitAttribute {
                kind: 'commit attribute';
                element: Element;
                name: string;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitProperty {
                kind: 'commit property';
                element: Element;
                name: string;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitBooleanAttribute {
                kind: 'commit boolean attribute';
                element: Element;
                name: string;
                value: boolean;
                options: RenderOptions | undefined;
            }
            interface CommitEventListener {
                kind: 'commit event listener';
                element: Element;
                name: string;
                value: unknown;
                oldListener: unknown;
                options: RenderOptions | undefined;
                removeListener: boolean;
                addListener: boolean;
            }
            interface CommitToElementBinding {
                kind: 'commit to element binding';
                element: Element;
                value: unknown;
                options: RenderOptions | undefined;
            }
        }
    }
    /**
     * Used to sanitize any value before it is written into the DOM. This can be
     * used to implement a security policy of allowed and disallowed values in
     * order to prevent XSS attacks.
     *
     * One way of using this callback would be to check attributes and properties
     * against a list of high risk fields, and require that values written to such
     * fields be instances of a class which is safe by construction. Closure's Safe
     * HTML Types is one implementation of this technique (
     * https://github.com/google/safe-html-types/blob/master/doc/safehtml-types.md).
     * The TrustedTypes polyfill in API-only mode could also be used as a basis
     * for this technique (https://github.com/WICG/trusted-types).
     *
     * @param node The HTML node (usually either a #text node or an Element) that
     *     is being written to. Note that this is just an exemplar node, the write
     *     may take place against another instance of the same class of node.
     * @param name The name of an attribute or property (for example, 'href').
     * @param type Indicates whether the write that's about to be performed will
     *     be to a property or a node.
     * @return A function that will sanitize this class of writes.
     */
    export type SanitizerFactory = (node: Node, name: string, type: 'property' | 'attribute') => ValueSanitizer;
    /**
     * A function which can sanitize values that will be written to a specific kind
     * of DOM sink.
     *
     * See SanitizerFactory.
     *
     * @param value The value to sanitize. Will be the actual value passed into
     *     the lit-html template literal, so this could be of any type.
     * @return The value to write to the DOM. Usually the same as the input value,
     *     unless sanitization is needed.
     */
    export type ValueSanitizer = (value: unknown) => unknown;
    /** TemplateResult types */
    const HTML_RESULT = 1;
    const SVG_RESULT = 2;
    const MATHML_RESULT = 3;
    type ResultType = typeof HTML_RESULT | typeof SVG_RESULT | typeof MATHML_RESULT;
    const ATTRIBUTE_PART = 1;
    const CHILD_PART = 2;
    const PROPERTY_PART = 3;
    const BOOLEAN_ATTRIBUTE_PART = 4;
    const EVENT_PART = 5;
    const ELEMENT_PART = 6;
    const COMMENT_PART = 7;
    /**
     * The return type of the template tag functions, {@linkcode html} and
     * {@linkcode svg} when it hasn't been compiled by @lit-labs/compiler.
     *
     * A `TemplateResult` object holds all the information about a template
     * expression required to render it: the template strings, expression values,
     * and type of template (html or svg).
     *
     * `TemplateResult` objects do not create any DOM on their own. To create or
     * update DOM you need to render the `TemplateResult`. See
     * [Rendering](https://lit.dev/docs/components/rendering) for more information.
     *
     */
    export type UncompiledTemplateResult<T extends ResultType = ResultType> = {
        ['_$litType$']: T;
        strings: TemplateStringsArray;
        values: unknown[];
    };
    /**
     * This is a template result that may be either uncompiled or compiled.
     *
     * In the future, TemplateResult will be this type. If you want to explicitly
     * note that a template result is potentially compiled, you can reference this
     * type and it will continue to behave the same through the next major version
     * of Lit. This can be useful for code that wants to prepare for the next
     * major version of Lit.
     */
    export type MaybeCompiledTemplateResult<T extends ResultType = ResultType> = UncompiledTemplateResult<T> | CompiledTemplateResult;
    /**
     * The return type of the template tag functions, {@linkcode html} and
     * {@linkcode svg}.
     *
     * A `TemplateResult` object holds all the information about a template
     * expression required to render it: the template strings, expression values,
     * and type of template (html or svg).
     *
     * `TemplateResult` objects do not create any DOM on their own. To create or
     * update DOM you need to render the `TemplateResult`. See
     * [Rendering](https://lit.dev/docs/components/rendering) for more information.
     *
     * In Lit 4, this type will be an alias of
     * MaybeCompiledTemplateResult, so that code will get type errors if it assumes
     * that Lit templates are not compiled. When deliberately working with only
     * one, use either {@linkcode CompiledTemplateResult} or
     * {@linkcode UncompiledTemplateResult} explicitly.
     */
    export type TemplateResult<T extends ResultType = ResultType> = UncompiledTemplateResult<T>;
    export type HTMLTemplateResult = TemplateResult<typeof HTML_RESULT>;
    export type SVGTemplateResult = TemplateResult<typeof SVG_RESULT>;
    export type MathMLTemplateResult = TemplateResult<typeof MATHML_RESULT>;
    /**
     * A TemplateResult that has been compiled by @lit-labs/compiler, skipping the
     * prepare step.
     */
    export interface CompiledTemplateResult {
        ['_$litType$']: CompiledTemplate;
        values: unknown[];
    }
    export interface CompiledTemplate extends Omit<Template, 'el'> {
        el?: HTMLTemplateElement;
        h: TemplateStringsArray;
    }
    /**
     * Interprets a template literal as an HTML template that can efficiently
     * render to and update a container.
     *
     * ```ts
     * const header = (title: string) => html`<h1>${title}</h1>`;
     * ```
     *
     * The `html` tag returns a description of the DOM to render as a value. It is
     * lazy, meaning no work is done until the template is rendered. When rendering,
     * if a template comes from the same expression as a previously rendered result,
     * it's efficiently updated instead of replaced.
     */
    export const html: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<1>;
    /**
     * Interprets a template literal as an SVG fragment that can efficiently render
     * to and update a container.
     *
     * ```ts
     * const rect = svg`<rect width="10" height="10"></rect>`;
     *
     * const myImage = html`
     *   <svg viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg">
     *     ${rect}
     *   </svg>`;
     * ```
     *
     * The `svg` *tag function* should only be used for SVG fragments, or elements
     * that would be contained **inside** an `<svg>` HTML element. A common error is
     * placing an `<svg>` *element* in a template tagged with the `svg` tag
     * function. The `<svg>` element is an HTML element and should be used within a
     * template tagged with the {@linkcode html} tag function.
     *
     * In LitElement usage, it's invalid to return an SVG fragment from the
     * `render()` method, as the SVG fragment will be contained within the element's
     * shadow root and thus not be properly contained within an `<svg>` HTML
     * element.
     */
    export const svg: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<2>;
    /**
     * Interprets a template literal as MathML fragment that can efficiently render
     * to and update a container.
     *
     * ```ts
     * const num = mathml`<mn>1</mn>`;
     *
     * const eq = html`
     *   <math>
     *     ${num}
     *   </math>`;
     * ```
     *
     * The `mathml` *tag function* should only be used for MathML fragments, or
     * elements that would be contained **inside** a `<math>` HTML element. A common
     * error is placing a `<math>` *element* in a template tagged with the `mathml`
     * tag function. The `<math>` element is an HTML element and should be used
     * within a template tagged with the {@linkcode html} tag function.
     *
     * In LitElement usage, it's invalid to return an MathML fragment from the
     * `render()` method, as the MathML fragment will be contained within the
     * element's shadow root and thus not be properly contained within a `<math>`
     * HTML element.
     */
    export const mathml: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<3>;
    /**
     * A sentinel value that signals that a value was handled by a directive and
     * should not be written to the DOM.
     */
    export const noChange: unique symbol;
    /**
     * A sentinel value that signals a ChildPart to fully clear its content.
     *
     * ```ts
     * const button = html`${
     *  user.isAdmin
     *    ? html`<button>DELETE</button>`
     *    : nothing
     * }`;
     * ```
     *
     * Prefer using `nothing` over other falsy values as it provides a consistent
     * behavior between various expression binding contexts.
     *
     * In child expressions, `undefined`, `null`, `''`, and `nothing` all behave the
     * same and render no nodes. In attribute expressions, `nothing` _removes_ the
     * attribute, while `undefined` and `null` will render an empty string. In
     * property expressions `nothing` becomes `undefined`.
     */
    export const nothing: unique symbol;
    /**
     * Object specifying options for controlling lit-html rendering. Note that
     * while `render` may be called multiple times on the same `container` (and
     * `renderBefore` reference node) to efficiently update the rendered content,
     * only the options passed in during the first render are respected during
     * the lifetime of renders to that unique `container` + `renderBefore`
     * combination.
     */
    export interface RenderOptions {
        /**
         * An object to use as the `this` value for event listeners. It's often
         * useful to set this to the host component rendering a template.
         */
        host?: object;
        /**
         * A DOM node before which to render content in the container.
         */
        renderBefore?: ChildNode | null;
        /**
         * Node used for cloning the template (`importNode` will be called on this
         * node). This controls the `ownerDocument` of the rendered DOM, along with
         * any inherited context. Defaults to the global `document`.
         */
        creationScope?: {
            importNode(node: Node, deep?: boolean): Node;
        };
        /**
         * The initial connected state for the top-level part being rendered. If no
         * `isConnected` option is set, `AsyncDirective`s will be connected by
         * default. Set to `false` if the initial render occurs in a disconnected tree
         * and `AsyncDirective`s should see `isConnected === false` for their initial
         * render. The `part.setConnected()` method must be used subsequent to initial
         * render to change the connected state of the part.
         */
        isConnected?: boolean;
    }
    export interface DirectiveParent {
        _$parent?: DirectiveParent;
        _$isConnected: boolean;
        __directive?: Directive;
        __directives?: Array<Directive | undefined>;
    }
    class Template {
        parts: Array<TemplatePart>;
        constructor({ strings, _$litType$ }: UncompiledTemplateResult, options?: RenderOptions);
        static createElement(html: any, _options?: RenderOptions): HTMLTemplateElement;
    }
    export interface Disconnectable {
        _$parent?: Disconnectable;
        _$disconnectableChildren?: Set<Disconnectable>;
        _$isConnected: boolean;
    }
    function resolveDirective(part: ChildPart | AttributePart | ElementPart, value: unknown, parent?: DirectiveParent, attributeIndex?: number): unknown;
    export type { TemplateInstance };
    /**
     * An updateable instance of a Template. Holds references to the Parts used to
     * update the template instance.
     */
    class TemplateInstance implements Disconnectable {
        _$template: Template;
        _$parts: Array<Part | undefined>;
        constructor(template: Template, parent: ChildPart);
        get parentNode(): Node;
        get _$isConnected(): boolean;
        _clone(options: RenderOptions | undefined): Node;
        _update(values: Array<unknown>): void;
    }
    type AttributeTemplatePart = {
        readonly type: typeof ATTRIBUTE_PART;
        readonly index: number;
        readonly name: string;
        readonly ctor: typeof AttributePart;
        readonly strings: ReadonlyArray<string>;
    };
    type ChildTemplatePart = {
        readonly type: typeof CHILD_PART;
        readonly index: number;
    };
    type ElementTemplatePart = {
        readonly type: typeof ELEMENT_PART;
        readonly index: number;
    };
    type CommentTemplatePart = {
        readonly type: typeof COMMENT_PART;
        readonly index: number;
    };
    /**
     * A TemplatePart represents a dynamic part in a template, before the template
     * is instantiated. When a template is instantiated Parts are created from
     * TemplateParts.
     */
    type TemplatePart = ChildTemplatePart | AttributeTemplatePart | ElementTemplatePart | CommentTemplatePart;
    export type Part = ChildPart | AttributePart | PropertyPart | BooleanAttributePart | ElementPart | EventPart;
    export type { ChildPart };
    class ChildPart implements Disconnectable {
        readonly type = 2;
        readonly options: RenderOptions | undefined;
        _$committedValue: unknown;
        private _textSanitizer;
        get _$isConnected(): boolean;
        constructor(startNode: ChildNode, endNode: ChildNode | null, parent: TemplateInstance | ChildPart | undefined, options: RenderOptions | undefined);
        /**
         * The parent node into which the part renders its content.
         *
         * A ChildPart's content consists of a range of adjacent child nodes of
         * `.parentNode`, possibly bordered by 'marker nodes' (`.startNode` and
         * `.endNode`).
         *
         * - If both `.startNode` and `.endNode` are non-null, then the part's content
         * consists of all siblings between `.startNode` and `.endNode`, exclusively.
         *
         * - If `.startNode` is non-null but `.endNode` is null, then the part's
         * content consists of all siblings following `.startNode`, up to and
         * including the last child of `.parentNode`. If `.endNode` is non-null, then
         * `.startNode` will always be non-null.
         *
         * - If both `.endNode` and `.startNode` are null, then the part's content
         * consists of all child nodes of `.parentNode`.
         */
        get parentNode(): Node;
        /**
         * The part's leading marker node, if any. See `.parentNode` for more
         * information.
         */
        get startNode(): Node | null;
        /**
         * The part's trailing marker node, if any. See `.parentNode` for more
         * information.
         */
        get endNode(): Node | null;
        _$setValue(value: unknown, directiveParent?: DirectiveParent): void;
        private _insert;
        private _commitNode;
        private _commitText;
        private _commitTemplateResult;
        private _commitIterable;
    }
    /**
     * A top-level `ChildPart` returned from `render` that manages the connected
     * state of `AsyncDirective`s created throughout the tree below it.
     */
    export interface RootPart extends ChildPart {
        /**
         * Sets the connection state for `AsyncDirective`s contained within this root
         * ChildPart.
         *
         * lit-html does not automatically monitor the connectedness of DOM rendered;
         * as such, it is the responsibility of the caller to `render` to ensure that
         * `part.setConnected(false)` is called before the part object is potentially
         * discarded, to ensure that `AsyncDirective`s have a chance to dispose of
         * any resources being held. If a `RootPart` that was previously
         * disconnected is subsequently re-connected (and its `AsyncDirective`s should
         * re-connect), `setConnected(true)` should be called.
         *
         * @param isConnected Whether directives within this tree should be connected
         * or not
         */
        setConnected(isConnected: boolean): void;
    }
    export type { AttributePart };
    class AttributePart implements Disconnectable {
        readonly type: typeof ATTRIBUTE_PART | typeof PROPERTY_PART | typeof BOOLEAN_ATTRIBUTE_PART | typeof EVENT_PART;
        readonly element: HTMLElement;
        readonly name: string;
        readonly options: RenderOptions | undefined;
        /**
         * If this attribute part represents an interpolation, this contains the
         * static strings of the interpolation. For single-value, complete bindings,
         * this is undefined.
         */
        readonly strings?: ReadonlyArray<string>;
        protected _sanitizer: ValueSanitizer | undefined;
        get tagName(): string;
        get _$isConnected(): boolean;
        constructor(element: HTMLElement, name: string, strings: ReadonlyArray<string>, parent: Disconnectable, options: RenderOptions | undefined);
    }
    export type { PropertyPart };
    class PropertyPart extends AttributePart {
        readonly type = 3;
    }
    export type { BooleanAttributePart };
    class BooleanAttributePart extends AttributePart {
        readonly type = 4;
    }
    /**
     * An AttributePart that manages an event listener via add/removeEventListener.
     *
     * This part works by adding itself as the event listener on an element, then
     * delegating to the value passed to it. This reduces the number of calls to
     * add/removeEventListener if the listener changes frequently, such as when an
     * inline function is used as a listener.
     *
     * Because event options are passed when adding listeners, we must take case
     * to add and remove the part as a listener when the event options change.
     */
    export type { EventPart };
    class EventPart extends AttributePart {
        readonly type = 5;
        constructor(element: HTMLElement, name: string, strings: ReadonlyArray<string>, parent: Disconnectable, options: RenderOptions | undefined);
        handleEvent(event: Event): void;
    }
    export type { ElementPart };
    class ElementPart implements Disconnectable {
        element: Element;
        readonly type = 6;
        _$committedValue: undefined;
        options: RenderOptions | undefined;
        constructor(element: Element, parent: Disconnectable, options: RenderOptions | undefined);
        get _$isConnected(): boolean;
        _$setValue(value: unknown): void;
    }
    /**
     * END USERS SHOULD NOT RELY ON THIS OBJECT.
     *
     * Private exports for use by other Lit packages, not intended for use by
     * external users.
     *
     * We currently do not make a mangled rollup build of the lit-ssr code. In order
     * to keep a number of (otherwise private) top-level exports mangled in the
     * client side code, we export a _$LH object containing those members (or
     * helper methods for accessing private fields of those members), and then
     * re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
     * client-side code is being used in `dev` mode or `prod` mode.
     *
     * This has a unique name, to disambiguate it from private exports in
     * lit-element, which re-exports all of lit-html.
     *
     * @private
     */
    export const _$LH: {
        _boundAttributeSuffix: string;
        _marker: string;
        _markerMatch: string;
        _HTML_RESULT: number;
        _getTemplateHtml: (strings: TemplateStringsArray, type: ResultType) => [any, Array<string>];
        _TemplateInstance: typeof TemplateInstance;
        _isIterable: (value: unknown) => value is Iterable<unknown>;
        _resolveDirective: typeof resolveDirective;
        _ChildPart: typeof ChildPart;
        _AttributePart: typeof AttributePart;
        _BooleanAttributePart: typeof BooleanAttributePart;
        _EventPart: typeof EventPart;
        _PropertyPart: typeof PropertyPart;
        _ElementPart: typeof ElementPart;
    };
    /**
     * Renders a value, usually a lit-html TemplateResult, to the container.
     *
     * This example renders the text "Hello, Zoe!" inside a paragraph tag, appending
     * it to the container `document.body`.
     *
     * ```js
     * import {html, render} from 'lit';
     *
     * const name = "Zoe";
     * render(html`<p>Hello, ${name}!</p>`, document.body);
     * ```
     *
     * @param value Any [renderable
     *   value](https://lit.dev/docs/templates/expressions/#child-expressions),
     *   typically a {@linkcode TemplateResult} created by evaluating a template tag
     *   like {@linkcode html} or {@linkcode svg}.
     * @param container A DOM container to render to. The first render will append
     *   the rendered value to the container, and subsequent renders will
     *   efficiently update the rendered value if the same result type was
     *   previously rendered there.
     * @param options See {@linkcode RenderOptions} for options documentation.
     * @see
     * {@link https://lit.dev/docs/libraries/standalone-templates/#rendering-lit-html-templates| Rendering Lit HTML Templates}
     */
    export const render: {
        (value: unknown, container: HTMLElement | DocumentFragment, options?: RenderOptions): RootPart;
        setSanitizer: (newSanitizer: SanitizerFactory) => void;
        createSanitizer: SanitizerFactory;
        _testOnlyClearSanitizerFactoryDoNotCallOrElse: () => void;
    };
}
declare module "../l2/asyncDirective" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Overview:
     *
     * This module is designed to add support for an async `setValue` API and
     * `disconnected` callback to directives with the least impact on the core
     * runtime or payload when that feature is not used.
     *
     * The strategy is to introduce a `AsyncDirective` subclass of
     * `Directive` that climbs the "parent" tree in its constructor to note which
     * branches of lit-html's "logical tree" of data structures contain such
     * directives and thus need to be crawled when a subtree is being cleared (or
     * manually disconnected) in order to run the `disconnected` callback.
     *
     * The "nodes" of the logical tree include Parts, TemplateInstances (for when a
     * TemplateResult is committed to a value of a ChildPart), and Directives; these
     * all implement a common interface called `DisconnectableChild`. Each has a
     * `_$parent` reference which is set during construction in the core code, and a
     * `_$disconnectableChildren` field which is initially undefined.
     *
     * The sparse tree created by means of the `AsyncDirective` constructor
     * crawling up the `_$parent` tree and placing a `_$disconnectableChildren` Set
     * on each parent that includes each child that contains a
     * `AsyncDirective` directly or transitively via its children. In order to
     * notify connection state changes and disconnect (or reconnect) a tree, the
     * `_$notifyConnectionChanged` API is patched onto ChildParts as a directive
     * climbs the parent tree, which is called by the core when clearing a part if
     * it exists. When called, that method iterates over the sparse tree of
     * Set<DisconnectableChildren> built up by AsyncDirectives, and calls
     * `_$notifyDirectiveConnectionChanged` on any directives that are encountered
     * in that tree, running the required callbacks.
     *
     * A given "logical tree" of lit-html data-structures might look like this:
     *
     *  ChildPart(N1) _$dC=[D2,T3]
     *   ._directive
     *     AsyncDirective(D2)
     *   ._value // user value was TemplateResult
     *     TemplateInstance(T3) _$dC=[A4,A6,N10,N12]
     *      ._$parts[]
     *        AttributePart(A4) _$dC=[D5]
     *         ._directives[]
     *           AsyncDirective(D5)
     *        AttributePart(A6) _$dC=[D7,D8]
     *         ._directives[]
     *           AsyncDirective(D7)
     *           Directive(D8) _$dC=[D9]
     *            ._directive
     *              AsyncDirective(D9)
     *        ChildPart(N10) _$dC=[D11]
     *         ._directive
     *           AsyncDirective(D11)
     *         ._value
     *           string
     *        ChildPart(N12) _$dC=[D13,N14,N16]
     *         ._directive
     *           AsyncDirective(D13)
     *         ._value // user value was iterable
     *           Array<ChildPart>
     *             ChildPart(N14) _$dC=[D15]
     *              ._value
     *                string
     *             ChildPart(N16) _$dC=[D17,T18]
     *              ._directive
     *                AsyncDirective(D17)
     *              ._value // user value was TemplateResult
     *                TemplateInstance(T18) _$dC=[A19,A21,N25]
     *                 ._$parts[]
     *                   AttributePart(A19) _$dC=[D20]
     *                    ._directives[]
     *                      AsyncDirective(D20)
     *                   AttributePart(A21) _$dC=[22,23]
     *                    ._directives[]
     *                      AsyncDirective(D22)
     *                      Directive(D23) _$dC=[D24]
     *                       ._directive
     *                         AsyncDirective(D24)
     *                   ChildPart(N25) _$dC=[D26]
     *                    ._directive
     *                      AsyncDirective(D26)
     *                    ._value
     *                      string
     *
     * Example 1: The directive in ChildPart(N12) updates and returns `nothing`. The
     * ChildPart will _clear() itself, and so we need to disconnect the "value" of
     * the ChildPart (but not its directive). In this case, when `_clear()` calls
     * `_$notifyConnectionChanged()`, we don't iterate all of the
     * _$disconnectableChildren, rather we do a value-specific disconnection: i.e.
     * since the _value was an Array<ChildPart> (because an iterable had been
     * committed), we iterate the array of ChildParts (N14, N16) and run
     * `setConnected` on them (which does recurse down the full tree of
     * `_$disconnectableChildren` below it, and also removes N14 and N16 from N12's
     * `_$disconnectableChildren`). Once the values have been disconnected, we then
     * check whether the ChildPart(N12)'s list of `_$disconnectableChildren` is empty
     * (and would remove it from its parent TemplateInstance(T3) if so), but since
     * it would still contain its directive D13, it stays in the disconnectable
     * tree.
     *
     * Example 2: In the course of Example 1, `setConnected` will reach
     * ChildPart(N16); in this case the entire part is being disconnected, so we
     * simply iterate all of N16's `_$disconnectableChildren` (D17,T18) and
     * recursively run `setConnected` on them. Note that we only remove children
     * from `_$disconnectableChildren` for the top-level values being disconnected
     * on a clear; doing this bookkeeping lower in the tree is wasteful since it's
     * all being thrown away.
     *
     * Example 3: If the LitElement containing the entire tree above becomes
     * disconnected, it will run `childPart.setConnected()` (which calls
     * `childPart._$notifyConnectionChanged()` if it exists); in this case, we
     * recursively run `setConnected()` over the entire tree, without removing any
     * children from `_$disconnectableChildren`, since this tree is required to
     * re-connect the tree, which does the same operation, simply passing
     * `isConnected: true` down the tree, signaling which callback to run.
     */
    import { Disconnectable, Part } from '_102027_/l2/litHtml';
    import { Directive } from '_102027_/l2/directive';
    export * from '_102027_/l2/directive';
    /**
     * An abstract `Directive` base class whose `disconnected` method will be
     * called when the part containing the directive is cleared as a result of
     * re-rendering, or when the user calls `part.setConnected(false)` on
     * a part that was previously rendered containing the directive (as happens
     * when e.g. a LitElement disconnects from the DOM).
     *
     * If `part.setConnected(true)` is subsequently called on a
     * containing part, the directive's `reconnected` method will be called prior
     * to its next `update`/`render` callbacks. When implementing `disconnected`,
     * `reconnected` should also be implemented to be compatible with reconnection.
     *
     * Note that updates may occur while the directive is disconnected. As such,
     * directives should generally check the `this.isConnected` flag during
     * render/update to determine whether it is safe to subscribe to resources
     * that may prevent garbage collection.
     */
    export abstract class AsyncDirective extends Directive {
        /**
         * The connection state for this Directive.
         */
        isConnected: boolean;
        /**
         * Initialize the part with internal fields
         * @param part
         * @param parent
         * @param attributeIndex
         */
        _$initialize(part: Part, parent: Disconnectable, attributeIndex: number | undefined): void;
        /**
         * Sets the value of the directive's Part outside the normal `update`/`render`
         * lifecycle of a directive.
         *
         * This method should not be called synchronously from a directive's `update`
         * or `render`.
         *
         * @param directive The directive to update
         * @param value The value to set
         */
        setValue(value: unknown): void;
        /**
         * User callbacks for implementing logic to release any resources/subscriptions
         * that may have been retained by this directive. Since directives may also be
         * re-connected, `reconnected` should also be implemented to restore the
         * working state of the directive prior to the next render.
         */
        protected disconnected(): void;
        protected reconnected(): void;
    }
}
declare module "../l2/asyncReplace" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart } from '_102027_/l2/litHtml';
    import { AsyncDirective, DirectiveParameters } from '_102027_/l2/asyncDirective';
    type Mapper<T> = (v: T, index?: number) => unknown;
    export class AsyncReplaceDirective extends AsyncDirective {
        private __value?;
        private __weakThis;
        private __pauser;
        render<T>(value: AsyncIterable<T>, _mapper?: Mapper<T>): symbol;
        update(_part: ChildPart, [value, mapper]: DirectiveParameters<this>): symbol;
        protected commitValue(value: unknown, _index: number): void;
        disconnected(): void;
        reconnected(): void;
    }
    /**
     * A directive that renders the items of an async iterable[1], replacing
     * previous values with new values, so that only one value is ever rendered
     * at a time. This directive may be used in any expression type.
     *
     * Async iterables are objects with a `[Symbol.asyncIterator]` method, which
     * returns an iterator who's `next()` method returns a Promise. When a new
     * value is available, the Promise resolves and the value is rendered to the
     * Part controlled by the directive. If another value other than this
     * directive has been set on the Part, the iterable will no longer be listened
     * to and new values won't be written to the Part.
     *
     * [1]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for-await...of
     *
     * @param value An async iterable
     * @param mapper An optional function that maps from (value, index) to another
     *     value. Useful for generating templates for each item in the iterable.
     */
    export const asyncReplace: (value: AsyncIterable<unknown>, _mapper?: Mapper<unknown> | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof AsyncReplaceDirective>;
    export {};
}
declare module "_102027_/l2/asyncAppend" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart } from '_102027_/l2/litHtml';
    import { DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    import { AsyncReplaceDirective } from '_102027_/l2/asyncReplace';
    class AsyncAppendDirective extends AsyncReplaceDirective {
        private __childPart;
        constructor(partInfo: PartInfo);
        update(part: ChildPart, params: DirectiveParameters<this>): symbol;
        protected commitValue(value: unknown, index: number): void;
    }
    /**
     * A directive that renders the items of an async iterable[1], appending new
     * values after previous values, similar to the built-in support for iterables.
     * This directive is usable only in child expressions.
     *
     * Async iterables are objects with a [Symbol.asyncIterator] method, which
     * returns an iterator who's `next()` method returns a Promise. When a new
     * value is available, the Promise resolves and the value is appended to the
     * Part controlled by the directive. If another value other than this
     * directive has been set on the Part, the iterable will no longer be listened
     * to and new values won't be written to the Part.
     *
     * [1]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for-await...of
     *
     * @param value An async iterable
     * @param mapper An optional function that maps from (value, index) to another
     *     value. Useful for generating templates for each item in the iterable.
     */
    export const asyncAppend: (value: AsyncIterable<unknown>, _mapper?: ((v: unknown, index?: number) => unknown) | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof AsyncAppendDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { AsyncAppendDirective };
}
declare module "_102027_/l2/asyncDirective" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Overview:
     *
     * This module is designed to add support for an async `setValue` API and
     * `disconnected` callback to directives with the least impact on the core
     * runtime or payload when that feature is not used.
     *
     * The strategy is to introduce a `AsyncDirective` subclass of
     * `Directive` that climbs the "parent" tree in its constructor to note which
     * branches of lit-html's "logical tree" of data structures contain such
     * directives and thus need to be crawled when a subtree is being cleared (or
     * manually disconnected) in order to run the `disconnected` callback.
     *
     * The "nodes" of the logical tree include Parts, TemplateInstances (for when a
     * TemplateResult is committed to a value of a ChildPart), and Directives; these
     * all implement a common interface called `DisconnectableChild`. Each has a
     * `_$parent` reference which is set during construction in the core code, and a
     * `_$disconnectableChildren` field which is initially undefined.
     *
     * The sparse tree created by means of the `AsyncDirective` constructor
     * crawling up the `_$parent` tree and placing a `_$disconnectableChildren` Set
     * on each parent that includes each child that contains a
     * `AsyncDirective` directly or transitively via its children. In order to
     * notify connection state changes and disconnect (or reconnect) a tree, the
     * `_$notifyConnectionChanged` API is patched onto ChildParts as a directive
     * climbs the parent tree, which is called by the core when clearing a part if
     * it exists. When called, that method iterates over the sparse tree of
     * Set<DisconnectableChildren> built up by AsyncDirectives, and calls
     * `_$notifyDirectiveConnectionChanged` on any directives that are encountered
     * in that tree, running the required callbacks.
     *
     * A given "logical tree" of lit-html data-structures might look like this:
     *
     *  ChildPart(N1) _$dC=[D2,T3]
     *   ._directive
     *     AsyncDirective(D2)
     *   ._value // user value was TemplateResult
     *     TemplateInstance(T3) _$dC=[A4,A6,N10,N12]
     *      ._$parts[]
     *        AttributePart(A4) _$dC=[D5]
     *         ._directives[]
     *           AsyncDirective(D5)
     *        AttributePart(A6) _$dC=[D7,D8]
     *         ._directives[]
     *           AsyncDirective(D7)
     *           Directive(D8) _$dC=[D9]
     *            ._directive
     *              AsyncDirective(D9)
     *        ChildPart(N10) _$dC=[D11]
     *         ._directive
     *           AsyncDirective(D11)
     *         ._value
     *           string
     *        ChildPart(N12) _$dC=[D13,N14,N16]
     *         ._directive
     *           AsyncDirective(D13)
     *         ._value // user value was iterable
     *           Array<ChildPart>
     *             ChildPart(N14) _$dC=[D15]
     *              ._value
     *                string
     *             ChildPart(N16) _$dC=[D17,T18]
     *              ._directive
     *                AsyncDirective(D17)
     *              ._value // user value was TemplateResult
     *                TemplateInstance(T18) _$dC=[A19,A21,N25]
     *                 ._$parts[]
     *                   AttributePart(A19) _$dC=[D20]
     *                    ._directives[]
     *                      AsyncDirective(D20)
     *                   AttributePart(A21) _$dC=[22,23]
     *                    ._directives[]
     *                      AsyncDirective(D22)
     *                      Directive(D23) _$dC=[D24]
     *                       ._directive
     *                         AsyncDirective(D24)
     *                   ChildPart(N25) _$dC=[D26]
     *                    ._directive
     *                      AsyncDirective(D26)
     *                    ._value
     *                      string
     *
     * Example 1: The directive in ChildPart(N12) updates and returns `nothing`. The
     * ChildPart will _clear() itself, and so we need to disconnect the "value" of
     * the ChildPart (but not its directive). In this case, when `_clear()` calls
     * `_$notifyConnectionChanged()`, we don't iterate all of the
     * _$disconnectableChildren, rather we do a value-specific disconnection: i.e.
     * since the _value was an Array<ChildPart> (because an iterable had been
     * committed), we iterate the array of ChildParts (N14, N16) and run
     * `setConnected` on them (which does recurse down the full tree of
     * `_$disconnectableChildren` below it, and also removes N14 and N16 from N12's
     * `_$disconnectableChildren`). Once the values have been disconnected, we then
     * check whether the ChildPart(N12)'s list of `_$disconnectableChildren` is empty
     * (and would remove it from its parent TemplateInstance(T3) if so), but since
     * it would still contain its directive D13, it stays in the disconnectable
     * tree.
     *
     * Example 2: In the course of Example 1, `setConnected` will reach
     * ChildPart(N16); in this case the entire part is being disconnected, so we
     * simply iterate all of N16's `_$disconnectableChildren` (D17,T18) and
     * recursively run `setConnected` on them. Note that we only remove children
     * from `_$disconnectableChildren` for the top-level values being disconnected
     * on a clear; doing this bookkeeping lower in the tree is wasteful since it's
     * all being thrown away.
     *
     * Example 3: If the LitElement containing the entire tree above becomes
     * disconnected, it will run `childPart.setConnected()` (which calls
     * `childPart._$notifyConnectionChanged()` if it exists); in this case, we
     * recursively run `setConnected()` over the entire tree, without removing any
     * children from `_$disconnectableChildren`, since this tree is required to
     * re-connect the tree, which does the same operation, simply passing
     * `isConnected: true` down the tree, signaling which callback to run.
     */
    import { Disconnectable, Part } from '_102027_/l2/litHtml';
    import { Directive } from '_102027_/l2/directive';
    export * from '_102027_/l2/directive';
    /**
     * An abstract `Directive` base class whose `disconnected` method will be
     * called when the part containing the directive is cleared as a result of
     * re-rendering, or when the user calls `part.setConnected(false)` on
     * a part that was previously rendered containing the directive (as happens
     * when e.g. a LitElement disconnects from the DOM).
     *
     * If `part.setConnected(true)` is subsequently called on a
     * containing part, the directive's `reconnected` method will be called prior
     * to its next `update`/`render` callbacks. When implementing `disconnected`,
     * `reconnected` should also be implemented to be compatible with reconnection.
     *
     * Note that updates may occur while the directive is disconnected. As such,
     * directives should generally check the `this.isConnected` flag during
     * render/update to determine whether it is safe to subscribe to resources
     * that may prevent garbage collection.
     */
    export abstract class AsyncDirective extends Directive {
        /**
         * The connection state for this Directive.
         */
        isConnected: boolean;
        /**
         * Initialize the part with internal fields
         * @param part
         * @param parent
         * @param attributeIndex
         */
        _$initialize(part: Part, parent: Disconnectable, attributeIndex: number | undefined): void;
        /**
         * Sets the value of the directive's Part outside the normal `update`/`render`
         * lifecycle of a directive.
         *
         * This method should not be called synchronously from a directive's `update`
         * or `render`.
         *
         * @param directive The directive to update
         * @param value The value to set
         */
        setValue(value: unknown): void;
        /**
         * User callbacks for implementing logic to release any resources/subscriptions
         * that may have been retained by this directive. Since directives may also be
         * re-connected, `reconnected` should also be implemented to restore the
         * working state of the directive prior to the next render.
         */
        protected disconnected(): void;
        protected reconnected(): void;
    }
}
declare module "_102027_/l2/asyncReplace" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart } from '_102027_/l2/litHtml';
    import { AsyncDirective, DirectiveParameters } from '_102027_/l2/asyncDirective';
    type Mapper<T> = (v: T, index?: number) => unknown;
    export class AsyncReplaceDirective extends AsyncDirective {
        private __value?;
        private __weakThis;
        private __pauser;
        render<T>(value: AsyncIterable<T>, _mapper?: Mapper<T>): symbol;
        update(_part: ChildPart, [value, mapper]: DirectiveParameters<this>): symbol;
        protected commitValue(value: unknown, _index: number): void;
        disconnected(): void;
        reconnected(): void;
    }
    /**
     * A directive that renders the items of an async iterable[1], replacing
     * previous values with new values, so that only one value is ever rendered
     * at a time. This directive may be used in any expression type.
     *
     * Async iterables are objects with a `[Symbol.asyncIterator]` method, which
     * returns an iterator who's `next()` method returns a Promise. When a new
     * value is available, the Promise resolves and the value is rendered to the
     * Part controlled by the directive. If another value other than this
     * directive has been set on the Part, the iterable will no longer be listened
     * to and new values won't be written to the Part.
     *
     * [1]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for-await...of
     *
     * @param value An async iterable
     * @param mapper An optional function that maps from (value, index) to another
     *     value. Useful for generating templates for each item in the iterable.
     */
    export const asyncReplace: (value: AsyncIterable<unknown>, _mapper?: Mapper<unknown> | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof AsyncReplaceDirective>;
    export {};
}
declare module "_102027_/l2/base" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Generates a public interface type that removes private and protected fields.
     * This allows accepting otherwise incompatible versions of the type (e.g. from
     * multiple copies of the same package in `node_modules`).
     */
    export type Interface<T> = {
        [K in keyof T]: T[K];
    };
    export type Constructor<T> = {
        new (...args: any[]): T;
    };
}
declare module "_102027_/l2/cache" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    class CacheDirective extends Directive {
        private _templateCache;
        private _value?;
        constructor(partInfo: PartInfo);
        render(v: unknown): unknown[];
        update(containerPart: ChildPart, [v]: DirectiveParameters<this>): unknown[];
    }
    /**
     * Enables fast switching between multiple templates by caching the DOM nodes
     * and TemplateInstances produced by the templates.
     *
     * Example:
     *
     * ```js
     * let checked = false;
     *
     * html`
     *   ${cache(checked ? html`input is checked` : html`input is not checked`)}
     * `
     * ```
     */
    export const cache: (v: unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof CacheDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { CacheDirective };
}
declare module "_102027_/l2/choose" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Chooses and evaluates a template function from a list based on matching
     * the given `value` to a case.
     *
     * Cases are structured as `[caseValue, func]`. `value` is matched to
     * `caseValue` by strict equality. The first match is selected. Case values
     * can be of any type including primitives, objects, and symbols.
     *
     * This is similar to a switch statement, but as an expression and without
     * fallthrough.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${choose(this.section, [
     *       ['home', () => html`<h1>Home</h1>`],
     *       ['about', () => html`<h1>About</h1>`]
     *     ],
     *     () => html`<h1>Error</h1>`)}
     *   `;
     * }
     * ```
     */
    export const choose: <T, V, K extends T = T>(value: T, cases: Array<[K, () => V]>, defaultCase?: () => V) => V | undefined;
}
declare module "_102027_/l2/classMap" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart, noChange } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    /**
     * A key-value set of class names to truthy values.
     */
    export interface ClassInfo {
        readonly [name: string]: string | boolean | number;
    }
    class ClassMapDirective extends Directive {
        /**
         * Stores the ClassInfo object applied to a given AttributePart.
         * Used to unset existing values when a new ClassInfo object is applied.
         */
        private _previousClasses?;
        private _staticClasses?;
        constructor(partInfo: PartInfo);
        render(classInfo: ClassInfo): string;
        update(part: AttributePart, [classInfo]: DirectiveParameters<this>): string | typeof noChange;
    }
    /**
     * A directive that applies dynamic CSS classes.
     *
     * This must be used in the `class` attribute and must be the only part used in
     * the attribute. It takes each property in the `classInfo` argument and adds
     * the property name to the element's `classList` if the property value is
     * truthy; if the property value is falsy, the property name is removed from
     * the element's `class`.
     *
     * For example `{foo: bar}` applies the class `foo` if the value of `bar` is
     * truthy.
     *
     * @param classInfo
     */
    export const classMap: (classInfo: ClassInfo) => import("/_102027_/l2/directive.js").DirectiveResult<typeof ClassMapDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { ClassMapDirective };
}
declare module "../l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102027_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "../l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/collabLanguages" {
    export const languages: ICollabLanguage[];
    export interface ICollabLanguage {
        code: string;
        name: string;
        country: string;
        svg: string;
    }
    /**
     * Resolves a language entry by BCP 47 code.
     * Tries an exact (case-insensitive) match first — e.g. "pt-BR" —
     * then falls back to the base language — e.g. "pt-AO" -> "pt".
     */
    export function findLanguageByCode(code: string): ICollabLanguage | undefined;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102027_/l2/collabMonacoEditor" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMonacoEditor extends StateLitElement {
        msize: string;
        mlsEditor: any;
        get isMls2(): boolean;
        render(): any;
        updated(changed: Map<PropertyKey, unknown>): void;
        private _onMsizeChange;
    }
}
declare module "../l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "_102027_/l2/collabSelectKnob" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class SelectOneKnobWidget extends StateLitElement {
        min: number;
        max: number;
        value: number | null;
        step: number;
        disabled: boolean;
        active: boolean;
        selected: boolean;
        showTicks: boolean;
        private _focused;
        private _editing;
        private _dragStartY;
        private _dragStartValue;
        private _dragging;
        private _pendingDigit;
        private _digitTimeout;
        private _pendingDisplay;
        private _pendingInvalid;
        private get _hasValue();
        private get _rotation();
        private get _tickCount();
        private get _displayValue();
        private get _displayHidden();
        private get _canInteract();
        private _clamp;
        private _setValue;
        private _cycleValue;
        private _onKeyDown;
        private _cancelDigitInput;
        private _onMouseDown;
        private _onWheel;
        private _onFocus;
        private _onBlur;
        private _onDisplayClick;
        private _onClick;
        private _renderTicks;
        render(): any;
    }
}
declare module "_102027_/l2/collabSpliterHorizontalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterHorizontalVarFixed102027 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement[] | undefined;
        slotRight: HTMLElement[] | undefined;
        private collab_chevron_right;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        resizeItens(): void;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): any;
        private styles;
    }
}
declare module "_102027_/l2/collabSpliterVerticalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterVerticalVarFixed extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        private collab_chevron_down;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        updatePanelsMSize(): void;
        private forceRefreshMsize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        timeoutResize: number | undefined;
        _distributeContent(): void;
        render(): any;
        private styles;
    }
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/cssTag" {
    /**
     * @license
     * Copyright 2019 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Whether the current browser supports `adoptedStyleSheets`.
     */
    export const supportsAdoptingStyleSheets: boolean;
    /**
     * A CSSResult or native CSSStyleSheet.
     *
     * In browsers that support constructible CSS style sheets, CSSStyleSheet
     * object can be used for styling along side CSSResult from the `css`
     * template tag.
     */
    export type CSSResultOrNative = CSSResult | CSSStyleSheet;
    export type CSSResultArray = Array<CSSResultOrNative | CSSResultArray>;
    /**
     * A single CSSResult, CSSStyleSheet, or an array or nested arrays of those.
     */
    export type CSSResultGroup = CSSResultOrNative | CSSResultArray;
    /**
     * A container for a string of CSS text, that may be used to create a CSSStyleSheet.
     *
     * CSSResult is the return value of `css`-tagged template literals and
     * `unsafeCSS()`. In order to ensure that CSSResults are only created via the
     * `css` tag and `unsafeCSS()`, CSSResult cannot be constructed directly.
     */
    export class CSSResult {
        ['_$cssResult$']: boolean;
        readonly cssText: string;
        private _styleSheet?;
        private _strings;
        private constructor();
        get styleSheet(): CSSStyleSheet | undefined;
        toString(): string;
    }
    /**
     * Wrap a value for interpolation in a {@linkcode css} tagged template literal.
     *
     * This is unsafe because untrusted CSS text can be used to phone home
     * or exfiltrate data to an attacker controlled site. Take care to only use
     * this with trusted input.
     */
    export const unsafeCSS: (value: unknown) => CSSResult;
    /**
     * A template literal tag which can be used with LitElement's
     * {@linkcode LitElement.styles} property to set element styles.
     *
     * For security reasons, only literal string values and number may be used in
     * embedded expressions. To incorporate non-literal values {@linkcode unsafeCSS}
     * may be used inside an expression.
     */
    export const css: (strings: TemplateStringsArray, ...values: (CSSResultGroup | number)[]) => CSSResult;
    /**
     * Applies the given styles to a `shadowRoot`. When Shadow DOM is
     * available but `adoptedStyleSheets` is not, styles are appended to the
     * `shadowRoot` to [mimic the native feature](https://developer.mozilla.org/en-US/docs/Web/API/ShadowRoot/adoptedStyleSheets).
     * Note, when shimming is used, any styles that are subsequently placed into
     * the shadowRoot should be placed *before* any shimmed adopted styles. This
     * will match spec behavior that gives adopted sheets precedence over styles in
     * shadowRoot.
     */
    export const adoptStyles: (renderRoot: ShadowRoot, styles: Array<CSSResultOrNative>) => void;
    export const getCompatibleStyle: (s: CSSResultOrNative) => CSSResultOrNative;
}
declare module "../l2/base" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Generates a public interface type that removes private and protected fields.
     * This allows accepting otherwise incompatible versions of the type (e.g. from
     * multiple copies of the same package in `node_modules`).
     */
    export type Interface<T> = {
        [K in keyof T]: T[K];
    };
    export type Constructor<T> = {
        new (...args: any[]): T;
    };
}
declare module "_102027_/l2/customElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { Constructor } from '_102027_/l2/base';
    /**
     * Allow for custom element classes with private constructors
     */
    type CustomElementClass = Omit<typeof HTMLElement, 'new'>;
    export type CustomElementDecorator = {
        (cls: CustomElementClass): void;
        (target: CustomElementClass, context: ClassDecoratorContext<Constructor<HTMLElement>>): void;
    };
    /**
     * Class decorator factory that defines the decorated class as a custom element.
     *
     * ```js
     * @customElement('my-element')
     * class MyElement extends LitElement {
     *   render() {
     *     return html``;
     *   }
     * }
     * ```
     * @category Decorator
     * @param tagName The tag name of the custom element to define.
     */
    export const customElement: (tagName: string) => CustomElementDecorator;
    export {};
}
declare module "../l2/customElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { Constructor } from '_102027_/l2/base';
    /**
     * Allow for custom element classes with private constructors
     */
    type CustomElementClass = Omit<typeof HTMLElement, 'new'>;
    export type CustomElementDecorator = {
        (cls: CustomElementClass): void;
        (target: CustomElementClass, context: ClassDecoratorContext<Constructor<HTMLElement>>): void;
    };
    /**
     * Class decorator factory that defines the decorated class as a custom element.
     *
     * ```js
     * @customElement('my-element')
     * class MyElement extends LitElement {
     *   render() {
     *     return html``;
     *   }
     * }
     * ```
     * @category Decorator
     * @param tagName The tag name of the custom element to define.
     */
    export const customElement: (tagName: string) => CustomElementDecorator;
    export {};
}
declare module "../l2/cssTag" {
    /**
     * @license
     * Copyright 2019 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Whether the current browser supports `adoptedStyleSheets`.
     */
    export const supportsAdoptingStyleSheets: boolean;
    /**
     * A CSSResult or native CSSStyleSheet.
     *
     * In browsers that support constructible CSS style sheets, CSSStyleSheet
     * object can be used for styling along side CSSResult from the `css`
     * template tag.
     */
    export type CSSResultOrNative = CSSResult | CSSStyleSheet;
    export type CSSResultArray = Array<CSSResultOrNative | CSSResultArray>;
    /**
     * A single CSSResult, CSSStyleSheet, or an array or nested arrays of those.
     */
    export type CSSResultGroup = CSSResultOrNative | CSSResultArray;
    /**
     * A container for a string of CSS text, that may be used to create a CSSStyleSheet.
     *
     * CSSResult is the return value of `css`-tagged template literals and
     * `unsafeCSS()`. In order to ensure that CSSResults are only created via the
     * `css` tag and `unsafeCSS()`, CSSResult cannot be constructed directly.
     */
    export class CSSResult {
        ['_$cssResult$']: boolean;
        readonly cssText: string;
        private _styleSheet?;
        private _strings;
        private constructor();
        get styleSheet(): CSSStyleSheet | undefined;
        toString(): string;
    }
    /**
     * Wrap a value for interpolation in a {@linkcode css} tagged template literal.
     *
     * This is unsafe because untrusted CSS text can be used to phone home
     * or exfiltrate data to an attacker controlled site. Take care to only use
     * this with trusted input.
     */
    export const unsafeCSS: (value: unknown) => CSSResult;
    /**
     * A template literal tag which can be used with LitElement's
     * {@linkcode LitElement.styles} property to set element styles.
     *
     * For security reasons, only literal string values and number may be used in
     * embedded expressions. To incorporate non-literal values {@linkcode unsafeCSS}
     * may be used inside an expression.
     */
    export const css: (strings: TemplateStringsArray, ...values: (CSSResultGroup | number)[]) => CSSResult;
    /**
     * Applies the given styles to a `shadowRoot`. When Shadow DOM is
     * available but `adoptedStyleSheets` is not, styles are appended to the
     * `shadowRoot` to [mimic the native feature](https://developer.mozilla.org/en-US/docs/Web/API/ShadowRoot/adoptedStyleSheets).
     * Note, when shimming is used, any styles that are subsequently placed into
     * the shadowRoot should be placed *before* any shimmed adopted styles. This
     * will match spec behavior that gives adopted sheets precedence over styles in
     * shadowRoot.
     */
    export const adoptStyles: (renderRoot: ShadowRoot, styles: Array<CSSResultOrNative>) => void;
    export const getCompatibleStyle: (s: CSSResultOrNative) => CSSResultOrNative;
}
declare module "../l2/reactiveController" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * An object that can host Reactive Controllers and call their lifecycle
     * callbacks.
     */
    export interface ReactiveControllerHost {
        /**
         * Adds a controller to the host, which sets up the controller's lifecycle
         * methods to be called with the host's lifecycle.
         */
        addController(controller: ReactiveController): void;
        /**
         * Removes a controller from the host.
         */
        removeController(controller: ReactiveController): void;
        /**
         * Requests a host update which is processed asynchronously. The update can
         * be waited on via the `updateComplete` property.
         */
        requestUpdate(): void;
        /**
         * Returns a Promise that resolves when the host has completed updating.
         * The Promise value is a boolean that is `true` if the element completed the
         * update without triggering another update. The Promise result is `false` if
         * a property was set inside `updated()`. If the Promise is rejected, an
         * exception was thrown during the update.
         *
         * @return A promise of a boolean that indicates if the update resolved
         *     without triggering another update.
         */
        readonly updateComplete: Promise<boolean>;
    }
    /**
     * A Reactive Controller is an object that enables sub-component code
     * organization and reuse by aggregating the state, behavior, and lifecycle
     * hooks related to a single feature.
     *
     * Controllers are added to a host component, or other object that implements
     * the `ReactiveControllerHost` interface, via the `addController()` method.
     * They can hook their host components's lifecycle by implementing one or more
     * of the lifecycle callbacks, or initiate an update of the host component by
     * calling `requestUpdate()` on the host.
     */
    export interface ReactiveController {
        /**
         * Called when the host is connected to the component tree. For custom
         * element hosts, this corresponds to the `connectedCallback()` lifecycle,
         * which is only called when the component is connected to the document.
         */
        hostConnected?(): void;
        /**
         * Called when the host is disconnected from the component tree. For custom
         * element hosts, this corresponds to the `disconnectedCallback()` lifecycle,
         * which is called the host or an ancestor component is disconnected from the
         * document.
         */
        hostDisconnected?(): void;
        /**
         * Called during the client-side host update, just before the host calls
         * its own update.
         *
         * Code in `update()` can depend on the DOM as it is not called in
         * server-side rendering.
         */
        hostUpdate?(): void;
        /**
         * Called after a host update, just before the host calls firstUpdated and
         * updated. It is not called in server-side rendering.
         *
         */
        hostUpdated?(): void;
    }
}
declare module "../l2/reactiveElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Use this module if you want to create your own base class extending
     * {@link ReactiveElement}.
     * @packageDocumentation
     */
    import { CSSResultGroup, CSSResultOrNative } from '_102027_/l2/cssTag';
    import type { ReactiveController, ReactiveControllerHost } from '_102027_/l2/reactiveController';
    export * from '_102027_/l2/cssTag';
    export type { ReactiveController, ReactiveControllerHost, } from '_102027_/l2/reactiveController';
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace ReactiveUnstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = Update;
            interface Update {
                kind: 'update';
            }
        }
    }
    /**
     * Converts property values to and from attribute values.
     */
    export interface ComplexAttributeConverter<Type = unknown, TypeHint = unknown> {
        /**
         * Called to convert an attribute value to a property
         * value.
         */
        fromAttribute?(value: string | null, type?: TypeHint): Type;
        /**
         * Called to convert a property value to an attribute
         * value.
         *
         * It returns unknown instead of string, to be compatible with
         * https://github.com/WICG/trusted-types (and similar efforts).
         */
        toAttribute?(value: Type, type?: TypeHint): unknown;
    }
    type AttributeConverter<Type = unknown, TypeHint = unknown> = ComplexAttributeConverter<Type> | ((value: string | null, type?: TypeHint) => Type);
    /**
     * Defines options for a property accessor.
     */
    export interface PropertyDeclaration<Type = unknown, TypeHint = unknown> {
        /**
         * When set to `true`, indicates the property is internal private state. The
         * property should not be set by users. When using TypeScript, this property
         * should be marked as `private` or `protected`, and it is also a common
         * practice to use a leading `_` in the name. The property is not added to
         * `observedAttributes`.
         */
        readonly state?: boolean;
        /**
         * Indicates how and whether the property becomes an observed attribute.
         * If the value is `false`, the property is not added to `observedAttributes`.
         * If true or absent, the lowercased property name is observed (e.g. `fooBar`
         * becomes `foobar`). If a string, the string value is observed (e.g
         * `attribute: 'foo-bar'`).
         */
        readonly attribute?: boolean | string;
        /**
         * Indicates the type of the property. This is used only as a hint for the
         * `converter` to determine how to convert the attribute
         * to/from a property.
         */
        readonly type?: TypeHint;
        /**
         * Indicates how to convert the attribute to/from a property. If this value
         * is a function, it is used to convert the attribute value a the property
         * value. If it's an object, it can have keys for `fromAttribute` and
         * `toAttribute`. If no `toAttribute` function is provided and
         * `reflect` is set to `true`, the property value is set directly to the
         * attribute. A default `converter` is used if none is provided; it supports
         * `Boolean`, `String`, `Number`, `Object`, and `Array`. Note,
         * when a property changes and the converter is used to update the attribute,
         * the property is never updated again as a result of the attribute changing,
         * and vice versa.
         */
        readonly converter?: AttributeConverter<Type, TypeHint>;
        /**
         * Indicates if the property should reflect to an attribute.
         * If `true`, when the property is set, the attribute is set using the
         * attribute name determined according to the rules for the `attribute`
         * property option and the value of the property converted using the rules
         * from the `converter` property option.
         */
        readonly reflect?: boolean;
        /**
         * A function that indicates if a property should be considered changed when
         * it is set. The function should take the `newValue` and `oldValue` and
         * return `true` if an update should be requested.
         */
        hasChanged?(value: Type, oldValue: Type): boolean;
        /**
         * Indicates whether an accessor will be created for this property. By
         * default, an accessor will be generated for this property that requests an
         * update when set. If this flag is `true`, no accessor will be created, and
         * it will be the user's responsibility to call
         * `this.requestUpdate(propertyName, oldValue)` to request an update when
         * the property changes.
         */
        readonly noAccessor?: boolean;
        /**
         * When `true`, uses the initial value of the property as the default value,
         * which changes how attributes are handled:
         *  - The initial value does *not* reflect, even if the `reflect` option is `true`.
         *    Subsequent changes to the property will reflect, even if they are equal to the
         *     default value.
         *  - When the attribute is removed, the property is set to the default value
         *  - The initial value will not trigger an old value in the `changedProperties` map
         *    argument to update lifecycle methods.
         *
         * When set, properties must be initialized, either with a field initializer, or an
         * assignment in the constructor. Not initializing the property may lead to
         * improper handling of subsequent property assignments.
         *
         * While this behavior is opt-in, most properties that reflect to attributes should
         * use `useDefault: true` so that their initial values do not reflect.
         */
        useDefault?: boolean;
    }
    /**
     * Map of properties to PropertyDeclaration options. For each property an
     * accessor is made, and the property is processed according to the
     * PropertyDeclaration options.
     */
    export interface PropertyDeclarations {
        readonly [key: string]: PropertyDeclaration;
    }
    type PropertyDeclarationMap = Map<PropertyKey, PropertyDeclaration>;
    /**
     * A Map of property keys to values.
     *
     * Takes an optional type parameter T, which when specified as a non-any,
     * non-unknown type, will make the Map more strongly-typed, associating the map
     * keys with their corresponding value type on T.
     *
     * Use `PropertyValues<this>` when overriding ReactiveElement.update() and
     * other lifecycle methods in order to get stronger type-checking on keys
     * and values.
     */
    export type PropertyValues<T = any> = T extends object ? PropertyValueMap<T> : Map<PropertyKey, unknown>;
    /**
     * Do not use, instead prefer {@linkcode PropertyValues}.
     */
    export interface PropertyValueMap<T> extends Map<PropertyKey, unknown> {
        get<K extends keyof T>(k: K): T[K] | undefined;
        set<K extends keyof T>(key: K, value: T[K]): this;
        has<K extends keyof T>(k: K): boolean;
        delete<K extends keyof T>(k: K): boolean;
    }
    export const defaultConverter: ComplexAttributeConverter;
    export interface HasChanged {
        (value: unknown, old: unknown): boolean;
    }
    /**
     * Change function that returns true if `value` is different from `oldValue`.
     * This method is used as the default for a property's `hasChanged` function.
     */
    export const notEqual: HasChanged;
    /**
     * A string representing one of the supported dev mode warning categories.
     */
    export type WarningKind = 'change-in-update' | 'migration' | 'async-perform-update';
    export type Initializer = (element: ReactiveElement) => void;
    global {
        interface SymbolConstructor {
            readonly metadata: unique symbol;
        }
    }
    global {
        var litPropertyMetadata: WeakMap<object, Map<PropertyKey, PropertyDeclaration>>;
    }
    /**
     * Base element class which manages element properties and attributes. When
     * properties change, the `update` method is asynchronously called. This method
     * should be supplied by subclasses to render updates as desired.
     * @noInheritDoc
     */
    export abstract class ReactiveElement extends HTMLElement implements ReactiveControllerHost {
        /**
         * Read or set all the enabled warning categories for this class.
         *
         * This property is only used in development builds.
         *
         * @nocollapse
         * @category dev-mode
         */
        static enabledWarnings?: WarningKind[];
        /**
         * Enable the given warning category for this class.
         *
         * This method only exists in development builds, so it should be accessed
         * with a guard like:
         *
         * ```ts
         * // Enable for all ReactiveElement subclasses
         * ReactiveElement.enableWarning?.('migration');
         *
         * // Enable for only MyElement and subclasses
         * MyElement.enableWarning?.('migration');
         * ```
         *
         * @nocollapse
         * @category dev-mode
         */
        static enableWarning?: (warningKind: WarningKind) => void;
        /**
         * Disable the given warning category for this class.
         *
         * This method only exists in development builds, so it should be accessed
         * with a guard like:
         *
         * ```ts
         * // Disable for all ReactiveElement subclasses
         * ReactiveElement.disableWarning?.('migration');
         *
         * // Disable for only MyElement and subclasses
         * MyElement.disableWarning?.('migration');
         * ```
         *
         * @nocollapse
         * @category dev-mode
         */
        static disableWarning?: (warningKind: WarningKind) => void;
        /**
         * Adds an initializer function to the class that is called during instance
         * construction.
         *
         * This is useful for code that runs against a `ReactiveElement`
         * subclass, such as a decorator, that needs to do work for each
         * instance, such as setting up a `ReactiveController`.
         *
         * ```ts
         * const myDecorator = (target: typeof ReactiveElement, key: string) => {
         *   target.addInitializer((instance: ReactiveElement) => {
         *     // This is run during construction of the element
         *     new MyController(instance);
         *   });
         * }
         * ```
         *
         * Decorating a field will then cause each instance to run an initializer
         * that adds a controller:
         *
         * ```ts
         * class MyElement extends LitElement {
         *   @myDecorator foo;
         * }
         * ```
         *
         * Initializers are stored per-constructor. Adding an initializer to a
         * subclass does not add it to a superclass. Since initializers are run in
         * constructors, initializers will run in order of the class hierarchy,
         * starting with superclasses and progressing to the instance's class.
         *
         * @nocollapse
         */
        static addInitializer(initializer: Initializer): void;
        static _initializers?: Initializer[];
        /**
         * Maps attribute names to properties; for example `foobar` attribute to
         * `fooBar` property. Created lazily on user subclasses when finalizing the
         * class.
         * @nocollapse
         */
        private static __attributeToPropertyMap;
        /**
         * Marks class as having been finalized, which includes creating properties
         * from `static properties`, but does *not* include all properties created
         * from decorators.
         * @nocollapse
         */
        protected static finalized: true | undefined;
        /**
         * Memoized list of all element properties, including any superclass
         * properties. Created lazily on user subclasses when finalizing the class.
         *
         * @nocollapse
         * @category properties
         */
        static elementProperties: PropertyDeclarationMap;
        /**
         * User-supplied object that maps property names to `PropertyDeclaration`
         * objects containing options for configuring reactive properties. When
         * a reactive property is set the element will update and render.
         *
         * By default properties are public fields, and as such, they should be
         * considered as primarily settable by element users, either via attribute or
         * the property itself.
         *
         * Generally, properties that are changed by the element should be private or
         * protected fields and should use the `state: true` option. Properties
         * marked as `state` do not reflect from the corresponding attribute
         *
         * However, sometimes element code does need to set a public property. This
         * should typically only be done in response to user interaction, and an event
         * should be fired informing the user; for example, a checkbox sets its
         * `checked` property when clicked and fires a `changed` event. Mutating
         * public properties should typically not be done for non-primitive (object or
         * array) properties. In other cases when an element needs to manage state, a
         * private property set with the `state: true` option should be used. When
         * needed, state properties can be initialized via public properties to
         * facilitate complex interactions.
         * @nocollapse
         * @category properties
         */
        static properties: PropertyDeclarations;
        /**
         * Memoized list of all element styles.
         * Created lazily on user subclasses when finalizing the class.
         * @nocollapse
         * @category styles
         */
        static elementStyles: Array<CSSResultOrNative>;
        /**
         * Array of styles to apply to the element. The styles should be defined
         * using the {@linkcode css} tag function, via constructible stylesheets, or
         * imported from native CSS module scripts.
         *
         * Note on Content Security Policy:
         *
         * Element styles are implemented with `<style>` tags when the browser doesn't
         * support adopted StyleSheets. To use such `<style>` tags with the style-src
         * CSP directive, the style-src value must either include 'unsafe-inline' or
         * `nonce-<base64-value>` with `<base64-value>` replaced be a server-generated
         * nonce.
         *
         * To provide a nonce to use on generated `<style>` elements, set
         * `window.litNonce` to a server-generated nonce in your page's HTML, before
         * loading application code:
         *
         * ```html
         * <script>
         *   // Generated and unique per request:
         *   window.litNonce = 'a1b2c3d4';
         * </script>
         * ```
         * @nocollapse
         * @category styles
         */
        static styles?: CSSResultGroup;
        /**
         * Returns a list of attributes corresponding to the registered properties.
         * @nocollapse
         * @category attributes
         */
        static get observedAttributes(): string[];
        private __instanceProperties?;
        /**
         * Creates a property accessor on the element prototype if one does not exist
         * and stores a {@linkcode PropertyDeclaration} for the property with the
         * given options. The property setter calls the property's `hasChanged`
         * property option or uses a strict identity check to determine whether or not
         * to request an update.
         *
         * This method may be overridden to customize properties; however,
         * when doing so, it's important to call `super.createProperty` to ensure
         * the property is setup correctly. This method calls
         * `getPropertyDescriptor` internally to get a descriptor to install.
         * To customize what properties do when they are get or set, override
         * `getPropertyDescriptor`. To customize the options for a property,
         * implement `createProperty` like this:
         *
         * ```ts
         * static createProperty(name, options) {
         *   options = Object.assign(options, {myOption: true});
         *   super.createProperty(name, options);
         * }
         * ```
         *
         * @nocollapse
         * @category properties
         */
        static createProperty(name: PropertyKey, options?: PropertyDeclaration): void;
        /**
         * Returns a property descriptor to be defined on the given named property.
         * If no descriptor is returned, the property will not become an accessor.
         * For example,
         *
         * ```ts
         * class MyElement extends LitElement {
         *   static getPropertyDescriptor(name, key, options) {
         *     const defaultDescriptor =
         *         super.getPropertyDescriptor(name, key, options);
         *     const setter = defaultDescriptor.set;
         *     return {
         *       get: defaultDescriptor.get,
         *       set(value) {
         *         setter.call(this, value);
         *         // custom action.
         *       },
         *       configurable: true,
         *       enumerable: true
         *     }
         *   }
         * }
         * ```
         *
         * @nocollapse
         * @category properties
         */
        protected static getPropertyDescriptor(name: PropertyKey, key: string | symbol, options: PropertyDeclaration): PropertyDescriptor | undefined;
        /**
         * Returns the property options associated with the given property.
         * These options are defined with a `PropertyDeclaration` via the `properties`
         * object or the `@property` decorator and are registered in
         * `createProperty(...)`.
         *
         * Note, this method should be considered "final" and not overridden. To
         * customize the options for a given property, override
         * {@linkcode createProperty}.
         *
         * @nocollapse
         * @final
         * @category properties
         */
        static getPropertyOptions(name: PropertyKey): PropertyDeclaration<unknown, unknown>;
        static [Symbol.metadata]: object & Record<PropertyKey, unknown>;
        /**
         * Initializes static own properties of the class used in bookkeeping
         * for element properties, initializers, etc.
         *
         * Can be called multiple times by code that needs to ensure these
         * properties exist before using them.
         *
         * This method ensures the superclass is finalized so that inherited
         * property metadata can be copied down.
         * @nocollapse
         */
        private static __prepare;
        /**
         * Finishes setting up the class so that it's ready to be registered
         * as a custom element and instantiated.
         *
         * This method is called by the ReactiveElement.observedAttributes getter.
         * If you override the observedAttributes getter, you must either call
         * super.observedAttributes to trigger finalization, or call finalize()
         * yourself.
         *
         * @nocollapse
         */
        protected static finalize(): void;
        /**
         * Options used when calling `attachShadow`. Set this property to customize
         * the options for the shadowRoot; for example, to create a closed
         * shadowRoot: `{mode: 'closed'}`.
         *
         * Note, these options are used in `createRenderRoot`. If this method
         * is customized, options should be respected if possible.
         * @nocollapse
         * @category rendering
         */
        static shadowRootOptions: ShadowRootInit;
        /**
         * Takes the styles the user supplied via the `static styles` property and
         * returns the array of styles to apply to the element.
         * Override this method to integrate into a style management system.
         *
         * Styles are deduplicated preserving the _last_ instance in the list. This
         * is a performance optimization to avoid duplicated styles that can occur
         * especially when composing via subclassing. The last item is kept to try
         * to preserve the cascade order with the assumption that it's most important
         * that last added styles override previous styles.
         *
         * @nocollapse
         * @category styles
         */
        protected static finalizeStyles(styles?: CSSResultGroup): Array<CSSResultOrNative>;
        /**
         * Node or ShadowRoot into which element DOM should be rendered. Defaults
         * to an open shadowRoot.
         * @category rendering
         */
        readonly renderRoot: HTMLElement | DocumentFragment;
        /**
         * Returns the property name for the given attribute `name`.
         * @nocollapse
         */
        private static __attributeNameForProperty;
        private __updatePromise;
        /**
         * True if there is a pending update as a result of calling `requestUpdate()`.
         * Should only be read.
         * @category updates
         */
        isUpdatePending: boolean;
        /**
         * Is set to `true` after the first update. The element code cannot assume
         * that `renderRoot` exists before the element `hasUpdated`.
         * @category updates
         */
        hasUpdated: boolean;
        /**
         * Records property default values when the
         * `useDefault` option is used.
         */
        private __defaultValues?;
        /**
         * Properties that should be reflected when updated.
         */
        private __reflectingProperties?;
        /**
         * Name of currently reflecting property
         */
        private __reflectingProperty;
        /**
         * Set of controllers.
         */
        private __controllers?;
        constructor();
        /**
         * Internal only override point for customizing work done when elements
         * are constructed.
         */
        private __initialize;
        /**
         * Registers a `ReactiveController` to participate in the element's reactive
         * update cycle. The element automatically calls into any registered
         * controllers during its lifecycle callbacks.
         *
         * If the element is connected when `addController()` is called, the
         * controller's `hostConnected()` callback will be immediately called.
         * @category controllers
         */
        addController(controller: ReactiveController): void;
        /**
         * Removes a `ReactiveController` from the element.
         * @category controllers
         */
        removeController(controller: ReactiveController): void;
        /**
         * Fixes any properties set on the instance before upgrade time.
         * Otherwise these would shadow the accessor and break these properties.
         * The properties are stored in a Map which is played back after the
         * constructor runs.
         */
        private __saveInstanceProperties;
        /**
         * Returns the node into which the element should render and by default
         * creates and returns an open shadowRoot. Implement to customize where the
         * element's DOM is rendered. For example, to render into the element's
         * childNodes, return `this`.
         *
         * @return Returns a node into which to render.
         * @category rendering
         */
        protected createRenderRoot(): HTMLElement | DocumentFragment;
        /**
         * On first connection, creates the element's renderRoot, sets up
         * element styling, and enables updating.
         * @category lifecycle
         */
        connectedCallback(): void;
        /**
         * Note, this method should be considered final and not overridden. It is
         * overridden on the element instance with a function that triggers the first
         * update.
         * @category updates
         */
        protected enableUpdating(_requestedUpdate: boolean): void;
        /**
         * Allows for `super.disconnectedCallback()` in extensions while
         * reserving the possibility of making non-breaking feature additions
         * when disconnecting at some point in the future.
         * @category lifecycle
         */
        disconnectedCallback(): void;
        /**
         * Synchronizes property values when attributes change.
         *
         * Specifically, when an attribute is set, the corresponding property is set.
         * You should rarely need to implement this callback. If this method is
         * overridden, `super.attributeChangedCallback(name, _old, value)` must be
         * called.
         *
         * See [responding to attribute changes](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements#responding_to_attribute_changes)
         * on MDN for more information about the `attributeChangedCallback`.
         * @category attributes
         */
        attributeChangedCallback(name: string, _old: string | null, value: string | null): void;
        private __propertyToAttribute;
        /**
         * Requests an update which is processed asynchronously. This should be called
         * when an element should update based on some state not triggered by setting
         * a reactive property. In this case, pass no arguments. It should also be
         * called when manually implementing a property setter. In this case, pass the
         * property `name` and `oldValue` to ensure that any configured property
         * options are honored.
         *
         * @param name name of requesting property
         * @param oldValue old value of requesting property
         * @param options property options to use instead of the previously
         *     configured options
         * @category updates
         */
        requestUpdate(name?: PropertyKey, oldValue?: unknown, options?: PropertyDeclaration): void;
        /**
         * Sets up the element to asynchronously update.
         */
        private __enqueueUpdate;
        /**
         * Schedules an element update. You can override this method to change the
         * timing of updates by returning a Promise. The update will await the
         * returned Promise, and you should resolve the Promise to allow the update
         * to proceed. If this method is overridden, `super.scheduleUpdate()`
         * must be called.
         *
         * For instance, to schedule updates to occur just before the next frame:
         *
         * ```ts
         * override protected async scheduleUpdate(): Promise<unknown> {
         *   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
         *   super.scheduleUpdate();
         * }
         * ```
         * @category updates
         */
        protected scheduleUpdate(): void | Promise<unknown>;
        /**
         * Performs an element update. Note, if an exception is thrown during the
         * update, `firstUpdated` and `updated` will not be called.
         *
         * Call `performUpdate()` to immediately process a pending update. This should
         * generally not be needed, but it can be done in rare cases when you need to
         * update synchronously.
         *
         * @category updates
         */
        protected performUpdate(): void;
        /**
         * Invoked before `update()` to compute values needed during the update.
         *
         * Implement `willUpdate` to compute property values that depend on other
         * properties and are used in the rest of the update process.
         *
         * ```ts
         * willUpdate(changedProperties) {
         *   // only need to check changed properties for an expensive computation.
         *   if (changedProperties.has('firstName') || changedProperties.has('lastName')) {
         *     this.sha = computeSHA(`${this.firstName} ${this.lastName}`);
         *   }
         * }
         *
         * render() {
         *   return html`SHA: ${this.sha}`;
         * }
         * ```
         *
         * @category updates
         */
        protected willUpdate(_changedProperties: PropertyValues): void;
        private __markUpdated;
        /**
         * Returns a Promise that resolves when the element has completed updating.
         * The Promise value is a boolean that is `true` if the element completed the
         * update without triggering another update. The Promise result is `false` if
         * a property was set inside `updated()`. If the Promise is rejected, an
         * exception was thrown during the update.
         *
         * To await additional asynchronous work, override the `getUpdateComplete`
         * method. For example, it is sometimes useful to await a rendered element
         * before fulfilling this Promise. To do this, first await
         * `super.getUpdateComplete()`, then any subsequent state.
         *
         * @return A promise of a boolean that resolves to true if the update completed
         *     without triggering another update.
         * @category updates
         */
        get updateComplete(): Promise<boolean>;
        /**
         * Override point for the `updateComplete` promise.
         *
         * It is not safe to override the `updateComplete` getter directly due to a
         * limitation in TypeScript which means it is not possible to call a
         * superclass getter (e.g. `super.updateComplete.then(...)`) when the target
         * language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
         * This method should be overridden instead. For example:
         *
         * ```ts
         * class MyElement extends LitElement {
         *   override async getUpdateComplete() {
         *     const result = await super.getUpdateComplete();
         *     await this._myChild.updateComplete;
         *     return result;
         *   }
         * }
         * ```
         *
         * @return A promise of a boolean that resolves to true if the update completed
         *     without triggering another update.
         * @category updates
         */
        protected getUpdateComplete(): Promise<boolean>;
        /**
         * Controls whether or not `update()` should be called when the element requests
         * an update. By default, this method always returns `true`, but this can be
         * customized to control when to update.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected shouldUpdate(_changedProperties: PropertyValues): boolean;
        /**
         * Updates the element. This method reflects property values to attributes.
         * It can be overridden to render and keep updated element DOM.
         * Setting properties inside this method will *not* trigger
         * another update.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected update(_changedProperties: PropertyValues): void;
        /**
         * Invoked whenever the element is updated. Implement to perform
         * post-updating tasks via DOM APIs, for example, focusing an element.
         *
         * Setting properties inside this method will trigger the element to update
         * again after this update cycle completes.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected updated(_changedProperties: PropertyValues): void;
        /**
         * Invoked when the element is first updated. Implement to perform one time
         * work on the element after update.
         *
         * ```ts
         * firstUpdated() {
         *   this.renderRoot.getElementById('my-text-area').focus();
         * }
         * ```
         *
         * Setting properties inside this method will trigger the element to update
         * again after this update cycle completes.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected firstUpdated(_changedProperties: PropertyValues): void;
    }
}
declare module "../l2/property" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { type PropertyDeclaration, type ReactiveElement } from '_102027_/l2/reactiveElement';
    import type { Interface } from '_102027_/l2/base';
    export type PropertyDecorator = {
        <C extends Interface<ReactiveElement>, V>(target: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
        <C extends Interface<ReactiveElement>, V>(target: (value: V) => void, context: ClassSetterDecoratorContext<C, V>): (this: C, value: V) => void;
        (protoOrDescriptor: Object, name: PropertyKey, descriptor?: PropertyDescriptor): any;
    };
    type StandardPropertyContext<C, V> = (ClassAccessorDecoratorContext<C, V> | ClassSetterDecoratorContext<C, V>) & {
        metadata: object;
    };
    /**
     * Wraps a class accessor or setter so that `requestUpdate()` is called with the
     * property name and old value when the accessor is set.
     */
    export const standardProperty: <C extends Interface<ReactiveElement>, V>(options: PropertyDeclaration | undefined, target: ClassAccessorDecoratorTarget<C, V> | ((value: V) => void), context: StandardPropertyContext<C, V>) => ClassAccessorDecoratorResult<C, V> | ((this: C, value: V) => void);
    /**
     * A class field or accessor decorator which creates a reactive property that
     * reflects a corresponding attribute value. When a decorated property is set
     * the element will update and render. A {@linkcode PropertyDeclaration} may
     * optionally be supplied to configure property features.
     *
     * This decorator should only be used for public fields. As public fields,
     * properties should be considered as primarily settable by element users,
     * either via attribute or the property itself.
     *
     * Generally, properties that are changed by the element should be private or
     * protected fields and should use the {@linkcode state} decorator.
     *
     * However, sometimes element code does need to set a public property. This
     * should typically only be done in response to user interaction, and an event
     * should be fired informing the user; for example, a checkbox sets its
     * `checked` property when clicked and fires a `changed` event. Mutating public
     * properties should typically not be done for non-primitive (object or array)
     * properties. In other cases when an element needs to manage state, a private
     * property decorated via the {@linkcode state} decorator should be used. When
     * needed, state properties can be initialized via public properties to
     * facilitate complex interactions.
     *
     * ```ts
     * class MyElement {
     *   @property({ type: Boolean })
     *   clicked = false;
     * }
     * ```
     * @category Decorator
     * @ExportDecoratedItems
     */
    export function property(options?: PropertyDeclaration): PropertyDecorator;
    export {};
}
declare module "../l2/state" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    export interface StateDeclaration<Type = unknown> {
        /**
         * A function that indicates if a property should be considered changed when
         * it is set. The function should take the `newValue` and `oldValue` and
         * return `true` if an update should be requested.
         */
        hasChanged?(value: Type, oldValue: Type): boolean;
    }
    /**
     * @deprecated use StateDeclaration
     */
    export type InternalPropertyDeclaration<Type = unknown> = StateDeclaration<Type>;
    /**
     * Declares a private or protected reactive property that still triggers
     * updates to the element when it changes. It does not reflect from the
     * corresponding attribute.
     *
     * Properties declared this way must not be used from HTML or HTML templating
     * systems, they're solely for properties internal to the element. These
     * properties may be renamed by optimization tools like closure compiler.
     * @category Decorator
     */
    export function state(options?: StateDeclaration): import("/_102027_/l2/property.js").PropertyDecorator;
}
declare module "../l2/eventOptions" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import type { Interface } from '_102027_/l2/base';
    export type EventOptionsDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey): void | any;
        <C, V extends (this: C, ...args: any) => any>(value: V, _context: ClassMethodDecoratorContext<C, V>): void;
    };
    /**
     * Adds event listener options to a method used as an event listener in a
     * lit-html template.
     *
     * @param options An object that specifies event listener options as accepted by
     * `EventTarget#addEventListener` and `EventTarget#removeEventListener`.
     *
     * Current browsers support the `capture`, `passive`, and `once` options. See:
     * https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#Parameters
     *
     * ```ts
     * class MyElement {
     *   clicked = false;
     *
     *   render() {
     *     return html`
     *       <div @click=${this._onClick}>
     *         <button></button>
     *       </div>
     *     `;
     *   }
     *
     *   @eventOptions({capture: true})
     *   _onClick(e) {
     *     this.clicked = true;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function eventOptions(options: AddEventListenerOptions): EventOptionsDecorator;
}
declare module "../l2/query" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    export type QueryDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Element | null>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter that
     * executes a querySelector on the element's renderRoot.
     *
     * @param selector A DOMString containing one or more selectors to match.
     * @param cache An optional boolean which when true performs the DOM query only
     *     once and caches the result.
     *
     * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
     *
     * ```ts
     * class MyElement {
     *   @query('#first')
     *   first: HTMLDivElement;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function query(selector: string, cache?: boolean): QueryDecorator;
}
declare module "../l2/queryAll" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    export type QueryAllDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends NodeList>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter
     * that executes a querySelectorAll on the element's renderRoot.
     *
     * @param selector A DOMString containing one or more selectors to match.
     *
     * See:
     * https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelectorAll
     *
     * ```ts
     * class MyElement {
     *   @queryAll('div')
     *   divs: NodeListOf<HTMLDivElement>;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function queryAll(selector: string): QueryAllDecorator;
}
declare module "../l2/queryAsync" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    export type QueryAsyncDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Promise<Element | null>>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter that
     * returns a promise that resolves to the result of a querySelector on the
     * element's renderRoot done after the element's `updateComplete` promise
     * resolves. When the queried property may change with element state, this
     * decorator can be used instead of requiring users to await the
     * `updateComplete` before accessing the property.
     *
     * @param selector A DOMString containing one or more selectors to match.
     *
     * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
     *
     * ```ts
     * class MyElement {
     *   @queryAsync('#first')
     *   first: Promise<HTMLDivElement>;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     *
     * // external usage
     * async doSomethingWithFirst() {
     *  (await aMyElement.first).doSomething();
     * }
     * ```
     * @category Decorator
     */
    export function queryAsync(selector: string): QueryAsyncDecorator;
}
declare module "../l2/queryAssignedNodes" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    /**
     * Options for the {@linkcode queryAssignedNodes} decorator. Extends the options
     * that can be passed into [HTMLSlotElement.assignedNodes](https://developer.mozilla.org/en-US/docs/Web/API/HTMLSlotElement/assignedNodes).
     */
    export interface QueryAssignedNodesOptions extends AssignedNodesOptions {
        /**
         * Name of the slot to query. Leave empty for the default slot.
         */
        slot?: string;
    }
    export type QueryAssignedNodesDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Array<Node>>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter that
     * returns the `assignedNodes` of the given `slot`.
     *
     * Can be passed an optional {@linkcode QueryAssignedNodesOptions} object.
     *
     * Example usage:
     * ```ts
     * class MyElement {
     *   @queryAssignedNodes({slot: 'list', flatten: true})
     *   listItems!: Array<Node>;
     *
     *   render() {
     *     return html`
     *       <slot name="list"></slot>
     *     `;
     *   }
     * }
     * ```
     *
     * Note the type of this property should be annotated as `Array<Node>`. Use the
     * queryAssignedElements decorator to list only elements, and optionally filter
     * the element list using a CSS selector.
     *
     * @category Decorator
     */
    export function queryAssignedNodes(options?: QueryAssignedNodesOptions): QueryAssignedNodesDecorator;
}
declare module "../l2/queryAssignedElements" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import type { QueryAssignedNodesOptions } from '_102027_/l2/queryAssignedNodes';
    import { type Interface } from '_102027_/l2/base';
    export type QueryAssignedElementsDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Array<Element>>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * Options for the {@linkcode queryAssignedElements} decorator. Extends the
     * options that can be passed into
     * [HTMLSlotElement.assignedElements](https://developer.mozilla.org/en-US/docs/Web/API/HTMLSlotElement/assignedElements).
     */
    export interface QueryAssignedElementsOptions extends QueryAssignedNodesOptions {
        /**
         * CSS selector used to filter the elements returned. For example, a selector
         * of `".item"` will only include elements with the `item` class.
         */
        selector?: string;
    }
    /**
     * A property decorator that converts a class property into a getter that
     * returns the `assignedElements` of the given `slot`. Provides a declarative
     * way to use
     * [`HTMLSlotElement.assignedElements`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLSlotElement/assignedElements).
     *
     * Can be passed an optional {@linkcode QueryAssignedElementsOptions} object.
     *
     * Example usage:
     * ```ts
     * class MyElement {
     *   @queryAssignedElements({ slot: 'list' })
     *   listItems!: Array<HTMLElement>;
     *   @queryAssignedElements()
     *   unnamedSlotEls!: Array<HTMLElement>;
     *
     *   render() {
     *     return html`
     *       <slot name="list"></slot>
     *       <slot></slot>
     *     `;
     *   }
     * }
     * ```
     *
     * Note, the type of this property should be annotated as `Array<HTMLElement>`.
     *
     * @category Decorator
     */
    export function queryAssignedElements(options?: QueryAssignedElementsOptions): QueryAssignedElementsDecorator;
}
declare module "_102027_/l2/decorators" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    export * from '_102027_/l2/customElement';
    export * from '_102027_/l2/property';
    export * from '_102027_/l2/state';
    export * from '_102027_/l2/eventOptions';
    export * from '_102027_/l2/query';
    export * from '_102027_/l2/queryAll';
    export * from '_102027_/l2/queryAsync';
    export * from '_102027_/l2/queryAssignedElements';
    export * from '_102027_/l2/queryAssignedNodes';
}
declare module "_102027_/l2/defsAST" {
    export function parseDefsFile(source: string): {
        asis: mls.defs.AsIs;
        history: mls.defs.ChangeHistoryItem[];
        skill: string;
    };
    export function getAsis(source: string): mls.defs.AsIs;
    export function updateAsis(source: string, patch: DeepPartial<mls.defs.AsIs>): string;
    export function replaceAsis(source: string, value: mls.defs.AsIs): string;
    export function getHistory(source: string): mls.defs.ChangeHistoryItem[];
    export function addHistoryItem(source: string, item: mls.defs.ChangeHistoryItem): string;
    export function updateHistoryItem(source: string, version: number, patch: Partial<mls.defs.ChangeHistoryItem>): string;
    export function replaceHistory(source: string, value: mls.defs.ChangeHistoryItem[]): string;
    export function getSkill(source: string): string;
    export function updateSkill(source: string, value: string): string;
    type DeepPartial<T> = {
        [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
    };
    export function getMaterializeIndex(source: string): mls.defs.MaterializeIndex;
    export function replaceMaterializeIndex(source: string, value: mls.defs.MaterializeIndex): string;
    export function addMaterializeItem(source: string, item: mls.defs.MaterializeEntry): string;
    export function updateMaterializeItem(source: string, id: string, patch: Partial<mls.defs.MaterializeEntry>): string;
    export function removeMaterializeItem(source: string, id: string): string;
    export function getVariableText(source: string, varName: string): string;
    export function updateVariableText(source: string, varName: string, value: string): string;
    export function getVariableJson<T = unknown>(source: string, varName: string): T;
    export function updateVariableJson(source: string, varName: string, value: unknown): string;
}
declare module "../l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "../l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        dsGlobalCss?: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "../l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "../l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "../l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "../l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102027_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102027_/l2/directive" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Disconnectable, Part } from '_102027_/l2/litHtml';
    export { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart, } from '_102027_/l2/litHtml';
    export interface DirectiveClass {
        new (part: PartInfo): Directive;
    }
    /**
     * This utility type extracts the signature of a directive class's render()
     * method so we can use it for the type of the generated directive function.
     */
    export type DirectiveParameters<C extends Directive> = Parameters<C['render']>;
    /**
     * A generated directive function doesn't evaluate the directive, but just
     * returns a DirectiveResult object that captures the arguments.
     */
    export interface DirectiveResult<C extends DirectiveClass = DirectiveClass> {
    }
    export const PartType: {
        readonly ATTRIBUTE: 1;
        readonly CHILD: 2;
        readonly PROPERTY: 3;
        readonly BOOLEAN_ATTRIBUTE: 4;
        readonly EVENT: 5;
        readonly ELEMENT: 6;
    };
    export type PartType = (typeof PartType)[keyof typeof PartType];
    export interface ChildPartInfo {
        readonly type: typeof PartType.CHILD;
    }
    export interface AttributePartInfo {
        readonly type: typeof PartType.ATTRIBUTE | typeof PartType.PROPERTY | typeof PartType.BOOLEAN_ATTRIBUTE | typeof PartType.EVENT;
        readonly strings?: ReadonlyArray<string>;
        readonly name: string;
        readonly tagName: string;
    }
    export interface ElementPartInfo {
        readonly type: typeof PartType.ELEMENT;
    }
    /**
     * Information about the part a directive is bound to.
     *
     * This is useful for checking that a directive is attached to a valid part,
     * such as with directive that can only be used on attribute bindings.
     */
    export type PartInfo = ChildPartInfo | AttributePartInfo | ElementPartInfo;
    /**
     * Creates a user-facing directive function from a Directive class. This
     * function has the same parameters as the directive's render() method.
     */
    export const directive: <C extends DirectiveClass>(c: C) => (...values: DirectiveParameters<InstanceType<C>>) => DirectiveResult<C>;
    /**
     * Base class for creating custom directives. Users should extend this class,
     * implement `render` and/or `update`, and then pass their subclass to
     * `directive`.
     */
    export abstract class Directive implements Disconnectable {
        constructor(_partInfo: PartInfo);
        get _$isConnected(): boolean;
        abstract render(...props: Array<unknown>): unknown;
        update(_part: Part, props: Array<unknown>): unknown;
    }
}
declare module "_102027_/l2/directiveHelpers" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Part, DirectiveParent, CompiledTemplateResult, MaybeCompiledTemplateResult, UncompiledTemplateResult } from '_102027_/l2/litHtml';
    import { DirectiveResult, DirectiveClass, PartInfo } from '_102027_/l2/directive';
    type Primitive = null | undefined | boolean | number | string | symbol | bigint;
    const ChildPart: typeof import("/_102027_/l2/litHtml.js").ChildPart;
    type ChildPart = InstanceType<typeof ChildPart>;
    /**
     * Tests if a value is a primitive value.
     *
     * See https://tc39.github.io/ecma262/#sec-typeof-operator
     */
    export const isPrimitive: (value: unknown) => value is Primitive;
    export const TemplateResultType: {
        readonly HTML: 1;
        readonly SVG: 2;
        readonly MATHML: 3;
    };
    export type TemplateResultType = (typeof TemplateResultType)[keyof typeof TemplateResultType];
    type IsTemplateResult = {
        (val: unknown): val is MaybeCompiledTemplateResult;
        <T extends TemplateResultType>(val: unknown, type: T): val is UncompiledTemplateResult<T>;
    };
    /**
     * Tests if a value is a TemplateResult or a CompiledTemplateResult.
     */
    export const isTemplateResult: IsTemplateResult;
    /**
     * Tests if a value is a CompiledTemplateResult.
     */
    export const isCompiledTemplateResult: (value: unknown) => value is CompiledTemplateResult;
    /**
     * Tests if a value is a DirectiveResult.
     */
    export const isDirectiveResult: (value: unknown) => value is DirectiveResult;
    /**
     * Retrieves the Directive class for a DirectiveResult
     */
    export const getDirectiveClass: (value: unknown) => DirectiveClass | undefined;
    /**
     * Tests whether a part has only a single-expression with no strings to
     * interpolate between.
     *
     * Only AttributePart and PropertyPart can have multiple expressions.
     * Multi-expression parts have a `strings` property and single-expression
     * parts do not.
     */
    export const isSingleExpression: (part: PartInfo) => boolean;
    /**
     * Inserts a ChildPart into the given container ChildPart's DOM, either at the
     * end of the container ChildPart, or before the optional `refPart`.
     *
     * This does not add the part to the containerPart's committed value. That must
     * be done by callers.
     *
     * @param containerPart Part within which to add the new ChildPart
     * @param refPart Part before which to add the new ChildPart; when omitted the
     *     part added to the end of the `containerPart`
     * @param part Part to insert, or undefined to create a new part
     */
    export const insertPart: (containerPart: ChildPart, refPart?: ChildPart, part?: ChildPart) => ChildPart;
    /**
     * Sets the value of a Part.
     *
     * Note that this should only be used to set/update the value of user-created
     * parts (i.e. those created using `insertPart`); it should not be used
     * by directives to set the value of the directive's container part. Directives
     * should return a value from `update`/`render` to update their part state.
     *
     * For directives that require setting their part value asynchronously, they
     * should extend `AsyncDirective` and call `this.setValue()`.
     *
     * @param part Part to set
     * @param value Value to set
     * @param index For `AttributePart`s, the index to set
     * @param directiveParent Used internally; should not be set by user
     */
    export const setChildPartValue: <T extends ChildPart>(part: T, value: unknown, directiveParent?: DirectiveParent) => T;
    /**
     * Sets the committed value of a ChildPart directly without triggering the
     * commit stage of the part.
     *
     * This is useful in cases where a directive needs to update the part such
     * that the next update detects a value change or not. When value is omitted,
     * the next update will be guaranteed to be detected as a change.
     *
     * @param part
     * @param value
     */
    export const setCommittedValue: (part: Part, value?: unknown) => unknown;
    /**
     * Returns the committed value of a ChildPart.
     *
     * The committed value is used for change detection and efficient updates of
     * the part. It can differ from the value set by the template or directive in
     * cases where the template value is transformed before being committed.
     *
     * - `TemplateResult`s are committed as a `TemplateInstance`
     * - Iterables are committed as `Array<ChildPart>`
     * - All other types are committed as the template value or value returned or
     *   set by a directive.
     *
     * @param part
     */
    export const getCommittedValue: (part: ChildPart) => unknown;
    /**
     * Removes a ChildPart from the DOM, including any of its content and markers.
     *
     * Note: The only difference between this and clearPart() is that this also
     * removes the part's start node. This means that the ChildPart must own its
     * start node, ie it must be a marker node specifically for this part and not an
     * anchor from surrounding content.
     *
     * @param part The Part to remove
     */
    export const removePart: (part: ChildPart) => void;
    export const clearPart: (part: ChildPart) => void;
    export {};
}
declare module "_102027_/l2/enhancementAgent" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string) => Promise<string>;
}
declare module "../l2/validateLit" {
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
    export function validateRender(modelTS: mls.editor.IModelTS): boolean;
}
declare module "../l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "../l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "../l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102027_/l2/enhancementLit" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "../l2/enhancementLit" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102027_/l2/enhancementLitService" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102027_/l2/enhancementStyle" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export const getDesignDetails: (modelStyle: mls.editor.IModelStyle) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function getLineByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getLineSelectorByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getRootSelectors(lessContent: string): string[];
    export function isCommentLine(line: string): boolean;
    export function setStylesProcessed(newCss: string, el: HTMLElement, tag: string): Promise<void>;
}
declare module "_102027_/l2/eventOptions" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import type { Interface } from '_102027_/l2/base';
    export type EventOptionsDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey): void | any;
        <C, V extends (this: C, ...args: any) => any>(value: V, _context: ClassMethodDecoratorContext<C, V>): void;
    };
    /**
     * Adds event listener options to a method used as an event listener in a
     * lit-html template.
     *
     * @param options An object that specifies event listener options as accepted by
     * `EventTarget#addEventListener` and `EventTarget#removeEventListener`.
     *
     * Current browsers support the `capture`, `passive`, and `once` options. See:
     * https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#Parameters
     *
     * ```ts
     * class MyElement {
     *   clicked = false;
     *
     *   render() {
     *     return html`
     *       <div @click=${this._onClick}>
     *         <button></button>
     *       </div>
     *     `;
     *   }
     *
     *   @eventOptions({capture: true})
     *   _onClick(e) {
     *     this.clicked = true;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function eventOptions(options: AddEventListenerOptions): EventOptionsDecorator;
}
declare module "_102027_/l2/guard" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Part } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters } from '_102027_/l2/directive';
    class GuardDirective extends Directive {
        private _previousValue;
        render(_value: unknown, f: () => unknown): unknown;
        update(_part: Part, [value, f]: DirectiveParameters<this>): unknown;
    }
    /**
     * Prevents re-render of a template function until a single value or an array of
     * values changes.
     *
     * Values are checked against previous values with strict equality (`===`), and
     * so the check won't detect nested property changes inside objects or arrays.
     * Arrays values have each item checked against the previous value at the same
     * index with strict equality. Nested arrays are also checked only by strict
     * equality.
     *
     * Example:
     *
     * ```js
     * html`
     *   <div>
     *     ${guard([user.id, company.id], () => html`...`)}
     *   </div>
     * `
     * ```
     *
     * In this case, the template only rerenders if either `user.id` or `company.id`
     * changes.
     *
     * guard() is useful with immutable data patterns, by preventing expensive work
     * until data updates.
     *
     * Example:
     *
     * ```js
     * html`
     *   <div>
     *     ${guard([immutableItems], () => immutableItems.map(i => html`${i}`))}
     *   </div>
     * `
     * ```
     *
     * In this case, items are mapped over only when the array reference changes.
     *
     * @param value the value to check before re-rendering
     * @param f the template function
     */
    export const guard: (_value: unknown, f: () => unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof GuardDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { GuardDirective };
}
declare module "_102027_/l2/ifDefined" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { nothing } from '_102027_/l2/litHtml';
    /**
     * For AttributeParts, sets the attribute if the value is defined and removes
     * the attribute if the value is undefined.
     *
     * For other part types, this directive is a no-op.
     */
    export const ifDefined: <T>(value: T) => typeof nothing | NonNullable<T>;
}
declare module "_102027_/l2/isServer" {
    /**
     * @license
     * Copyright 2022 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * A boolean that will be `true` in server environments like Node, and `false`
     * in browser environments. Note that your server environment or toolchain must
     * support the `"node"` export condition for this to be `true`.
     *
     * This can be used when authoring components to change behavior based on
     * whether or not the component is executing in an SSR context.
     */
    export const isServer = false;
}
declare module "_102027_/l2/join" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Returns an iterable containing the values in `items` interleaved with the
     * `joiner` value.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${join(items, html`<span class="separator">|</span>`)}
     *   `;
     * }
     */
    export function join<I, J>(items: Iterable<I> | undefined, joiner: (index: number) => J): Iterable<I | J>;
    export function join<I, J>(items: Iterable<I> | undefined, joiner: J): Iterable<I | J>;
}
declare module "_102027_/l2/keyed" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Directive, ChildPart, DirectiveParameters } from '_102027_/l2/directive';
    class Keyed extends Directive {
        key: unknown;
        render(k: unknown, v: unknown): unknown;
        update(part: ChildPart, [k, v]: DirectiveParameters<this>): unknown;
    }
    /**
     * Associates a renderable value with a unique key. When the key changes, the
     * previous DOM is removed and disposed before rendering the next value, even
     * if the value - such as a template - is the same.
     *
     * This is useful for forcing re-renders of stateful components, or working
     * with code that expects new data to generate new HTML elements, such as some
     * animation techniques.
     */
    export const keyed: (k: unknown, v: unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof Keyed>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { Keyed };
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        dsGlobalCss?: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libNewProject" {
    export interface IProjectType {
        id: string;
        name: string;
        dependencies: number[];
        agent?: string;
    }
    export const projectTypes: IProjectType[];
    export const template_tsconfig: {
        ext: string;
        template: string;
    };
    export const template_l5Project: {
        ext: string;
        template: string;
    };
    export const template_package: {
        ext: string;
        template: string;
    };
    export const template_build: {
        ext: string;
        template: string;
    };
    export const template_l2Project: {
        ext: string;
        template: string;
    };
    export const template_coreIndex: {
        ext: string;
        template: string;
    };
    export const template_ds: {
        ext: string;
        template: string;
    };
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "../l2/classMap" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart, noChange } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    /**
     * A key-value set of class names to truthy values.
     */
    export interface ClassInfo {
        readonly [name: string]: string | boolean | number;
    }
    class ClassMapDirective extends Directive {
        /**
         * Stores the ClassInfo object applied to a given AttributePart.
         * Used to unset existing values when a new ClassInfo object is applied.
         */
        private _previousClasses?;
        private _staticClasses?;
        constructor(partInfo: PartInfo);
        render(classInfo: ClassInfo): string;
        update(part: AttributePart, [classInfo]: DirectiveParameters<this>): string | typeof noChange;
    }
    /**
     * A directive that applies dynamic CSS classes.
     *
     * This must be used in the `class` attribute and must be the only part used in
     * the attribute. It takes each property in the `classInfo` argument and adds
     * the property name to the element's `classList` if the property value is
     * truthy; if the property value is falsy, the property name is removed from
     * the element's `class`.
     *
     * For example `{foo: bar}` applies the class `foo` if the value of `bar` is
     * truthy.
     *
     * @param classInfo
     */
    export const classMap: (classInfo: ClassInfo) => import("/_102027_/l2/directive.js").DirectiveResult<typeof ClassMapDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { ClassMapDirective };
}
declare module "../l2/ifDefined" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { nothing } from '_102027_/l2/litHtml';
    /**
     * For AttributeParts, sets the attribute if the value is defined and removes
     * the attribute if the value is undefined.
     *
     * For other part types, this directive is a no-op.
     */
    export const ifDefined: <T>(value: T) => typeof nothing | NonNullable<T>;
}
declare module "../l2/live" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    class LiveDirective extends Directive {
        constructor(partInfo: PartInfo);
        render(value: unknown): unknown;
        update(part: AttributePart, [value]: DirectiveParameters<this>): unknown;
    }
    /**
     * Checks binding values against live DOM values, instead of previously bound
     * values, when determining whether to update the value.
     *
     * This is useful for cases where the DOM value may change from outside of
     * lit-html, such as with a binding to an `<input>` element's `value` property,
     * a content editable elements text, or to a custom element that changes it's
     * own properties or attributes.
     *
     * In these cases if the DOM value changes, but the value set through lit-html
     * bindings hasn't, lit-html won't know to update the DOM value and will leave
     * it alone. If this is not what you want--if you want to overwrite the DOM
     * value with the bound value no matter what--use the `live()` directive:
     *
     * ```js
     * html`<input .value=${live(x)}>`
     * ```
     *
     * `live()` performs a strict equality check against the live DOM value, and if
     * the new value is equal to the live value, does nothing. This means that
     * `live()` should not be used when the binding will cause a type conversion. If
     * you use `live()` with an attribute binding, make sure that only strings are
     * passed in, or the binding will update every render.
     */
    export const live: (value: unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof LiveDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { LiveDirective };
}
declare module "../l2/styleMap" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart, noChange } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    /**
     * A key-value set of CSS properties and values.
     *
     * The key should be either a valid CSS property name string, like
     * `'background-color'`, or a valid JavaScript camel case property name
     * for CSSStyleDeclaration like `backgroundColor`.
     */
    export interface StyleInfo {
        [name: string]: string | number | undefined | null;
    }
    class StyleMapDirective extends Directive {
        private _previousStyleProperties?;
        constructor(partInfo: PartInfo);
        render(styleInfo: Readonly<StyleInfo>): string;
        update(part: AttributePart, [styleInfo]: DirectiveParameters<this>): string | typeof noChange;
    }
    /**
     * A directive that applies CSS properties to an element.
     *
     * `styleMap` can only be used in the `style` attribute and must be the only
     * expression in the attribute. It takes the property names in the
     * {@link StyleInfo styleInfo} object and adds the properties to the inline
     * style of the element.
     *
     * Property names with dashes (`-`) are assumed to be valid CSS
     * property names and set on the element's style object using `setProperty()`.
     * Names without dashes are assumed to be camelCased JavaScript property names
     * and set on the element's style object using property assignment, allowing the
     * style object to translate JavaScript-style names to CSS property names.
     *
     * For example `styleMap({backgroundColor: 'red', 'border-top': '5px', '--size':
     * '0'})` sets the `background-color`, `border-top` and `--size` properties.
     *
     * @param styleInfo
     * @see {@link https://lit.dev/docs/templates/directives/#stylemap styleMap code samples on Lit.dev}
     */
    export const styleMap: (styleInfo: Readonly<StyleInfo>) => import("/_102027_/l2/directive.js").DirectiveResult<typeof StyleMapDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { StyleMapDirective };
}
declare module "../l2/asyncAppend" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart } from '_102027_/l2/litHtml';
    import { DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    import { AsyncReplaceDirective } from '_102027_/l2/asyncReplace';
    class AsyncAppendDirective extends AsyncReplaceDirective {
        private __childPart;
        constructor(partInfo: PartInfo);
        update(part: ChildPart, params: DirectiveParameters<this>): symbol;
        protected commitValue(value: unknown, index: number): void;
    }
    /**
     * A directive that renders the items of an async iterable[1], appending new
     * values after previous values, similar to the built-in support for iterables.
     * This directive is usable only in child expressions.
     *
     * Async iterables are objects with a [Symbol.asyncIterator] method, which
     * returns an iterator who's `next()` method returns a Promise. When a new
     * value is available, the Promise resolves and the value is appended to the
     * Part controlled by the directive. If another value other than this
     * directive has been set on the Part, the iterable will no longer be listened
     * to and new values won't be written to the Part.
     *
     * [1]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for-await...of
     *
     * @param value An async iterable
     * @param mapper An optional function that maps from (value, index) to another
     *     value. Useful for generating templates for each item in the iterable.
     */
    export const asyncAppend: (value: AsyncIterable<unknown>, _mapper?: ((v: unknown, index?: number) => unknown) | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof AsyncAppendDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { AsyncAppendDirective };
}
declare module "../l2/cache" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    class CacheDirective extends Directive {
        private _templateCache;
        private _value?;
        constructor(partInfo: PartInfo);
        render(v: unknown): unknown[];
        update(containerPart: ChildPart, [v]: DirectiveParameters<this>): unknown[];
    }
    /**
     * Enables fast switching between multiple templates by caching the DOM nodes
     * and TemplateInstances produced by the templates.
     *
     * Example:
     *
     * ```js
     * let checked = false;
     *
     * html`
     *   ${cache(checked ? html`input is checked` : html`input is not checked`)}
     * `
     * ```
     */
    export const cache: (v: unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof CacheDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { CacheDirective };
}
declare module "../l2/choose" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Chooses and evaluates a template function from a list based on matching
     * the given `value` to a case.
     *
     * Cases are structured as `[caseValue, func]`. `value` is matched to
     * `caseValue` by strict equality. The first match is selected. Case values
     * can be of any type including primitives, objects, and symbols.
     *
     * This is similar to a switch statement, but as an expression and without
     * fallthrough.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${choose(this.section, [
     *       ['home', () => html`<h1>Home</h1>`],
     *       ['about', () => html`<h1>About</h1>`]
     *     ],
     *     () => html`<h1>Error</h1>`)}
     *   `;
     * }
     * ```
     */
    export const choose: <T, V, K extends T = T>(value: T, cases: Array<[K, () => V]>, defaultCase?: () => V) => V | undefined;
}
declare module "../l2/guard" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Part } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters } from '_102027_/l2/directive';
    class GuardDirective extends Directive {
        private _previousValue;
        render(_value: unknown, f: () => unknown): unknown;
        update(_part: Part, [value, f]: DirectiveParameters<this>): unknown;
    }
    /**
     * Prevents re-render of a template function until a single value or an array of
     * values changes.
     *
     * Values are checked against previous values with strict equality (`===`), and
     * so the check won't detect nested property changes inside objects or arrays.
     * Arrays values have each item checked against the previous value at the same
     * index with strict equality. Nested arrays are also checked only by strict
     * equality.
     *
     * Example:
     *
     * ```js
     * html`
     *   <div>
     *     ${guard([user.id, company.id], () => html`...`)}
     *   </div>
     * `
     * ```
     *
     * In this case, the template only rerenders if either `user.id` or `company.id`
     * changes.
     *
     * guard() is useful with immutable data patterns, by preventing expensive work
     * until data updates.
     *
     * Example:
     *
     * ```js
     * html`
     *   <div>
     *     ${guard([immutableItems], () => immutableItems.map(i => html`${i}`))}
     *   </div>
     * `
     * ```
     *
     * In this case, items are mapped over only when the array reference changes.
     *
     * @param value the value to check before re-rendering
     * @param f the template function
     */
    export const guard: (_value: unknown, f: () => unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof GuardDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { GuardDirective };
}
declare module "../l2/join" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Returns an iterable containing the values in `items` interleaved with the
     * `joiner` value.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${join(items, html`<span class="separator">|</span>`)}
     *   `;
     * }
     */
    export function join<I, J>(items: Iterable<I> | undefined, joiner: (index: number) => J): Iterable<I | J>;
    export function join<I, J>(items: Iterable<I> | undefined, joiner: J): Iterable<I | J>;
}
declare module "../l2/keyed" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Directive, ChildPart, DirectiveParameters } from '_102027_/l2/directive';
    class Keyed extends Directive {
        key: unknown;
        render(k: unknown, v: unknown): unknown;
        update(part: ChildPart, [k, v]: DirectiveParameters<this>): unknown;
    }
    /**
     * Associates a renderable value with a unique key. When the key changes, the
     * previous DOM is removed and disposed before rendering the next value, even
     * if the value - such as a template - is the same.
     *
     * This is useful for forcing re-renders of stateful components, or working
     * with code that expects new data to generate new HTML elements, such as some
     * animation techniques.
     */
    export const keyed: (k: unknown, v: unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof Keyed>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { Keyed };
}
declare module "../l2/map" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Returns an iterable containing the result of calling `f(value)` on each
     * value in `items`.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     <ul>
     *       ${map(items, (i) => html`<li>${i}</li>`)}
     *     </ul>
     *   `;
     * }
     * ```
     */
    export function map<T>(items: Iterable<T> | undefined, f: (value: T, index: number) => unknown): Generator<unknown, void, unknown>;
}
declare module "../l2/range" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Returns an iterable of integers from `start` to `end` (exclusive)
     * incrementing by `step`.
     *
     * If `start` is omitted, the range starts at `0`. `step` defaults to `1`.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${map(range(8), () => html`<div class="cell"></div>`)}
     *   `;
     * }
     * ```
     */
    export function range(end: number): Iterable<number>;
    export function range(start: number, end: number, step?: number): Iterable<number>;
}
declare module "../l2/repeat" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart, noChange } from '_102027_/l2/litHtml';
    import { Directive, PartInfo } from '_102027_/l2/directive';
    export type KeyFn<T> = (item: T, index: number) => unknown;
    export type ItemTemplate<T> = (item: T, index: number) => unknown;
    class RepeatDirective extends Directive {
        private _itemKeys?;
        constructor(partInfo: PartInfo);
        private _getValuesAndKeys;
        render<T>(items: Iterable<T>, template: ItemTemplate<T>): Array<unknown>;
        render<T>(items: Iterable<T>, keyFn: KeyFn<T> | ItemTemplate<T>, template: ItemTemplate<T>): Array<unknown>;
        update<T>(containerPart: ChildPart, [items, keyFnOrTemplate, template]: [
            Iterable<T>,
            KeyFn<T> | ItemTemplate<T>,
            ItemTemplate<T>
        ]): unknown[] | typeof noChange;
    }
    export interface RepeatDirectiveFn {
        <T>(items: Iterable<T>, keyFnOrTemplate: KeyFn<T> | ItemTemplate<T>, template?: ItemTemplate<T>): unknown;
        <T>(items: Iterable<T>, template: ItemTemplate<T>): unknown;
        <T>(items: Iterable<T>, keyFn: KeyFn<T> | ItemTemplate<T>, template: ItemTemplate<T>): unknown;
    }
    /**
     * A directive that repeats a series of values (usually `TemplateResults`)
     * generated from an iterable, and updates those items efficiently when the
     * iterable changes based on user-provided `keys` associated with each item.
     *
     * Note that if a `keyFn` is provided, strict key-to-DOM mapping is maintained,
     * meaning previous DOM for a given key is moved into the new position if
     * needed, and DOM will never be reused with values for different keys (new DOM
     * will always be created for new keys). This is generally the most efficient
     * way to use `repeat` since it performs minimum unnecessary work for insertions
     * and removals.
     *
     * The `keyFn` takes two parameters, the item and its index, and returns a unique key value.
     *
     * ```js
     * html`
     *   <ol>
     *     ${repeat(this.items, (item) => item.id, (item, index) => {
     *       return html`<li>${index}: ${item.name}</li>`;
     *     })}
     *   </ol>
     * `
     * ```
     *
     * **Important**: If providing a `keyFn`, keys *must* be unique for all items in a
     * given call to `repeat`. The behavior when two or more items have the same key
     * is undefined.
     *
     * If no `keyFn` is provided, this directive will perform similar to mapping
     * items to values, and DOM will be reused against potentially different items.
     */
    export const repeat: RepeatDirectiveFn;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { RepeatDirective };
}
declare module "../l2/ref" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ElementPart } from '_102027_/l2/litHtml';
    import { AsyncDirective } from '_102027_/l2/asyncDirective';
    /**
     * Creates a new Ref object, which is container for a reference to an element.
     */
    export const createRef: <T = Element>() => Ref<T>;
    /**
     * An object that holds a ref value.
     */
    class Ref<T = Element> {
        /**
         * The current Element value of the ref, or else `undefined` if the ref is no
         * longer rendered.
         */
        readonly value?: T;
    }
    export type { Ref };
    export type RefOrCallback<T = Element> = Ref<T> | ((el: T | undefined) => void);
    class RefDirective extends AsyncDirective {
        private _element?;
        private _ref?;
        private _context?;
        render(_ref?: RefOrCallback): symbol;
        update(part: ElementPart, [ref]: Parameters<this['render']>): symbol;
        private _updateRefValue;
        private get _lastElementForRef();
        disconnected(): void;
        reconnected(): void;
    }
    /**
     * Sets the value of a Ref object or calls a ref callback with the element it's
     * bound to.
     *
     * A Ref object acts as a container for a reference to an element. A ref
     * callback is a function that takes an element as its only argument.
     *
     * The ref directive sets the value of the Ref object or calls the ref callback
     * during rendering, if the referenced element changed.
     *
     * Note: If a ref callback is rendered to a different element position or is
     * removed in a subsequent render, it will first be called with `undefined`,
     * followed by another call with the new element it was rendered to (if any).
     *
     * ```js
     * // Using Ref object
     * const inputRef = createRef();
     * render(html`<input ${ref(inputRef)}>`, container);
     * inputRef.value.focus();
     *
     * // Using callback
     * const callback = (inputElement) => inputElement.focus();
     * render(html`<input ${ref(callback)}>`, container);
     * ```
     */
    export const ref: (_ref?: RefOrCallback<Element> | undefined) => import('/_102027_/l2/directive.js').DirectiveResult<typeof RefDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { RefDirective };
}
declare module "../l2/templateContent" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { noChange } from '_102027_/l2/litHtml';
    import { Directive, PartInfo } from '_102027_/l2/directive';
    class TemplateContentDirective extends Directive {
        private _previousTemplate?;
        constructor(partInfo: PartInfo);
        render(template: HTMLTemplateElement): DocumentFragment | typeof noChange;
    }
    /**
     * Renders the content of a template element as HTML.
     *
     * Note, the template should be developer controlled and not user controlled.
     * Rendering a user-controlled template with this directive
     * could lead to cross-site-scripting vulnerabilities.
     */
    export const templateContent: (template: HTMLTemplateElement) => import("/_102027_/l2/directive.js").DirectiveResult<typeof TemplateContentDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { TemplateContentDirective };
}
declare module "../l2/unsafeHtml" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { nothing, TemplateResult, noChange } from '_102027_/l2/litHtml';
    import { Directive, PartInfo } from '_102027_/l2/directive';
    export class UnsafeHTMLDirective extends Directive {
        static directiveName: string;
        static resultType: number;
        private _value;
        private _templateResult?;
        constructor(partInfo: PartInfo);
        render(value: string | typeof nothing | typeof noChange | undefined | null): typeof noChange | typeof nothing | TemplateResult | null | undefined;
    }
    /**
     * Renders the result as HTML, rather than text.
     *
     * The values `undefined`, `null`, and `nothing`, will all result in no content
     * (empty string) being rendered.
     *
     * Note, this is unsafe to use with any user-provided input that hasn't been
     * sanitized or escaped, as it may lead to cross-site-scripting
     * vulnerabilities.
     */
    export const unsafeHTML: (value: string | typeof noChange | typeof nothing | null | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof UnsafeHTMLDirective>;
}
declare module "../l2/unsafeSvg" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { UnsafeHTMLDirective } from '_102027_/l2/unsafeHtml';
    class UnsafeSVGDirective extends UnsafeHTMLDirective {
        static directiveName: string;
        static resultType: number;
    }
    /**
     * Renders the result as SVG, rather than text.
     *
     * The values `undefined`, `null`, and `nothing`, will all result in no content
     * (empty string) being rendered.
     *
     * Note, this is unsafe to use with any user-provided input that hasn't been
     * sanitized or escaped, as it may lead to cross-site-scripting
     * vulnerabilities.
     */
    export const unsafeSVG: (value: string | typeof import('/_102027_/l2/litHtml.js').noChange | typeof import("/_102027_/l2/litHtml.js").nothing | null | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof UnsafeSVGDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { UnsafeSVGDirective };
}
declare module "../l2/until" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Part } from '_102027_/l2/litHtml';
    import { AsyncDirective } from '_102027_/l2/asyncDirective';
    export class UntilDirective extends AsyncDirective {
        private __lastRenderedIndex;
        private __values;
        private __weakThis;
        private __pauser;
        render(...args: Array<unknown>): unknown;
        update(_part: Part, args: Array<unknown>): unknown;
        disconnected(): void;
        reconnected(): void;
    }
    /**
     * Renders one of a series of values, including Promises, to a Part.
     *
     * Values are rendered in priority order, with the first argument having the
     * highest priority and the last argument having the lowest priority. If a
     * value is a Promise, low-priority values will be rendered until it resolves.
     *
     * The priority of values can be used to create placeholder content for async
     * data. For example, a Promise with pending content can be the first,
     * highest-priority, argument, and a non_promise loading indicator template can
     * be used as the second, lower-priority, argument. The loading indicator will
     * render immediately, and the primary content will render when the Promise
     * resolves.
     *
     * Example:
     *
     * ```js
     * const content = fetch('./content.txt').then(r => r.text());
     * html`${until(content, html`<span>Loading...</span>`)}`
     * ```
     */
    export const until: (...values: unknown[]) => import('/_102027_/l2/directive.js').DirectiveResult<typeof UntilDirective>;
}
declare module "../l2/when" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    type Falsy = null | undefined | false | 0 | -0 | 0n | '';
    /**
     * When `condition` is true, returns the result of calling `trueCase()`, else
     * returns the result of calling `falseCase()` if `falseCase` is defined.
     *
     * This is a convenience wrapper around a ternary expression that makes it a
     * little nicer to write an inline conditional without an else.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${when(this.user, () => html`User: ${this.user.username}`, () => html`Sign In...`)}
     *   `;
     * }
     * ```
     */
    export function when<C extends Falsy, T, F = undefined>(condition: C, trueCase: (c: C) => T, falseCase?: (c: C) => F): F;
    export function when<C, T, F>(condition: C extends Falsy ? never : C, trueCase: (c: C) => T, falseCase?: (c: C) => F): T;
    export function when<C, T, F = undefined>(condition: C, trueCase: (c: Exclude<C, Falsy>) => T, falseCase?: (c: Extract<C, Falsy>) => F): C extends Falsy ? F : T;
    export {};
}
declare module "_102027_/l2/litElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * The main LitElement module, which defines the {@linkcode LitElement} base
     * class and related APIs.
     *
     * LitElement components can define a template and a set of observed
     * properties. Changing an observed property triggers a re-render of the
     * element.
     *
     * Import {@linkcode LitElement} and {@linkcode html} from this module to
     * create a component:
     *
     *  ```js
     * import {LitElement, html} from 'lit-element';
     *
     * class MyElement extends LitElement {
     *
     *   // Declare observed properties
     *   static get properties() {
     *     return {
     *       adjective: {}
     *     }
     *   }
     *
     *   constructor() {
     *     this.adjective = 'awesome';
     *   }
     *
     *   // Define the element's template
     *   render() {
     *     return html`<p>your ${adjective} template here</p>`;
     *   }
     * }
     *
     * customElements.define('my-element', MyElement);
     * ```
     *
     * `LitElement` extends {@linkcode ReactiveElement} and adds lit-html
     * templating. The `ReactiveElement` class is provided for users that want to
     * build their own custom element base classes that don't use lit-html.
     *
     * @packageDocumentation
     */
    import { PropertyValues, ReactiveElement } from '_102027_/l2/reactiveElement';
    import { RenderOptions, LitUnstable } from '_102027_/l2/litHtml';
    import { ReactiveUnstable } from '_102027_/l2/reactiveElement';
    export * from '_102027_/l2/reactiveElement';
    export * from '_102027_/l2/litHtml';
    export * from '_102027_/l2/classMap';
    export * from '_102027_/l2/ifDefined';
    export * from '_102027_/l2/live';
    export * from '_102027_/l2/styleMap';
    export * from '_102027_/l2/asyncAppend';
    export * from '_102027_/l2/asyncReplace';
    export * from '_102027_/l2/cache';
    export * from '_102027_/l2/choose';
    export * from '_102027_/l2/guard';
    export * from '_102027_/l2/join';
    export * from '_102027_/l2/keyed';
    export * from '_102027_/l2/map';
    export * from '_102027_/l2/range';
    export * from '_102027_/l2/repeat';
    export * from '_102027_/l2/ref';
    export * from '_102027_/l2/templateContent';
    export * from '_102027_/l2/unsafeHtml';
    export * from '_102027_/l2/unsafeSvg';
    export * from '_102027_/l2/until';
    export * from '_102027_/l2/when';
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace Unstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = LitUnstable.DebugLog.Entry | ReactiveUnstable.DebugLog.Entry;
        }
    }
    /**
     * Base element class that manages element properties and attributes, and
     * renders a lit-html template.
     *
     * To define a component, subclass `LitElement` and implement a
     * `render` method to provide the component's template. Define properties
     * using the {@linkcode LitElement.properties properties} property or the
     * {@linkcode property} decorator.
     */
    export class LitElement extends ReactiveElement {
        static ['_$litElement$']: boolean;
        /**
         * @category rendering
         */
        readonly renderOptions: RenderOptions;
        private __childPart;
        /**
         * @category rendering
         */
        protected createRenderRoot(): HTMLElement | DocumentFragment;
        /**
         * Updates the element. This method reflects property values to attributes
         * and calls `render` to render DOM via lit-html. Setting properties inside
         * this method will *not* trigger another update.
         * @param changedProperties Map of changed properties with old values
         * @category updates
         */
        protected update(changedProperties: PropertyValues): void;
        /**
         * Invoked when the component is added to the document's DOM.
         *
         * In `connectedCallback()` you should setup tasks that should only occur when
         * the element is connected to the document. The most common of these is
         * adding event listeners to nodes external to the element, like a keydown
         * event handler added to the window.
         *
         * ```ts
         * connectedCallback() {
         *   super.connectedCallback();
         *   addEventListener('keydown', this._handleKeydown);
         * }
         * ```
         *
         * Typically, anything done in `connectedCallback()` should be undone when the
         * element is disconnected, in `disconnectedCallback()`.
         *
         * @category lifecycle
         */
        connectedCallback(): void;
        /**
         * Invoked when the component is removed from the document's DOM.
         *
         * This callback is the main signal to the element that it may no longer be
         * used. `disconnectedCallback()` should ensure that nothing is holding a
         * reference to the element (such as event listeners added to nodes external
         * to the element), so that it is free to be garbage collected.
         *
         * ```ts
         * disconnectedCallback() {
         *   super.disconnectedCallback();
         *   window.removeEventListener('keydown', this._handleKeydown);
         * }
         * ```
         *
         * An element may be re-connected after being disconnected.
         *
         * @category lifecycle
         */
        disconnectedCallback(): void;
        /**
         * Invoked on each update to perform rendering tasks. This method may return
         * any value renderable by lit-html's `ChildPart` - typically a
         * `TemplateResult`. Setting properties inside this method will *not* trigger
         * the element to update.
         * @category rendering
         */
        protected render(): unknown;
    }
    /**
     * END USERS SHOULD NOT RELY ON THIS OBJECT.
     *
     * Private exports for use by other Lit packages, not intended for use by
     * external users.
     *
     * We currently do not make a mangled rollup build of the lit-ssr code. In order
     * to keep a number of (otherwise private) top-level exports  mangled in the
     * client side code, we export a _$LE object containing those members (or
     * helper methods for accessing private fields of those members), and then
     * re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
     * client-side code is being used in `dev` mode or `prod` mode.
     *
     * This has a unique name, to disambiguate it from private exports in
     * lit-html, since this module re-exports all of lit-html.
     *
     * @private
     */
    export const _$LE: {
        _$attributeToProperty: (el: LitElement, name: string, value: string | null) => void;
        _$changedProperties: (el: LitElement) => any;
    };
}
declare module "_102027_/l2/litHtml" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { Directive } from '_102027_/l2/directive';
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace LitUnstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = TemplatePrep | TemplateInstantiated | TemplateInstantiatedAndUpdated | TemplateUpdating | BeginRender | EndRender | CommitPartEntry | SetPartValue;
            interface TemplatePrep {
                kind: 'template prep';
                template: Template;
                strings: TemplateStringsArray;
                clonableTemplate: HTMLTemplateElement;
                parts: TemplatePart[];
            }
            interface BeginRender {
                kind: 'begin render';
                id: number;
                value: unknown;
                container: HTMLElement | DocumentFragment;
                options: RenderOptions | undefined;
                part: ChildPart | undefined;
            }
            interface EndRender {
                kind: 'end render';
                id: number;
                value: unknown;
                container: HTMLElement | DocumentFragment;
                options: RenderOptions | undefined;
                part: ChildPart;
            }
            interface TemplateInstantiated {
                kind: 'template instantiated';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                fragment: Node;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface TemplateInstantiatedAndUpdated {
                kind: 'template instantiated and updated';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                fragment: Node;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface TemplateUpdating {
                kind: 'template updating';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface SetPartValue {
                kind: 'set part';
                part: Part;
                value: unknown;
                valueIndex: number;
                values: unknown[];
                templateInstance: TemplateInstance;
            }
            type CommitPartEntry = CommitNothingToChildEntry | CommitText | CommitNode | CommitAttribute | CommitProperty | CommitBooleanAttribute | CommitEventListener | CommitToElementBinding;
            interface CommitNothingToChildEntry {
                kind: 'commit nothing to child';
                start: ChildNode;
                end: ChildNode | null;
                parent: Disconnectable | undefined;
                options: RenderOptions | undefined;
            }
            interface CommitText {
                kind: 'commit text';
                node: Text;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitNode {
                kind: 'commit node';
                start: Node;
                parent: Disconnectable | undefined;
                value: Node;
                options: RenderOptions | undefined;
            }
            interface CommitAttribute {
                kind: 'commit attribute';
                element: Element;
                name: string;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitProperty {
                kind: 'commit property';
                element: Element;
                name: string;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitBooleanAttribute {
                kind: 'commit boolean attribute';
                element: Element;
                name: string;
                value: boolean;
                options: RenderOptions | undefined;
            }
            interface CommitEventListener {
                kind: 'commit event listener';
                element: Element;
                name: string;
                value: unknown;
                oldListener: unknown;
                options: RenderOptions | undefined;
                removeListener: boolean;
                addListener: boolean;
            }
            interface CommitToElementBinding {
                kind: 'commit to element binding';
                element: Element;
                value: unknown;
                options: RenderOptions | undefined;
            }
        }
    }
    /**
     * Used to sanitize any value before it is written into the DOM. This can be
     * used to implement a security policy of allowed and disallowed values in
     * order to prevent XSS attacks.
     *
     * One way of using this callback would be to check attributes and properties
     * against a list of high risk fields, and require that values written to such
     * fields be instances of a class which is safe by construction. Closure's Safe
     * HTML Types is one implementation of this technique (
     * https://github.com/google/safe-html-types/blob/master/doc/safehtml-types.md).
     * The TrustedTypes polyfill in API-only mode could also be used as a basis
     * for this technique (https://github.com/WICG/trusted-types).
     *
     * @param node The HTML node (usually either a #text node or an Element) that
     *     is being written to. Note that this is just an exemplar node, the write
     *     may take place against another instance of the same class of node.
     * @param name The name of an attribute or property (for example, 'href').
     * @param type Indicates whether the write that's about to be performed will
     *     be to a property or a node.
     * @return A function that will sanitize this class of writes.
     */
    export type SanitizerFactory = (node: Node, name: string, type: 'property' | 'attribute') => ValueSanitizer;
    /**
     * A function which can sanitize values that will be written to a specific kind
     * of DOM sink.
     *
     * See SanitizerFactory.
     *
     * @param value The value to sanitize. Will be the actual value passed into
     *     the lit-html template literal, so this could be of any type.
     * @return The value to write to the DOM. Usually the same as the input value,
     *     unless sanitization is needed.
     */
    export type ValueSanitizer = (value: unknown) => unknown;
    /** TemplateResult types */
    const HTML_RESULT = 1;
    const SVG_RESULT = 2;
    const MATHML_RESULT = 3;
    type ResultType = typeof HTML_RESULT | typeof SVG_RESULT | typeof MATHML_RESULT;
    const ATTRIBUTE_PART = 1;
    const CHILD_PART = 2;
    const PROPERTY_PART = 3;
    const BOOLEAN_ATTRIBUTE_PART = 4;
    const EVENT_PART = 5;
    const ELEMENT_PART = 6;
    const COMMENT_PART = 7;
    /**
     * The return type of the template tag functions, {@linkcode html} and
     * {@linkcode svg} when it hasn't been compiled by @lit-labs/compiler.
     *
     * A `TemplateResult` object holds all the information about a template
     * expression required to render it: the template strings, expression values,
     * and type of template (html or svg).
     *
     * `TemplateResult` objects do not create any DOM on their own. To create or
     * update DOM you need to render the `TemplateResult`. See
     * [Rendering](https://lit.dev/docs/components/rendering) for more information.
     *
     */
    export type UncompiledTemplateResult<T extends ResultType = ResultType> = {
        ['_$litType$']: T;
        strings: TemplateStringsArray;
        values: unknown[];
    };
    /**
     * This is a template result that may be either uncompiled or compiled.
     *
     * In the future, TemplateResult will be this type. If you want to explicitly
     * note that a template result is potentially compiled, you can reference this
     * type and it will continue to behave the same through the next major version
     * of Lit. This can be useful for code that wants to prepare for the next
     * major version of Lit.
     */
    export type MaybeCompiledTemplateResult<T extends ResultType = ResultType> = UncompiledTemplateResult<T> | CompiledTemplateResult;
    /**
     * The return type of the template tag functions, {@linkcode html} and
     * {@linkcode svg}.
     *
     * A `TemplateResult` object holds all the information about a template
     * expression required to render it: the template strings, expression values,
     * and type of template (html or svg).
     *
     * `TemplateResult` objects do not create any DOM on their own. To create or
     * update DOM you need to render the `TemplateResult`. See
     * [Rendering](https://lit.dev/docs/components/rendering) for more information.
     *
     * In Lit 4, this type will be an alias of
     * MaybeCompiledTemplateResult, so that code will get type errors if it assumes
     * that Lit templates are not compiled. When deliberately working with only
     * one, use either {@linkcode CompiledTemplateResult} or
     * {@linkcode UncompiledTemplateResult} explicitly.
     */
    export type TemplateResult<T extends ResultType = ResultType> = UncompiledTemplateResult<T>;
    export type HTMLTemplateResult = TemplateResult<typeof HTML_RESULT>;
    export type SVGTemplateResult = TemplateResult<typeof SVG_RESULT>;
    export type MathMLTemplateResult = TemplateResult<typeof MATHML_RESULT>;
    /**
     * A TemplateResult that has been compiled by @lit-labs/compiler, skipping the
     * prepare step.
     */
    export interface CompiledTemplateResult {
        ['_$litType$']: CompiledTemplate;
        values: unknown[];
    }
    export interface CompiledTemplate extends Omit<Template, 'el'> {
        el?: HTMLTemplateElement;
        h: TemplateStringsArray;
    }
    /**
     * Interprets a template literal as an HTML template that can efficiently
     * render to and update a container.
     *
     * ```ts
     * const header = (title: string) => html`<h1>${title}</h1>`;
     * ```
     *
     * The `html` tag returns a description of the DOM to render as a value. It is
     * lazy, meaning no work is done until the template is rendered. When rendering,
     * if a template comes from the same expression as a previously rendered result,
     * it's efficiently updated instead of replaced.
     */
    export const html: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<1>;
    /**
     * Interprets a template literal as an SVG fragment that can efficiently render
     * to and update a container.
     *
     * ```ts
     * const rect = svg`<rect width="10" height="10"></rect>`;
     *
     * const myImage = html`
     *   <svg viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg">
     *     ${rect}
     *   </svg>`;
     * ```
     *
     * The `svg` *tag function* should only be used for SVG fragments, or elements
     * that would be contained **inside** an `<svg>` HTML element. A common error is
     * placing an `<svg>` *element* in a template tagged with the `svg` tag
     * function. The `<svg>` element is an HTML element and should be used within a
     * template tagged with the {@linkcode html} tag function.
     *
     * In LitElement usage, it's invalid to return an SVG fragment from the
     * `render()` method, as the SVG fragment will be contained within the element's
     * shadow root and thus not be properly contained within an `<svg>` HTML
     * element.
     */
    export const svg: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<2>;
    /**
     * Interprets a template literal as MathML fragment that can efficiently render
     * to and update a container.
     *
     * ```ts
     * const num = mathml`<mn>1</mn>`;
     *
     * const eq = html`
     *   <math>
     *     ${num}
     *   </math>`;
     * ```
     *
     * The `mathml` *tag function* should only be used for MathML fragments, or
     * elements that would be contained **inside** a `<math>` HTML element. A common
     * error is placing a `<math>` *element* in a template tagged with the `mathml`
     * tag function. The `<math>` element is an HTML element and should be used
     * within a template tagged with the {@linkcode html} tag function.
     *
     * In LitElement usage, it's invalid to return an MathML fragment from the
     * `render()` method, as the MathML fragment will be contained within the
     * element's shadow root and thus not be properly contained within a `<math>`
     * HTML element.
     */
    export const mathml: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<3>;
    /**
     * A sentinel value that signals that a value was handled by a directive and
     * should not be written to the DOM.
     */
    export const noChange: unique symbol;
    /**
     * A sentinel value that signals a ChildPart to fully clear its content.
     *
     * ```ts
     * const button = html`${
     *  user.isAdmin
     *    ? html`<button>DELETE</button>`
     *    : nothing
     * }`;
     * ```
     *
     * Prefer using `nothing` over other falsy values as it provides a consistent
     * behavior between various expression binding contexts.
     *
     * In child expressions, `undefined`, `null`, `''`, and `nothing` all behave the
     * same and render no nodes. In attribute expressions, `nothing` _removes_ the
     * attribute, while `undefined` and `null` will render an empty string. In
     * property expressions `nothing` becomes `undefined`.
     */
    export const nothing: unique symbol;
    /**
     * Object specifying options for controlling lit-html rendering. Note that
     * while `render` may be called multiple times on the same `container` (and
     * `renderBefore` reference node) to efficiently update the rendered content,
     * only the options passed in during the first render are respected during
     * the lifetime of renders to that unique `container` + `renderBefore`
     * combination.
     */
    export interface RenderOptions {
        /**
         * An object to use as the `this` value for event listeners. It's often
         * useful to set this to the host component rendering a template.
         */
        host?: object;
        /**
         * A DOM node before which to render content in the container.
         */
        renderBefore?: ChildNode | null;
        /**
         * Node used for cloning the template (`importNode` will be called on this
         * node). This controls the `ownerDocument` of the rendered DOM, along with
         * any inherited context. Defaults to the global `document`.
         */
        creationScope?: {
            importNode(node: Node, deep?: boolean): Node;
        };
        /**
         * The initial connected state for the top-level part being rendered. If no
         * `isConnected` option is set, `AsyncDirective`s will be connected by
         * default. Set to `false` if the initial render occurs in a disconnected tree
         * and `AsyncDirective`s should see `isConnected === false` for their initial
         * render. The `part.setConnected()` method must be used subsequent to initial
         * render to change the connected state of the part.
         */
        isConnected?: boolean;
    }
    export interface DirectiveParent {
        _$parent?: DirectiveParent;
        _$isConnected: boolean;
        __directive?: Directive;
        __directives?: Array<Directive | undefined>;
    }
    class Template {
        parts: Array<TemplatePart>;
        constructor({ strings, _$litType$ }: UncompiledTemplateResult, options?: RenderOptions);
        static createElement(html: any, _options?: RenderOptions): HTMLTemplateElement;
    }
    export interface Disconnectable {
        _$parent?: Disconnectable;
        _$disconnectableChildren?: Set<Disconnectable>;
        _$isConnected: boolean;
    }
    function resolveDirective(part: ChildPart | AttributePart | ElementPart, value: unknown, parent?: DirectiveParent, attributeIndex?: number): unknown;
    export type { TemplateInstance };
    /**
     * An updateable instance of a Template. Holds references to the Parts used to
     * update the template instance.
     */
    class TemplateInstance implements Disconnectable {
        _$template: Template;
        _$parts: Array<Part | undefined>;
        constructor(template: Template, parent: ChildPart);
        get parentNode(): Node;
        get _$isConnected(): boolean;
        _clone(options: RenderOptions | undefined): Node;
        _update(values: Array<unknown>): void;
    }
    type AttributeTemplatePart = {
        readonly type: typeof ATTRIBUTE_PART;
        readonly index: number;
        readonly name: string;
        readonly ctor: typeof AttributePart;
        readonly strings: ReadonlyArray<string>;
    };
    type ChildTemplatePart = {
        readonly type: typeof CHILD_PART;
        readonly index: number;
    };
    type ElementTemplatePart = {
        readonly type: typeof ELEMENT_PART;
        readonly index: number;
    };
    type CommentTemplatePart = {
        readonly type: typeof COMMENT_PART;
        readonly index: number;
    };
    /**
     * A TemplatePart represents a dynamic part in a template, before the template
     * is instantiated. When a template is instantiated Parts are created from
     * TemplateParts.
     */
    type TemplatePart = ChildTemplatePart | AttributeTemplatePart | ElementTemplatePart | CommentTemplatePart;
    export type Part = ChildPart | AttributePart | PropertyPart | BooleanAttributePart | ElementPart | EventPart;
    export type { ChildPart };
    class ChildPart implements Disconnectable {
        readonly type = 2;
        readonly options: RenderOptions | undefined;
        _$committedValue: unknown;
        private _textSanitizer;
        get _$isConnected(): boolean;
        constructor(startNode: ChildNode, endNode: ChildNode | null, parent: TemplateInstance | ChildPart | undefined, options: RenderOptions | undefined);
        /**
         * The parent node into which the part renders its content.
         *
         * A ChildPart's content consists of a range of adjacent child nodes of
         * `.parentNode`, possibly bordered by 'marker nodes' (`.startNode` and
         * `.endNode`).
         *
         * - If both `.startNode` and `.endNode` are non-null, then the part's content
         * consists of all siblings between `.startNode` and `.endNode`, exclusively.
         *
         * - If `.startNode` is non-null but `.endNode` is null, then the part's
         * content consists of all siblings following `.startNode`, up to and
         * including the last child of `.parentNode`. If `.endNode` is non-null, then
         * `.startNode` will always be non-null.
         *
         * - If both `.endNode` and `.startNode` are null, then the part's content
         * consists of all child nodes of `.parentNode`.
         */
        get parentNode(): Node;
        /**
         * The part's leading marker node, if any. See `.parentNode` for more
         * information.
         */
        get startNode(): Node | null;
        /**
         * The part's trailing marker node, if any. See `.parentNode` for more
         * information.
         */
        get endNode(): Node | null;
        _$setValue(value: unknown, directiveParent?: DirectiveParent): void;
        private _insert;
        private _commitNode;
        private _commitText;
        private _commitTemplateResult;
        private _commitIterable;
    }
    /**
     * A top-level `ChildPart` returned from `render` that manages the connected
     * state of `AsyncDirective`s created throughout the tree below it.
     */
    export interface RootPart extends ChildPart {
        /**
         * Sets the connection state for `AsyncDirective`s contained within this root
         * ChildPart.
         *
         * lit-html does not automatically monitor the connectedness of DOM rendered;
         * as such, it is the responsibility of the caller to `render` to ensure that
         * `part.setConnected(false)` is called before the part object is potentially
         * discarded, to ensure that `AsyncDirective`s have a chance to dispose of
         * any resources being held. If a `RootPart` that was previously
         * disconnected is subsequently re-connected (and its `AsyncDirective`s should
         * re-connect), `setConnected(true)` should be called.
         *
         * @param isConnected Whether directives within this tree should be connected
         * or not
         */
        setConnected(isConnected: boolean): void;
    }
    export type { AttributePart };
    class AttributePart implements Disconnectable {
        readonly type: typeof ATTRIBUTE_PART | typeof PROPERTY_PART | typeof BOOLEAN_ATTRIBUTE_PART | typeof EVENT_PART;
        readonly element: HTMLElement;
        readonly name: string;
        readonly options: RenderOptions | undefined;
        /**
         * If this attribute part represents an interpolation, this contains the
         * static strings of the interpolation. For single-value, complete bindings,
         * this is undefined.
         */
        readonly strings?: ReadonlyArray<string>;
        protected _sanitizer: ValueSanitizer | undefined;
        get tagName(): string;
        get _$isConnected(): boolean;
        constructor(element: HTMLElement, name: string, strings: ReadonlyArray<string>, parent: Disconnectable, options: RenderOptions | undefined);
    }
    export type { PropertyPart };
    class PropertyPart extends AttributePart {
        readonly type = 3;
    }
    export type { BooleanAttributePart };
    class BooleanAttributePart extends AttributePart {
        readonly type = 4;
    }
    /**
     * An AttributePart that manages an event listener via add/removeEventListener.
     *
     * This part works by adding itself as the event listener on an element, then
     * delegating to the value passed to it. This reduces the number of calls to
     * add/removeEventListener if the listener changes frequently, such as when an
     * inline function is used as a listener.
     *
     * Because event options are passed when adding listeners, we must take case
     * to add and remove the part as a listener when the event options change.
     */
    export type { EventPart };
    class EventPart extends AttributePart {
        readonly type = 5;
        constructor(element: HTMLElement, name: string, strings: ReadonlyArray<string>, parent: Disconnectable, options: RenderOptions | undefined);
        handleEvent(event: Event): void;
    }
    export type { ElementPart };
    class ElementPart implements Disconnectable {
        element: Element;
        readonly type = 6;
        _$committedValue: undefined;
        options: RenderOptions | undefined;
        constructor(element: Element, parent: Disconnectable, options: RenderOptions | undefined);
        get _$isConnected(): boolean;
        _$setValue(value: unknown): void;
    }
    /**
     * END USERS SHOULD NOT RELY ON THIS OBJECT.
     *
     * Private exports for use by other Lit packages, not intended for use by
     * external users.
     *
     * We currently do not make a mangled rollup build of the lit-ssr code. In order
     * to keep a number of (otherwise private) top-level exports mangled in the
     * client side code, we export a _$LH object containing those members (or
     * helper methods for accessing private fields of those members), and then
     * re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
     * client-side code is being used in `dev` mode or `prod` mode.
     *
     * This has a unique name, to disambiguate it from private exports in
     * lit-element, which re-exports all of lit-html.
     *
     * @private
     */
    export const _$LH: {
        _boundAttributeSuffix: string;
        _marker: string;
        _markerMatch: string;
        _HTML_RESULT: number;
        _getTemplateHtml: (strings: TemplateStringsArray, type: ResultType) => [any, Array<string>];
        _TemplateInstance: typeof TemplateInstance;
        _isIterable: (value: unknown) => value is Iterable<unknown>;
        _resolveDirective: typeof resolveDirective;
        _ChildPart: typeof ChildPart;
        _AttributePart: typeof AttributePart;
        _BooleanAttributePart: typeof BooleanAttributePart;
        _EventPart: typeof EventPart;
        _PropertyPart: typeof PropertyPart;
        _ElementPart: typeof ElementPart;
    };
    /**
     * Renders a value, usually a lit-html TemplateResult, to the container.
     *
     * This example renders the text "Hello, Zoe!" inside a paragraph tag, appending
     * it to the container `document.body`.
     *
     * ```js
     * import {html, render} from 'lit';
     *
     * const name = "Zoe";
     * render(html`<p>Hello, ${name}!</p>`, document.body);
     * ```
     *
     * @param value Any [renderable
     *   value](https://lit.dev/docs/templates/expressions/#child-expressions),
     *   typically a {@linkcode TemplateResult} created by evaluating a template tag
     *   like {@linkcode html} or {@linkcode svg}.
     * @param container A DOM container to render to. The first render will append
     *   the rendered value to the container, and subsequent renders will
     *   efficiently update the rendered value if the same result type was
     *   previously rendered there.
     * @param options See {@linkcode RenderOptions} for options documentation.
     * @see
     * {@link https://lit.dev/docs/libraries/standalone-templates/#rendering-lit-html-templates| Rendering Lit HTML Templates}
     */
    export const render: {
        (value: unknown, container: HTMLElement | DocumentFragment, options?: RenderOptions): RootPart;
        setSanitizer: (newSanitizer: SanitizerFactory) => void;
        createSanitizer: SanitizerFactory;
        _testOnlyClearSanitizerFactoryDoNotCallOrElse: () => void;
    };
}
declare module "_102027_/l2/live" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    class LiveDirective extends Directive {
        constructor(partInfo: PartInfo);
        render(value: unknown): unknown;
        update(part: AttributePart, [value]: DirectiveParameters<this>): unknown;
    }
    /**
     * Checks binding values against live DOM values, instead of previously bound
     * values, when determining whether to update the value.
     *
     * This is useful for cases where the DOM value may change from outside of
     * lit-html, such as with a binding to an `<input>` element's `value` property,
     * a content editable elements text, or to a custom element that changes it's
     * own properties or attributes.
     *
     * In these cases if the DOM value changes, but the value set through lit-html
     * bindings hasn't, lit-html won't know to update the DOM value and will leave
     * it alone. If this is not what you want--if you want to overwrite the DOM
     * value with the bound value no matter what--use the `live()` directive:
     *
     * ```js
     * html`<input .value=${live(x)}>`
     * ```
     *
     * `live()` performs a strict equality check against the live DOM value, and if
     * the new value is equal to the live value, does nothing. This means that
     * `live()` should not be used when the binding will cause a type conversion. If
     * you use `live()` with an attribute binding, make sure that only strings are
     * passed in, or the binding will update every render.
     */
    export const live: (value: unknown) => import("/_102027_/l2/directive.js").DirectiveResult<typeof LiveDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { LiveDirective };
}
declare module "_102027_/l2/map" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Returns an iterable containing the result of calling `f(value)` on each
     * value in `items`.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     <ul>
     *       ${map(items, (i) => html`<li>${i}</li>`)}
     *     </ul>
     *   `;
     * }
     * ```
     */
    export function map<T>(items: Iterable<T> | undefined, f: (value: T, index: number) => unknown): Generator<unknown, void, unknown>;
}
declare module "_102027_/l2/pluginBase" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export abstract class PluginBase extends CollabLitElement {
        scope: string;
        abstract description: string;
        abstract getSvg(): TemplateResult;
    }
}
declare module "_102027_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_102027_/l2/polyfillSupport" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * ReactiveElement patch to support browsers without native web components.
     *
     * This module should be used in addition to loading the web components
     * polyfills via @webcomponents/webcomponentjs. When using those polyfills
     * support for polyfilled Shadow DOM is automatic via the ShadyDOM polyfill, but
     * support for Shadow DOM like css scoping is opt-in. This module uses ShadyCSS
     * to scope styles defined via the `static styles` property.
     *
     * @packageDocumentation
     */
    export {};
}
declare module "_102027_/l2/previewBase" {
    export abstract class PreviewModeBase {
        protected level: string | undefined;
        protected iFrame: HTMLIFrameElement | undefined;
        protected isService: boolean;
        protected storFile: mls.stor.IFileInfo | undefined;
        constructor(_iFrame: HTMLIFrameElement, _level: string, _isService: boolean, _storFile: mls.stor.IFileInfo);
        abstract init(): Promise<void>;
    }
}
declare module "_102027_/l2/privateAsyncHelpers" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Helper to iterate an AsyncIterable in its own closure.
     * @param iterable The iterable to iterate
     * @param callback The callback to call for each value. If the callback returns
     * `false`, the loop will be broken.
     */
    export const forAwaitOf: <T>(iterable: AsyncIterable<T>, callback: (value: T) => Promise<boolean>) => Promise<void>;
    /**
     * Holds a reference to an instance that can be disconnected and reconnected,
     * so that a closure over the ref (e.g. in a then function to a promise) does
     * not strongly hold a ref to the instance. Approximates a WeakRef but must
     * be manually connected & disconnected to the backing instance.
     */
    export class PseudoWeakRef<T> {
        private _ref?;
        constructor(ref: T);
        /**
         * Disassociates the ref with the backing instance.
         */
        disconnect(): void;
        /**
         * Reassociates the ref with the backing instance.
         */
        reconnect(ref: T): void;
        /**
         * Retrieves the backing instance (will be undefined when disconnected)
         */
        deref(): T | undefined;
    }
    /**
     * A helper to pause and resume waiting on a condition in an async function
     */
    export class Pauser {
        private _promise?;
        private _resolve?;
        /**
         * When paused, returns a promise to be awaited; when unpaused, returns
         * undefined. Note that in the microtask between the pauser being resumed
         * an await of this promise resolving, the pauser could be paused again,
         * hence callers should check the promise in a loop when awaiting.
         * @returns A promise to be awaited when paused or undefined
         */
        get(): Promise<void> | undefined;
        /**
         * Creates a promise to be awaited
         */
        pause(): void;
        /**
         * Resolves the promise which may be awaited
         */
        resume(): void;
    }
}
declare module "_102027_/l2/privateSsrSupport" {
    /**
     * @license
     * Copyright 2019 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Directive, PartInfo, DirectiveClass, DirectiveResult } from '_102027_/l2/directive';
    import { AttributePart, Part, Disconnectable } from '_102027_/l2/litHtml';
    import type { PropertyPart, ChildPart, BooleanAttributePart, EventPart, ElementPart, TemplateInstance } from '_102027_/l2/litHtml';
    /**
     * END USERS SHOULD NOT RELY ON THIS OBJECT.
     *
     * We currently do not make a mangled rollup build of the lit-ssr code. In order
     * to keep a number of (otherwise private) top-level exports mangled in the
     * client side code, we export a _$LH object containing those members (or
     * helper methods for accessing private fields of those members), and then
     * re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
     * client-side code is being used in `dev` mode or `prod` mode.
     * @private
     */
    export const _$LH: {
        boundAttributeSuffix: string;
        marker: string;
        markerMatch: string;
        HTML_RESULT: number;
        getTemplateHtml: (strings: TemplateStringsArray, type: 1 | 2 | 3) => [any, Array<string>];
        overrideDirectiveResolve: (directiveClass: new (part: PartInfo) => Directive & {
            render(): unknown;
        }, resolveOverrideFn: (directive: Directive, values: unknown[]) => unknown) => {
            new (part: PartInfo): {
                _$resolve(this: Directive, _part: Part, values: unknown[]): unknown;
                __part: Part;
                __attributeIndex: number | undefined;
                __directive?: Directive;
                _$parent: Disconnectable;
                _$disconnectableChildren?: Set<Disconnectable>;
                _$notifyDirectiveConnectionChanged?(isConnected: boolean): void;
                readonly _$isConnected: boolean;
                _$initialize(part: Part, parent: Disconnectable, attributeIndex: number | undefined): void;
                render: ((...props: Array<unknown>) => unknown) & (() => unknown);
                update(_part: Part, props: Array<unknown>): unknown;
            };
        };
        patchDirectiveResolve: (directiveClass: typeof Directive, resolveOverrideFn: (this: Directive, _part: Part, values: unknown[]) => unknown) => void;
        setDirectiveClass(value: DirectiveResult, directiveClass: DirectiveClass): void;
        getAttributePartCommittedValue: (part: AttributePart, value: unknown, index: number | undefined) => unknown;
        connectedDisconnectable: (props?: object) => Disconnectable;
        resolveDirective: (part: ChildPart | AttributePart | ElementPart, value: unknown, parent?: import("/_102027_/l2/litHtml.js").DirectiveParent, attributeIndex?: number) => unknown;
        AttributePart: typeof AttributePart;
        PropertyPart: typeof PropertyPart;
        BooleanAttributePart: typeof BooleanAttributePart;
        EventPart: typeof EventPart;
        ElementPart: typeof ElementPart;
        TemplateInstance: typeof TemplateInstance;
        isIterable: (value: unknown) => value is Iterable<unknown>;
        ChildPart: typeof ChildPart;
    };
}
declare module "_102027_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102027_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102027_/l2/property" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { type PropertyDeclaration, type ReactiveElement } from '_102027_/l2/reactiveElement';
    import type { Interface } from '_102027_/l2/base';
    export type PropertyDecorator = {
        <C extends Interface<ReactiveElement>, V>(target: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
        <C extends Interface<ReactiveElement>, V>(target: (value: V) => void, context: ClassSetterDecoratorContext<C, V>): (this: C, value: V) => void;
        (protoOrDescriptor: Object, name: PropertyKey, descriptor?: PropertyDescriptor): any;
    };
    type StandardPropertyContext<C, V> = (ClassAccessorDecoratorContext<C, V> | ClassSetterDecoratorContext<C, V>) & {
        metadata: object;
    };
    /**
     * Wraps a class accessor or setter so that `requestUpdate()` is called with the
     * property name and old value when the accessor is set.
     */
    export const standardProperty: <C extends Interface<ReactiveElement>, V>(options: PropertyDeclaration | undefined, target: ClassAccessorDecoratorTarget<C, V> | ((value: V) => void), context: StandardPropertyContext<C, V>) => ClassAccessorDecoratorResult<C, V> | ((this: C, value: V) => void);
    /**
     * A class field or accessor decorator which creates a reactive property that
     * reflects a corresponding attribute value. When a decorated property is set
     * the element will update and render. A {@linkcode PropertyDeclaration} may
     * optionally be supplied to configure property features.
     *
     * This decorator should only be used for public fields. As public fields,
     * properties should be considered as primarily settable by element users,
     * either via attribute or the property itself.
     *
     * Generally, properties that are changed by the element should be private or
     * protected fields and should use the {@linkcode state} decorator.
     *
     * However, sometimes element code does need to set a public property. This
     * should typically only be done in response to user interaction, and an event
     * should be fired informing the user; for example, a checkbox sets its
     * `checked` property when clicked and fires a `changed` event. Mutating public
     * properties should typically not be done for non-primitive (object or array)
     * properties. In other cases when an element needs to manage state, a private
     * property decorated via the {@linkcode state} decorator should be used. When
     * needed, state properties can be initialized via public properties to
     * facilitate complex interactions.
     *
     * ```ts
     * class MyElement {
     *   @property({ type: Boolean })
     *   clicked = false;
     * }
     * ```
     * @category Decorator
     * @ExportDecoratedItems
     */
    export function property(options?: PropertyDeclaration): PropertyDecorator;
    export {};
}
declare module "_102027_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102027_/l2/query" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    export type QueryDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Element | null>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter that
     * executes a querySelector on the element's renderRoot.
     *
     * @param selector A DOMString containing one or more selectors to match.
     * @param cache An optional boolean which when true performs the DOM query only
     *     once and caches the result.
     *
     * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
     *
     * ```ts
     * class MyElement {
     *   @query('#first')
     *   first: HTMLDivElement;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function query(selector: string, cache?: boolean): QueryDecorator;
}
declare module "_102027_/l2/queryAll" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    export type QueryAllDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends NodeList>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter
     * that executes a querySelectorAll on the element's renderRoot.
     *
     * @param selector A DOMString containing one or more selectors to match.
     *
     * See:
     * https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelectorAll
     *
     * ```ts
     * class MyElement {
     *   @queryAll('div')
     *   divs: NodeListOf<HTMLDivElement>;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function queryAll(selector: string): QueryAllDecorator;
}
declare module "_102027_/l2/queryAssignedElements" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import type { QueryAssignedNodesOptions } from '_102027_/l2/queryAssignedNodes';
    import { type Interface } from '_102027_/l2/base';
    export type QueryAssignedElementsDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Array<Element>>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * Options for the {@linkcode queryAssignedElements} decorator. Extends the
     * options that can be passed into
     * [HTMLSlotElement.assignedElements](https://developer.mozilla.org/en-US/docs/Web/API/HTMLSlotElement/assignedElements).
     */
    export interface QueryAssignedElementsOptions extends QueryAssignedNodesOptions {
        /**
         * CSS selector used to filter the elements returned. For example, a selector
         * of `".item"` will only include elements with the `item` class.
         */
        selector?: string;
    }
    /**
     * A property decorator that converts a class property into a getter that
     * returns the `assignedElements` of the given `slot`. Provides a declarative
     * way to use
     * [`HTMLSlotElement.assignedElements`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLSlotElement/assignedElements).
     *
     * Can be passed an optional {@linkcode QueryAssignedElementsOptions} object.
     *
     * Example usage:
     * ```ts
     * class MyElement {
     *   @queryAssignedElements({ slot: 'list' })
     *   listItems!: Array<HTMLElement>;
     *   @queryAssignedElements()
     *   unnamedSlotEls!: Array<HTMLElement>;
     *
     *   render() {
     *     return html`
     *       <slot name="list"></slot>
     *       <slot></slot>
     *     `;
     *   }
     * }
     * ```
     *
     * Note, the type of this property should be annotated as `Array<HTMLElement>`.
     *
     * @category Decorator
     */
    export function queryAssignedElements(options?: QueryAssignedElementsOptions): QueryAssignedElementsDecorator;
}
declare module "_102027_/l2/queryAssignedNodes" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    /**
     * Options for the {@linkcode queryAssignedNodes} decorator. Extends the options
     * that can be passed into [HTMLSlotElement.assignedNodes](https://developer.mozilla.org/en-US/docs/Web/API/HTMLSlotElement/assignedNodes).
     */
    export interface QueryAssignedNodesOptions extends AssignedNodesOptions {
        /**
         * Name of the slot to query. Leave empty for the default slot.
         */
        slot?: string;
    }
    export type QueryAssignedNodesDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Array<Node>>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter that
     * returns the `assignedNodes` of the given `slot`.
     *
     * Can be passed an optional {@linkcode QueryAssignedNodesOptions} object.
     *
     * Example usage:
     * ```ts
     * class MyElement {
     *   @queryAssignedNodes({slot: 'list', flatten: true})
     *   listItems!: Array<Node>;
     *
     *   render() {
     *     return html`
     *       <slot name="list"></slot>
     *     `;
     *   }
     * }
     * ```
     *
     * Note the type of this property should be annotated as `Array<Node>`. Use the
     * queryAssignedElements decorator to list only elements, and optionally filter
     * the element list using a CSS selector.
     *
     * @category Decorator
     */
    export function queryAssignedNodes(options?: QueryAssignedNodesOptions): QueryAssignedNodesDecorator;
}
declare module "_102027_/l2/queryAsync" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import type { ReactiveElement } from '_102027_/l2/reactiveElement';
    import { type Interface } from '_102027_/l2/base';
    export type QueryAsyncDecorator = {
        (proto: Interface<ReactiveElement>, name: PropertyKey, descriptor?: PropertyDescriptor): void | any;
        <C extends Interface<ReactiveElement>, V extends Promise<Element | null>>(value: ClassAccessorDecoratorTarget<C, V>, context: ClassAccessorDecoratorContext<C, V>): ClassAccessorDecoratorResult<C, V>;
    };
    /**
     * A property decorator that converts a class property into a getter that
     * returns a promise that resolves to the result of a querySelector on the
     * element's renderRoot done after the element's `updateComplete` promise
     * resolves. When the queried property may change with element state, this
     * decorator can be used instead of requiring users to await the
     * `updateComplete` before accessing the property.
     *
     * @param selector A DOMString containing one or more selectors to match.
     *
     * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
     *
     * ```ts
     * class MyElement {
     *   @queryAsync('#first')
     *   first: Promise<HTMLDivElement>;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     *
     * // external usage
     * async doSomethingWithFirst() {
     *  (await aMyElement.first).doSomething();
     * }
     * ```
     * @category Decorator
     */
    export function queryAsync(selector: string): QueryAsyncDecorator;
}
declare module "_102027_/l2/range" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Returns an iterable of integers from `start` to `end` (exclusive)
     * incrementing by `step`.
     *
     * If `start` is omitted, the range starts at `0`. `step` defaults to `1`.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${map(range(8), () => html`<div class="cell"></div>`)}
     *   `;
     * }
     * ```
     */
    export function range(end: number): Iterable<number>;
    export function range(start: number, end: number, step?: number): Iterable<number>;
}
declare module "_102027_/l2/reactiveController" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * An object that can host Reactive Controllers and call their lifecycle
     * callbacks.
     */
    export interface ReactiveControllerHost {
        /**
         * Adds a controller to the host, which sets up the controller's lifecycle
         * methods to be called with the host's lifecycle.
         */
        addController(controller: ReactiveController): void;
        /**
         * Removes a controller from the host.
         */
        removeController(controller: ReactiveController): void;
        /**
         * Requests a host update which is processed asynchronously. The update can
         * be waited on via the `updateComplete` property.
         */
        requestUpdate(): void;
        /**
         * Returns a Promise that resolves when the host has completed updating.
         * The Promise value is a boolean that is `true` if the element completed the
         * update without triggering another update. The Promise result is `false` if
         * a property was set inside `updated()`. If the Promise is rejected, an
         * exception was thrown during the update.
         *
         * @return A promise of a boolean that indicates if the update resolved
         *     without triggering another update.
         */
        readonly updateComplete: Promise<boolean>;
    }
    /**
     * A Reactive Controller is an object that enables sub-component code
     * organization and reuse by aggregating the state, behavior, and lifecycle
     * hooks related to a single feature.
     *
     * Controllers are added to a host component, or other object that implements
     * the `ReactiveControllerHost` interface, via the `addController()` method.
     * They can hook their host components's lifecycle by implementing one or more
     * of the lifecycle callbacks, or initiate an update of the host component by
     * calling `requestUpdate()` on the host.
     */
    export interface ReactiveController {
        /**
         * Called when the host is connected to the component tree. For custom
         * element hosts, this corresponds to the `connectedCallback()` lifecycle,
         * which is only called when the component is connected to the document.
         */
        hostConnected?(): void;
        /**
         * Called when the host is disconnected from the component tree. For custom
         * element hosts, this corresponds to the `disconnectedCallback()` lifecycle,
         * which is called the host or an ancestor component is disconnected from the
         * document.
         */
        hostDisconnected?(): void;
        /**
         * Called during the client-side host update, just before the host calls
         * its own update.
         *
         * Code in `update()` can depend on the DOM as it is not called in
         * server-side rendering.
         */
        hostUpdate?(): void;
        /**
         * Called after a host update, just before the host calls firstUpdated and
         * updated. It is not called in server-side rendering.
         *
         */
        hostUpdated?(): void;
    }
}
declare module "_102027_/l2/reactiveElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Use this module if you want to create your own base class extending
     * {@link ReactiveElement}.
     * @packageDocumentation
     */
    import { CSSResultGroup, CSSResultOrNative } from '_102027_/l2/cssTag';
    import type { ReactiveController, ReactiveControllerHost } from '_102027_/l2/reactiveController';
    export * from '_102027_/l2/cssTag';
    export type { ReactiveController, ReactiveControllerHost, } from '_102027_/l2/reactiveController';
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace ReactiveUnstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = Update;
            interface Update {
                kind: 'update';
            }
        }
    }
    /**
     * Converts property values to and from attribute values.
     */
    export interface ComplexAttributeConverter<Type = unknown, TypeHint = unknown> {
        /**
         * Called to convert an attribute value to a property
         * value.
         */
        fromAttribute?(value: string | null, type?: TypeHint): Type;
        /**
         * Called to convert a property value to an attribute
         * value.
         *
         * It returns unknown instead of string, to be compatible with
         * https://github.com/WICG/trusted-types (and similar efforts).
         */
        toAttribute?(value: Type, type?: TypeHint): unknown;
    }
    type AttributeConverter<Type = unknown, TypeHint = unknown> = ComplexAttributeConverter<Type> | ((value: string | null, type?: TypeHint) => Type);
    /**
     * Defines options for a property accessor.
     */
    export interface PropertyDeclaration<Type = unknown, TypeHint = unknown> {
        /**
         * When set to `true`, indicates the property is internal private state. The
         * property should not be set by users. When using TypeScript, this property
         * should be marked as `private` or `protected`, and it is also a common
         * practice to use a leading `_` in the name. The property is not added to
         * `observedAttributes`.
         */
        readonly state?: boolean;
        /**
         * Indicates how and whether the property becomes an observed attribute.
         * If the value is `false`, the property is not added to `observedAttributes`.
         * If true or absent, the lowercased property name is observed (e.g. `fooBar`
         * becomes `foobar`). If a string, the string value is observed (e.g
         * `attribute: 'foo-bar'`).
         */
        readonly attribute?: boolean | string;
        /**
         * Indicates the type of the property. This is used only as a hint for the
         * `converter` to determine how to convert the attribute
         * to/from a property.
         */
        readonly type?: TypeHint;
        /**
         * Indicates how to convert the attribute to/from a property. If this value
         * is a function, it is used to convert the attribute value a the property
         * value. If it's an object, it can have keys for `fromAttribute` and
         * `toAttribute`. If no `toAttribute` function is provided and
         * `reflect` is set to `true`, the property value is set directly to the
         * attribute. A default `converter` is used if none is provided; it supports
         * `Boolean`, `String`, `Number`, `Object`, and `Array`. Note,
         * when a property changes and the converter is used to update the attribute,
         * the property is never updated again as a result of the attribute changing,
         * and vice versa.
         */
        readonly converter?: AttributeConverter<Type, TypeHint>;
        /**
         * Indicates if the property should reflect to an attribute.
         * If `true`, when the property is set, the attribute is set using the
         * attribute name determined according to the rules for the `attribute`
         * property option and the value of the property converted using the rules
         * from the `converter` property option.
         */
        readonly reflect?: boolean;
        /**
         * A function that indicates if a property should be considered changed when
         * it is set. The function should take the `newValue` and `oldValue` and
         * return `true` if an update should be requested.
         */
        hasChanged?(value: Type, oldValue: Type): boolean;
        /**
         * Indicates whether an accessor will be created for this property. By
         * default, an accessor will be generated for this property that requests an
         * update when set. If this flag is `true`, no accessor will be created, and
         * it will be the user's responsibility to call
         * `this.requestUpdate(propertyName, oldValue)` to request an update when
         * the property changes.
         */
        readonly noAccessor?: boolean;
        /**
         * When `true`, uses the initial value of the property as the default value,
         * which changes how attributes are handled:
         *  - The initial value does *not* reflect, even if the `reflect` option is `true`.
         *    Subsequent changes to the property will reflect, even if they are equal to the
         *     default value.
         *  - When the attribute is removed, the property is set to the default value
         *  - The initial value will not trigger an old value in the `changedProperties` map
         *    argument to update lifecycle methods.
         *
         * When set, properties must be initialized, either with a field initializer, or an
         * assignment in the constructor. Not initializing the property may lead to
         * improper handling of subsequent property assignments.
         *
         * While this behavior is opt-in, most properties that reflect to attributes should
         * use `useDefault: true` so that their initial values do not reflect.
         */
        useDefault?: boolean;
    }
    /**
     * Map of properties to PropertyDeclaration options. For each property an
     * accessor is made, and the property is processed according to the
     * PropertyDeclaration options.
     */
    export interface PropertyDeclarations {
        readonly [key: string]: PropertyDeclaration;
    }
    type PropertyDeclarationMap = Map<PropertyKey, PropertyDeclaration>;
    /**
     * A Map of property keys to values.
     *
     * Takes an optional type parameter T, which when specified as a non-any,
     * non-unknown type, will make the Map more strongly-typed, associating the map
     * keys with their corresponding value type on T.
     *
     * Use `PropertyValues<this>` when overriding ReactiveElement.update() and
     * other lifecycle methods in order to get stronger type-checking on keys
     * and values.
     */
    export type PropertyValues<T = any> = T extends object ? PropertyValueMap<T> : Map<PropertyKey, unknown>;
    /**
     * Do not use, instead prefer {@linkcode PropertyValues}.
     */
    export interface PropertyValueMap<T> extends Map<PropertyKey, unknown> {
        get<K extends keyof T>(k: K): T[K] | undefined;
        set<K extends keyof T>(key: K, value: T[K]): this;
        has<K extends keyof T>(k: K): boolean;
        delete<K extends keyof T>(k: K): boolean;
    }
    export const defaultConverter: ComplexAttributeConverter;
    export interface HasChanged {
        (value: unknown, old: unknown): boolean;
    }
    /**
     * Change function that returns true if `value` is different from `oldValue`.
     * This method is used as the default for a property's `hasChanged` function.
     */
    export const notEqual: HasChanged;
    /**
     * A string representing one of the supported dev mode warning categories.
     */
    export type WarningKind = 'change-in-update' | 'migration' | 'async-perform-update';
    export type Initializer = (element: ReactiveElement) => void;
    global {
        interface SymbolConstructor {
            readonly metadata: unique symbol;
        }
    }
    global {
        var litPropertyMetadata: WeakMap<object, Map<PropertyKey, PropertyDeclaration>>;
    }
    /**
     * Base element class which manages element properties and attributes. When
     * properties change, the `update` method is asynchronously called. This method
     * should be supplied by subclasses to render updates as desired.
     * @noInheritDoc
     */
    export abstract class ReactiveElement extends HTMLElement implements ReactiveControllerHost {
        /**
         * Read or set all the enabled warning categories for this class.
         *
         * This property is only used in development builds.
         *
         * @nocollapse
         * @category dev-mode
         */
        static enabledWarnings?: WarningKind[];
        /**
         * Enable the given warning category for this class.
         *
         * This method only exists in development builds, so it should be accessed
         * with a guard like:
         *
         * ```ts
         * // Enable for all ReactiveElement subclasses
         * ReactiveElement.enableWarning?.('migration');
         *
         * // Enable for only MyElement and subclasses
         * MyElement.enableWarning?.('migration');
         * ```
         *
         * @nocollapse
         * @category dev-mode
         */
        static enableWarning?: (warningKind: WarningKind) => void;
        /**
         * Disable the given warning category for this class.
         *
         * This method only exists in development builds, so it should be accessed
         * with a guard like:
         *
         * ```ts
         * // Disable for all ReactiveElement subclasses
         * ReactiveElement.disableWarning?.('migration');
         *
         * // Disable for only MyElement and subclasses
         * MyElement.disableWarning?.('migration');
         * ```
         *
         * @nocollapse
         * @category dev-mode
         */
        static disableWarning?: (warningKind: WarningKind) => void;
        /**
         * Adds an initializer function to the class that is called during instance
         * construction.
         *
         * This is useful for code that runs against a `ReactiveElement`
         * subclass, such as a decorator, that needs to do work for each
         * instance, such as setting up a `ReactiveController`.
         *
         * ```ts
         * const myDecorator = (target: typeof ReactiveElement, key: string) => {
         *   target.addInitializer((instance: ReactiveElement) => {
         *     // This is run during construction of the element
         *     new MyController(instance);
         *   });
         * }
         * ```
         *
         * Decorating a field will then cause each instance to run an initializer
         * that adds a controller:
         *
         * ```ts
         * class MyElement extends LitElement {
         *   @myDecorator foo;
         * }
         * ```
         *
         * Initializers are stored per-constructor. Adding an initializer to a
         * subclass does not add it to a superclass. Since initializers are run in
         * constructors, initializers will run in order of the class hierarchy,
         * starting with superclasses and progressing to the instance's class.
         *
         * @nocollapse
         */
        static addInitializer(initializer: Initializer): void;
        static _initializers?: Initializer[];
        /**
         * Maps attribute names to properties; for example `foobar` attribute to
         * `fooBar` property. Created lazily on user subclasses when finalizing the
         * class.
         * @nocollapse
         */
        private static __attributeToPropertyMap;
        /**
         * Marks class as having been finalized, which includes creating properties
         * from `static properties`, but does *not* include all properties created
         * from decorators.
         * @nocollapse
         */
        protected static finalized: true | undefined;
        /**
         * Memoized list of all element properties, including any superclass
         * properties. Created lazily on user subclasses when finalizing the class.
         *
         * @nocollapse
         * @category properties
         */
        static elementProperties: PropertyDeclarationMap;
        /**
         * User-supplied object that maps property names to `PropertyDeclaration`
         * objects containing options for configuring reactive properties. When
         * a reactive property is set the element will update and render.
         *
         * By default properties are public fields, and as such, they should be
         * considered as primarily settable by element users, either via attribute or
         * the property itself.
         *
         * Generally, properties that are changed by the element should be private or
         * protected fields and should use the `state: true` option. Properties
         * marked as `state` do not reflect from the corresponding attribute
         *
         * However, sometimes element code does need to set a public property. This
         * should typically only be done in response to user interaction, and an event
         * should be fired informing the user; for example, a checkbox sets its
         * `checked` property when clicked and fires a `changed` event. Mutating
         * public properties should typically not be done for non-primitive (object or
         * array) properties. In other cases when an element needs to manage state, a
         * private property set with the `state: true` option should be used. When
         * needed, state properties can be initialized via public properties to
         * facilitate complex interactions.
         * @nocollapse
         * @category properties
         */
        static properties: PropertyDeclarations;
        /**
         * Memoized list of all element styles.
         * Created lazily on user subclasses when finalizing the class.
         * @nocollapse
         * @category styles
         */
        static elementStyles: Array<CSSResultOrNative>;
        /**
         * Array of styles to apply to the element. The styles should be defined
         * using the {@linkcode css} tag function, via constructible stylesheets, or
         * imported from native CSS module scripts.
         *
         * Note on Content Security Policy:
         *
         * Element styles are implemented with `<style>` tags when the browser doesn't
         * support adopted StyleSheets. To use such `<style>` tags with the style-src
         * CSP directive, the style-src value must either include 'unsafe-inline' or
         * `nonce-<base64-value>` with `<base64-value>` replaced be a server-generated
         * nonce.
         *
         * To provide a nonce to use on generated `<style>` elements, set
         * `window.litNonce` to a server-generated nonce in your page's HTML, before
         * loading application code:
         *
         * ```html
         * <script>
         *   // Generated and unique per request:
         *   window.litNonce = 'a1b2c3d4';
         * </script>
         * ```
         * @nocollapse
         * @category styles
         */
        static styles?: CSSResultGroup;
        /**
         * Returns a list of attributes corresponding to the registered properties.
         * @nocollapse
         * @category attributes
         */
        static get observedAttributes(): string[];
        private __instanceProperties?;
        /**
         * Creates a property accessor on the element prototype if one does not exist
         * and stores a {@linkcode PropertyDeclaration} for the property with the
         * given options. The property setter calls the property's `hasChanged`
         * property option or uses a strict identity check to determine whether or not
         * to request an update.
         *
         * This method may be overridden to customize properties; however,
         * when doing so, it's important to call `super.createProperty` to ensure
         * the property is setup correctly. This method calls
         * `getPropertyDescriptor` internally to get a descriptor to install.
         * To customize what properties do when they are get or set, override
         * `getPropertyDescriptor`. To customize the options for a property,
         * implement `createProperty` like this:
         *
         * ```ts
         * static createProperty(name, options) {
         *   options = Object.assign(options, {myOption: true});
         *   super.createProperty(name, options);
         * }
         * ```
         *
         * @nocollapse
         * @category properties
         */
        static createProperty(name: PropertyKey, options?: PropertyDeclaration): void;
        /**
         * Returns a property descriptor to be defined on the given named property.
         * If no descriptor is returned, the property will not become an accessor.
         * For example,
         *
         * ```ts
         * class MyElement extends LitElement {
         *   static getPropertyDescriptor(name, key, options) {
         *     const defaultDescriptor =
         *         super.getPropertyDescriptor(name, key, options);
         *     const setter = defaultDescriptor.set;
         *     return {
         *       get: defaultDescriptor.get,
         *       set(value) {
         *         setter.call(this, value);
         *         // custom action.
         *       },
         *       configurable: true,
         *       enumerable: true
         *     }
         *   }
         * }
         * ```
         *
         * @nocollapse
         * @category properties
         */
        protected static getPropertyDescriptor(name: PropertyKey, key: string | symbol, options: PropertyDeclaration): PropertyDescriptor | undefined;
        /**
         * Returns the property options associated with the given property.
         * These options are defined with a `PropertyDeclaration` via the `properties`
         * object or the `@property` decorator and are registered in
         * `createProperty(...)`.
         *
         * Note, this method should be considered "final" and not overridden. To
         * customize the options for a given property, override
         * {@linkcode createProperty}.
         *
         * @nocollapse
         * @final
         * @category properties
         */
        static getPropertyOptions(name: PropertyKey): PropertyDeclaration<unknown, unknown>;
        static [Symbol.metadata]: object & Record<PropertyKey, unknown>;
        /**
         * Initializes static own properties of the class used in bookkeeping
         * for element properties, initializers, etc.
         *
         * Can be called multiple times by code that needs to ensure these
         * properties exist before using them.
         *
         * This method ensures the superclass is finalized so that inherited
         * property metadata can be copied down.
         * @nocollapse
         */
        private static __prepare;
        /**
         * Finishes setting up the class so that it's ready to be registered
         * as a custom element and instantiated.
         *
         * This method is called by the ReactiveElement.observedAttributes getter.
         * If you override the observedAttributes getter, you must either call
         * super.observedAttributes to trigger finalization, or call finalize()
         * yourself.
         *
         * @nocollapse
         */
        protected static finalize(): void;
        /**
         * Options used when calling `attachShadow`. Set this property to customize
         * the options for the shadowRoot; for example, to create a closed
         * shadowRoot: `{mode: 'closed'}`.
         *
         * Note, these options are used in `createRenderRoot`. If this method
         * is customized, options should be respected if possible.
         * @nocollapse
         * @category rendering
         */
        static shadowRootOptions: ShadowRootInit;
        /**
         * Takes the styles the user supplied via the `static styles` property and
         * returns the array of styles to apply to the element.
         * Override this method to integrate into a style management system.
         *
         * Styles are deduplicated preserving the _last_ instance in the list. This
         * is a performance optimization to avoid duplicated styles that can occur
         * especially when composing via subclassing. The last item is kept to try
         * to preserve the cascade order with the assumption that it's most important
         * that last added styles override previous styles.
         *
         * @nocollapse
         * @category styles
         */
        protected static finalizeStyles(styles?: CSSResultGroup): Array<CSSResultOrNative>;
        /**
         * Node or ShadowRoot into which element DOM should be rendered. Defaults
         * to an open shadowRoot.
         * @category rendering
         */
        readonly renderRoot: HTMLElement | DocumentFragment;
        /**
         * Returns the property name for the given attribute `name`.
         * @nocollapse
         */
        private static __attributeNameForProperty;
        private __updatePromise;
        /**
         * True if there is a pending update as a result of calling `requestUpdate()`.
         * Should only be read.
         * @category updates
         */
        isUpdatePending: boolean;
        /**
         * Is set to `true` after the first update. The element code cannot assume
         * that `renderRoot` exists before the element `hasUpdated`.
         * @category updates
         */
        hasUpdated: boolean;
        /**
         * Records property default values when the
         * `useDefault` option is used.
         */
        private __defaultValues?;
        /**
         * Properties that should be reflected when updated.
         */
        private __reflectingProperties?;
        /**
         * Name of currently reflecting property
         */
        private __reflectingProperty;
        /**
         * Set of controllers.
         */
        private __controllers?;
        constructor();
        /**
         * Internal only override point for customizing work done when elements
         * are constructed.
         */
        private __initialize;
        /**
         * Registers a `ReactiveController` to participate in the element's reactive
         * update cycle. The element automatically calls into any registered
         * controllers during its lifecycle callbacks.
         *
         * If the element is connected when `addController()` is called, the
         * controller's `hostConnected()` callback will be immediately called.
         * @category controllers
         */
        addController(controller: ReactiveController): void;
        /**
         * Removes a `ReactiveController` from the element.
         * @category controllers
         */
        removeController(controller: ReactiveController): void;
        /**
         * Fixes any properties set on the instance before upgrade time.
         * Otherwise these would shadow the accessor and break these properties.
         * The properties are stored in a Map which is played back after the
         * constructor runs.
         */
        private __saveInstanceProperties;
        /**
         * Returns the node into which the element should render and by default
         * creates and returns an open shadowRoot. Implement to customize where the
         * element's DOM is rendered. For example, to render into the element's
         * childNodes, return `this`.
         *
         * @return Returns a node into which to render.
         * @category rendering
         */
        protected createRenderRoot(): HTMLElement | DocumentFragment;
        /**
         * On first connection, creates the element's renderRoot, sets up
         * element styling, and enables updating.
         * @category lifecycle
         */
        connectedCallback(): void;
        /**
         * Note, this method should be considered final and not overridden. It is
         * overridden on the element instance with a function that triggers the first
         * update.
         * @category updates
         */
        protected enableUpdating(_requestedUpdate: boolean): void;
        /**
         * Allows for `super.disconnectedCallback()` in extensions while
         * reserving the possibility of making non-breaking feature additions
         * when disconnecting at some point in the future.
         * @category lifecycle
         */
        disconnectedCallback(): void;
        /**
         * Synchronizes property values when attributes change.
         *
         * Specifically, when an attribute is set, the corresponding property is set.
         * You should rarely need to implement this callback. If this method is
         * overridden, `super.attributeChangedCallback(name, _old, value)` must be
         * called.
         *
         * See [responding to attribute changes](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements#responding_to_attribute_changes)
         * on MDN for more information about the `attributeChangedCallback`.
         * @category attributes
         */
        attributeChangedCallback(name: string, _old: string | null, value: string | null): void;
        private __propertyToAttribute;
        /**
         * Requests an update which is processed asynchronously. This should be called
         * when an element should update based on some state not triggered by setting
         * a reactive property. In this case, pass no arguments. It should also be
         * called when manually implementing a property setter. In this case, pass the
         * property `name` and `oldValue` to ensure that any configured property
         * options are honored.
         *
         * @param name name of requesting property
         * @param oldValue old value of requesting property
         * @param options property options to use instead of the previously
         *     configured options
         * @category updates
         */
        requestUpdate(name?: PropertyKey, oldValue?: unknown, options?: PropertyDeclaration): void;
        /**
         * Sets up the element to asynchronously update.
         */
        private __enqueueUpdate;
        /**
         * Schedules an element update. You can override this method to change the
         * timing of updates by returning a Promise. The update will await the
         * returned Promise, and you should resolve the Promise to allow the update
         * to proceed. If this method is overridden, `super.scheduleUpdate()`
         * must be called.
         *
         * For instance, to schedule updates to occur just before the next frame:
         *
         * ```ts
         * override protected async scheduleUpdate(): Promise<unknown> {
         *   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
         *   super.scheduleUpdate();
         * }
         * ```
         * @category updates
         */
        protected scheduleUpdate(): void | Promise<unknown>;
        /**
         * Performs an element update. Note, if an exception is thrown during the
         * update, `firstUpdated` and `updated` will not be called.
         *
         * Call `performUpdate()` to immediately process a pending update. This should
         * generally not be needed, but it can be done in rare cases when you need to
         * update synchronously.
         *
         * @category updates
         */
        protected performUpdate(): void;
        /**
         * Invoked before `update()` to compute values needed during the update.
         *
         * Implement `willUpdate` to compute property values that depend on other
         * properties and are used in the rest of the update process.
         *
         * ```ts
         * willUpdate(changedProperties) {
         *   // only need to check changed properties for an expensive computation.
         *   if (changedProperties.has('firstName') || changedProperties.has('lastName')) {
         *     this.sha = computeSHA(`${this.firstName} ${this.lastName}`);
         *   }
         * }
         *
         * render() {
         *   return html`SHA: ${this.sha}`;
         * }
         * ```
         *
         * @category updates
         */
        protected willUpdate(_changedProperties: PropertyValues): void;
        private __markUpdated;
        /**
         * Returns a Promise that resolves when the element has completed updating.
         * The Promise value is a boolean that is `true` if the element completed the
         * update without triggering another update. The Promise result is `false` if
         * a property was set inside `updated()`. If the Promise is rejected, an
         * exception was thrown during the update.
         *
         * To await additional asynchronous work, override the `getUpdateComplete`
         * method. For example, it is sometimes useful to await a rendered element
         * before fulfilling this Promise. To do this, first await
         * `super.getUpdateComplete()`, then any subsequent state.
         *
         * @return A promise of a boolean that resolves to true if the update completed
         *     without triggering another update.
         * @category updates
         */
        get updateComplete(): Promise<boolean>;
        /**
         * Override point for the `updateComplete` promise.
         *
         * It is not safe to override the `updateComplete` getter directly due to a
         * limitation in TypeScript which means it is not possible to call a
         * superclass getter (e.g. `super.updateComplete.then(...)`) when the target
         * language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
         * This method should be overridden instead. For example:
         *
         * ```ts
         * class MyElement extends LitElement {
         *   override async getUpdateComplete() {
         *     const result = await super.getUpdateComplete();
         *     await this._myChild.updateComplete;
         *     return result;
         *   }
         * }
         * ```
         *
         * @return A promise of a boolean that resolves to true if the update completed
         *     without triggering another update.
         * @category updates
         */
        protected getUpdateComplete(): Promise<boolean>;
        /**
         * Controls whether or not `update()` should be called when the element requests
         * an update. By default, this method always returns `true`, but this can be
         * customized to control when to update.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected shouldUpdate(_changedProperties: PropertyValues): boolean;
        /**
         * Updates the element. This method reflects property values to attributes.
         * It can be overridden to render and keep updated element DOM.
         * Setting properties inside this method will *not* trigger
         * another update.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected update(_changedProperties: PropertyValues): void;
        /**
         * Invoked whenever the element is updated. Implement to perform
         * post-updating tasks via DOM APIs, for example, focusing an element.
         *
         * Setting properties inside this method will trigger the element to update
         * again after this update cycle completes.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected updated(_changedProperties: PropertyValues): void;
        /**
         * Invoked when the element is first updated. Implement to perform one time
         * work on the element after update.
         *
         * ```ts
         * firstUpdated() {
         *   this.renderRoot.getElementById('my-text-area').focus();
         * }
         * ```
         *
         * Setting properties inside this method will trigger the element to update
         * again after this update cycle completes.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected firstUpdated(_changedProperties: PropertyValues): void;
    }
}
declare module "_102027_/l2/ref" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ElementPart } from '_102027_/l2/litHtml';
    import { AsyncDirective } from '_102027_/l2/asyncDirective';
    /**
     * Creates a new Ref object, which is container for a reference to an element.
     */
    export const createRef: <T = Element>() => Ref<T>;
    /**
     * An object that holds a ref value.
     */
    class Ref<T = Element> {
        /**
         * The current Element value of the ref, or else `undefined` if the ref is no
         * longer rendered.
         */
        readonly value?: T;
    }
    export type { Ref };
    export type RefOrCallback<T = Element> = Ref<T> | ((el: T | undefined) => void);
    class RefDirective extends AsyncDirective {
        private _element?;
        private _ref?;
        private _context?;
        render(_ref?: RefOrCallback): symbol;
        update(part: ElementPart, [ref]: Parameters<this['render']>): symbol;
        private _updateRefValue;
        private get _lastElementForRef();
        disconnected(): void;
        reconnected(): void;
    }
    /**
     * Sets the value of a Ref object or calls a ref callback with the element it's
     * bound to.
     *
     * A Ref object acts as a container for a reference to an element. A ref
     * callback is a function that takes an element as its only argument.
     *
     * The ref directive sets the value of the Ref object or calls the ref callback
     * during rendering, if the referenced element changed.
     *
     * Note: If a ref callback is rendered to a different element position or is
     * removed in a subsequent render, it will first be called with `undefined`,
     * followed by another call with the new element it was rendered to (if any).
     *
     * ```js
     * // Using Ref object
     * const inputRef = createRef();
     * render(html`<input ${ref(inputRef)}>`, container);
     * inputRef.value.focus();
     *
     * // Using callback
     * const callback = (inputElement) => inputElement.focus();
     * render(html`<input ${ref(callback)}>`, container);
     * ```
     */
    export const ref: (_ref?: RefOrCallback<Element> | undefined) => import('/_102027_/l2/directive.js').DirectiveResult<typeof RefDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { RefDirective };
}
declare module "_102027_/l2/repeat" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ChildPart, noChange } from '_102027_/l2/litHtml';
    import { Directive, PartInfo } from '_102027_/l2/directive';
    export type KeyFn<T> = (item: T, index: number) => unknown;
    export type ItemTemplate<T> = (item: T, index: number) => unknown;
    class RepeatDirective extends Directive {
        private _itemKeys?;
        constructor(partInfo: PartInfo);
        private _getValuesAndKeys;
        render<T>(items: Iterable<T>, template: ItemTemplate<T>): Array<unknown>;
        render<T>(items: Iterable<T>, keyFn: KeyFn<T> | ItemTemplate<T>, template: ItemTemplate<T>): Array<unknown>;
        update<T>(containerPart: ChildPart, [items, keyFnOrTemplate, template]: [
            Iterable<T>,
            KeyFn<T> | ItemTemplate<T>,
            ItemTemplate<T>
        ]): unknown[] | typeof noChange;
    }
    export interface RepeatDirectiveFn {
        <T>(items: Iterable<T>, keyFnOrTemplate: KeyFn<T> | ItemTemplate<T>, template?: ItemTemplate<T>): unknown;
        <T>(items: Iterable<T>, template: ItemTemplate<T>): unknown;
        <T>(items: Iterable<T>, keyFn: KeyFn<T> | ItemTemplate<T>, template: ItemTemplate<T>): unknown;
    }
    /**
     * A directive that repeats a series of values (usually `TemplateResults`)
     * generated from an iterable, and updates those items efficiently when the
     * iterable changes based on user-provided `keys` associated with each item.
     *
     * Note that if a `keyFn` is provided, strict key-to-DOM mapping is maintained,
     * meaning previous DOM for a given key is moved into the new position if
     * needed, and DOM will never be reused with values for different keys (new DOM
     * will always be created for new keys). This is generally the most efficient
     * way to use `repeat` since it performs minimum unnecessary work for insertions
     * and removals.
     *
     * The `keyFn` takes two parameters, the item and its index, and returns a unique key value.
     *
     * ```js
     * html`
     *   <ol>
     *     ${repeat(this.items, (item) => item.id, (item, index) => {
     *       return html`<li>${index}: ${item.name}</li>`;
     *     })}
     *   </ol>
     * `
     * ```
     *
     * **Important**: If providing a `keyFn`, keys *must* be unique for all items in a
     * given call to `repeat`. The behavior when two or more items have the same key
     * is undefined.
     *
     * If no `keyFn` is provided, this directive will perform similar to mapping
     * items to values, and DOM will be reused against potentially different items.
     */
    export const repeat: RepeatDirectiveFn;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { RepeatDirective };
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102027_/l2/state" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    export interface StateDeclaration<Type = unknown> {
        /**
         * A function that indicates if a property should be considered changed when
         * it is set. The function should take the `newValue` and `oldValue` and
         * return `true` if an update should be requested.
         */
        hasChanged?(value: Type, oldValue: Type): boolean;
    }
    /**
     * @deprecated use StateDeclaration
     */
    export type InternalPropertyDeclaration<Type = unknown> = StateDeclaration<Type>;
    /**
     * Declares a private or protected reactive property that still triggers
     * updates to the element when it changes. It does not reflect from the
     * corresponding attribute.
     *
     * Properties declared this way must not be used from HTML or HTML templating
     * systems, they're solely for properties internal to the element. These
     * properties may be renamed by optimization tools like closure compiler.
     * @category Decorator
     */
    export function state(options?: StateDeclaration): import("/_102027_/l2/property.js").PropertyDecorator;
}
declare module "../l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102027_/l2/stateLitElement" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    import { PropertyValueMap } from 'lit';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102027_/l2/static" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { html as coreHtml, svg as coreSvg, mathml as coreMathml, TemplateResult } from '_102027_/l2/litHtml';
    export interface StaticValue {
        /** The value to interpolate as-is into the template. */
        _$litStatic$: string;
        /**
         * A value that can't be decoded from ordinary JSON, make it harder for
         * an attacker-controlled data that goes through JSON.parse to produce a valid
         * StaticValue.
         */
        r: typeof brand;
    }
    /**
     * Prevents JSON injection attacks.
     *
     * The goals of this brand:
     *   1) fast to check
     *   2) code is small on the wire
     *   3) multiple versions of Lit in a single page will all produce mutually
     *      interoperable StaticValues
     *   4) normal JSON.parse (without an unusual reviver) can not produce a
     *      StaticValue
     *
     * Symbols satisfy (1), (2), and (4). We use Symbol.for to satisfy (3), but
     * we don't care about the key, so we break ties via (2) and use the empty
     * string.
     */
    const brand: unique symbol;
    /**
     * Wraps a string so that it behaves like part of the static template
     * strings instead of a dynamic value.
     *
     * Users must take care to ensure that adding the static string to the template
     * results in well-formed HTML, or else templates may break unexpectedly.
     *
     * Note that this function is unsafe to use on untrusted content, as it will be
     * directly parsed into HTML. Do not pass user input to this function
     * without sanitizing it.
     *
     * Static values can be changed, but they will cause a complete re-render
     * since they effectively create a new template.
     */
    export const unsafeStatic: (value: string) => StaticValue;
    /**
     * Tags a string literal so that it behaves like part of the static template
     * strings instead of a dynamic value.
     *
     * The only values that may be used in template expressions are other tagged
     * `literal` results or `unsafeStatic` values (note that untrusted content
     * should never be passed to `unsafeStatic`).
     *
     * Users must take care to ensure that adding the static string to the template
     * results in well-formed HTML, or else templates may break unexpectedly.
     *
     * Static values can be changed, but they will cause a complete re-render since
     * they effectively create a new template.
     */
    export const literal: (strings: TemplateStringsArray, ...values: unknown[]) => StaticValue;
    /**
     * Wraps a lit-html template tag (`html` or `svg`) to add static value support.
     */
    export const withStatic: (coreTag: typeof coreHtml | typeof coreSvg | typeof coreMathml) => (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult;
    /**
     * Interprets a template literal as an HTML template that can efficiently
     * render to and update a container.
     *
     * Includes static value support from `lit-html/static.js`.
     */
    export const html: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult;
    /**
     * Interprets a template literal as an SVG template that can efficiently
     * render to and update a container.
     *
     * Includes static value support from `lit-html/static.js`.
     */
    export const svg: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult;
    /**
     * Interprets a template literal as MathML fragment that can efficiently render
     * to and update a container.
     *
     * Includes static value support from `lit-html/static.js`.
     */
    export const mathml: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult;
    export {};
}
declare module "_102027_/l2/styleMap" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart, noChange } from '_102027_/l2/litHtml';
    import { Directive, DirectiveParameters, PartInfo } from '_102027_/l2/directive';
    /**
     * A key-value set of CSS properties and values.
     *
     * The key should be either a valid CSS property name string, like
     * `'background-color'`, or a valid JavaScript camel case property name
     * for CSSStyleDeclaration like `backgroundColor`.
     */
    export interface StyleInfo {
        [name: string]: string | number | undefined | null;
    }
    class StyleMapDirective extends Directive {
        private _previousStyleProperties?;
        constructor(partInfo: PartInfo);
        render(styleInfo: Readonly<StyleInfo>): string;
        update(part: AttributePart, [styleInfo]: DirectiveParameters<this>): string | typeof noChange;
    }
    /**
     * A directive that applies CSS properties to an element.
     *
     * `styleMap` can only be used in the `style` attribute and must be the only
     * expression in the attribute. It takes the property names in the
     * {@link StyleInfo styleInfo} object and adds the properties to the inline
     * style of the element.
     *
     * Property names with dashes (`-`) are assumed to be valid CSS
     * property names and set on the element's style object using `setProperty()`.
     * Names without dashes are assumed to be camelCased JavaScript property names
     * and set on the element's style object using property assignment, allowing the
     * style object to translate JavaScript-style names to CSS property names.
     *
     * For example `styleMap({backgroundColor: 'red', 'border-top': '5px', '--size':
     * '0'})` sets the `background-color`, `border-top` and `--size` properties.
     *
     * @param styleInfo
     * @see {@link https://lit.dev/docs/templates/directives/#stylemap styleMap code samples on Lit.dev}
     */
    export const styleMap: (styleInfo: Readonly<StyleInfo>) => import("/_102027_/l2/directive.js").DirectiveResult<typeof StyleMapDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { StyleMapDirective };
}
declare module "_102027_/l2/templateContent" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { noChange } from '_102027_/l2/litHtml';
    import { Directive, PartInfo } from '_102027_/l2/directive';
    class TemplateContentDirective extends Directive {
        private _previousTemplate?;
        constructor(partInfo: PartInfo);
        render(template: HTMLTemplateElement): DocumentFragment | typeof noChange;
    }
    /**
     * Renders the content of a template element as HTML.
     *
     * Note, the template should be developer controlled and not user controlled.
     * Rendering a user-controlled template with this directive
     * could lead to cross-site-scripting vulnerabilities.
     */
    export const templateContent: (template: HTMLTemplateElement) => import("/_102027_/l2/directive.js").DirectiveResult<typeof TemplateContentDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { TemplateContentDirective };
}
declare module "_102027_/l2/unsafeHtml" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { nothing, TemplateResult, noChange } from '_102027_/l2/litHtml';
    import { Directive, PartInfo } from '_102027_/l2/directive';
    export class UnsafeHTMLDirective extends Directive {
        static directiveName: string;
        static resultType: number;
        private _value;
        private _templateResult?;
        constructor(partInfo: PartInfo);
        render(value: string | typeof nothing | typeof noChange | undefined | null): typeof noChange | typeof nothing | TemplateResult | null | undefined;
    }
    /**
     * Renders the result as HTML, rather than text.
     *
     * The values `undefined`, `null`, and `nothing`, will all result in no content
     * (empty string) being rendered.
     *
     * Note, this is unsafe to use with any user-provided input that hasn't been
     * sanitized or escaped, as it may lead to cross-site-scripting
     * vulnerabilities.
     */
    export const unsafeHTML: (value: string | typeof noChange | typeof nothing | null | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof UnsafeHTMLDirective>;
}
declare module "_102027_/l2/unsafeMathml" {
    /**
     * @license
     * Copyright 2024 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { UnsafeHTMLDirective } from '_102027_/l2/unsafeHtml';
    class UnsafeMathMLDirective extends UnsafeHTMLDirective {
        static directiveName: string;
        static resultType: number;
    }
    /**
     * Renders the result as MathML, rather than text.
     *
     * The values `undefined`, `null`, and `nothing`, will all result in no content
     * (empty string) being rendered.
     *
     * Note, this is unsafe to use with any user-provided input that hasn't been
     * sanitized or escaped, as it may lead to cross-site-scripting
     * vulnerabilities.
     */
    export const unsafeMathML: (value: string | typeof import("/_102027_/l2/litHtml.js").noChange | typeof import("/_102027_/l2/litHtml.js").nothing | null | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof UnsafeMathMLDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { UnsafeMathMLDirective as UnsafeMathDirective };
}
declare module "_102027_/l2/unsafeSvg" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { UnsafeHTMLDirective } from '_102027_/l2/unsafeHtml';
    class UnsafeSVGDirective extends UnsafeHTMLDirective {
        static directiveName: string;
        static resultType: number;
    }
    /**
     * Renders the result as SVG, rather than text.
     *
     * The values `undefined`, `null`, and `nothing`, will all result in no content
     * (empty string) being rendered.
     *
     * Note, this is unsafe to use with any user-provided input that hasn't been
     * sanitized or escaped, as it may lead to cross-site-scripting
     * vulnerabilities.
     */
    export const unsafeSVG: (value: string | typeof import('/_102027_/l2/litHtml.js').noChange | typeof import("/_102027_/l2/litHtml.js").nothing | null | undefined) => import("/_102027_/l2/directive.js").DirectiveResult<typeof UnsafeSVGDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { UnsafeSVGDirective };
}
declare module "_102027_/l2/until" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Part } from '_102027_/l2/litHtml';
    import { AsyncDirective } from '_102027_/l2/asyncDirective';
    export class UntilDirective extends AsyncDirective {
        private __lastRenderedIndex;
        private __values;
        private __weakThis;
        private __pauser;
        render(...args: Array<unknown>): unknown;
        update(_part: Part, args: Array<unknown>): unknown;
        disconnected(): void;
        reconnected(): void;
    }
    /**
     * Renders one of a series of values, including Promises, to a Part.
     *
     * Values are rendered in priority order, with the first argument having the
     * highest priority and the last argument having the lowest priority. If a
     * value is a Promise, low-priority values will be rendered until it resolves.
     *
     * The priority of values can be used to create placeholder content for async
     * data. For example, a Promise with pending content can be the first,
     * highest-priority, argument, and a non_promise loading indicator template can
     * be used as the second, lower-priority, argument. The loading indicator will
     * render immediately, and the primary content will render when the Promise
     * resolves.
     *
     * Example:
     *
     * ```js
     * const content = fetch('./content.txt').then(r => r.text());
     * html`${until(content, html`<span>Loading...</span>`)}`
     * ```
     */
    export const until: (...values: unknown[]) => import('/_102027_/l2/directive.js').DirectiveResult<typeof UntilDirective>;
}
declare module "_102027_/l2/updateProduct.defs" {
    export const contractSpec: {
        interfaces: {
            PetshopProduct: {
                fields: ({
                    name: string;
                    type: string;
                    optional?: undefined;
                } | {
                    name: string;
                    type: string;
                    optional: boolean;
                })[];
            };
            PetshopGetProductParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopCategory: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopListCategoriesParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
        };
        enums: {
            PetshopAction: {
                values: {
                    key: string;
                    value: string;
                }[];
            };
        };
        types: {
            PetshopProductId: {
                definition: string;
            };
        };
        constants: {
            PETSHOP_API_VERSION: {
                type: string;
                value: string;
            };
        };
    };
    export const sharedSpec: {
        className: string;
        interfacesPath: string;
        interfaces: {
            PetshopProduct: {
                fields: ({
                    name: string;
                    type: string;
                    optional?: undefined;
                } | {
                    name: string;
                    type: string;
                    optional: boolean;
                })[];
            };
            PetshopGetProductParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopCategory: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopListCategoriesParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
        };
        properties: {
            name: string;
            type: string;
            default: string;
            reflect: boolean;
        }[];
        states: ({
            name: string;
            type: string;
            default: any;
            reset: boolean;
            interfaceGroup?: undefined;
            field?: undefined;
        } | {
            name: string;
            type: string;
            default: boolean;
            reset?: undefined;
            interfaceGroup?: undefined;
            field?: undefined;
        } | {
            name: string;
            type: string;
            default: any[];
            reset?: undefined;
            interfaceGroup?: undefined;
            field?: undefined;
        } | {
            name: string;
            type: string;
            default: string;
            interfaceGroup: string;
            field: string;
            reset?: undefined;
        } | {
            name: string;
            type: string;
            default: number;
            interfaceGroup: string;
            field: string;
            reset?: undefined;
        } | {
            name: string;
            type: string;
            default: boolean;
            interfaceGroup: string;
            field: string;
            reset?: undefined;
        })[];
        actions: ({
            trigger: {
                state: string;
                value: string;
            };
            method: string;
            useMock: boolean;
            bff: {
                fn: string;
                params: string;
                result: string;
                onStart: {
                    state: string;
                    value: string;
                }[];
                onSuccess: {
                    state: string;
                    value: string;
                }[];
                onError: {
                    state: string;
                    value: string;
                }[];
            };
            onStart?: undefined;
        } | {
            trigger: {
                state: string;
                value: string;
            };
            method: string;
            bff: {
                fn: string;
                params: string;
                result: string;
                onStart: {
                    state: string;
                    value: string;
                }[];
                onSuccess: {
                    state: string;
                    value: string;
                }[];
                onError: {
                    state: string;
                    value: string;
                }[];
            };
            useMock?: undefined;
            onStart?: undefined;
        } | {
            trigger: {
                state: string;
                value: string;
            };
            method: string;
            bff: any;
            onStart: {
                state: string;
                value: string;
            }[];
            useMock?: undefined;
        })[];
        lifecycle: {
            connectedCallback: {
                dispatchAction: string[];
            };
        };
    };
    export const desktopLayoutSpec: {
        className: string;
        tagName: string;
        extends: string;
        styling: string;
        imports: {
            type: string;
            import: string;
            path: string;
        }[];
        render: {
            conditions: {
                if: string;
                return: string;
            }[];
            blocks: {
                loading: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        i18n?: undefined;
                    } | {
                        element: string;
                        class: string;
                        i18n: string;
                    })[];
                };
                error: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        bind: string;
                        i18n?: undefined;
                        event?: undefined;
                    } | {
                        element: string;
                        class: string;
                        i18n: string;
                        event: {
                            on: string;
                            type: string;
                            state: string;
                            value: string;
                        };
                        bind?: undefined;
                    })[];
                };
                default: {
                    element: string;
                    class: string;
                    event: {
                        on: string;
                        type: string;
                        state: string;
                        value: string;
                        prevent: boolean;
                    };
                    children: ({
                        element: string;
                        class: string;
                        children: {
                            element: string;
                            class: string;
                            children: {
                                element: string;
                                class: string;
                                i18n: string;
                                input: {
                                    type: string;
                                    class: string;
                                    bind: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        cast: string;
                                    };
                                };
                            }[];
                        }[];
                    } | {
                        element: string;
                        class: string;
                        children: {
                            element: string;
                            class: string;
                            i18n: string;
                            input: {
                                type: string;
                                class: string;
                                bind: string;
                                options: {
                                    source: string;
                                    value: string;
                                    label: string;
                                };
                                event: {
                                    on: string;
                                    type: string;
                                    state: string;
                                    cast: string;
                                };
                            };
                        }[];
                    } | {
                        element: string;
                        class: string;
                        children: ({
                            element: string;
                            class: string;
                            type: string;
                            i18n: string;
                            event: {
                                on: string;
                                type: string;
                                state: string;
                                value: string;
                            };
                            disabled?: undefined;
                        } | {
                            element: string;
                            class: string;
                            type: string;
                            i18n: string;
                            disabled: string;
                            event?: undefined;
                        })[];
                    })[];
                };
            };
        };
        i18n: {
            default: string;
            languages: string[];
            keys: string[];
        };
    };
    export const lessSpec: {
        tagName: string;
        layout: {
            type: string;
            columns: number;
            states: string[];
        };
        classes: {
            name: string;
            role: string;
            context: string;
        }[];
    };
    export const materializeIndex: mls.defs.MaterializeIndex;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "../l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102027_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102027_/l2/validateLit" {
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
    export function validateRender(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102027_/l2/wcTeste" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class WcTeste100000 extends CollabLitElement {
        name: string;
        render(): any;
    }
}
declare module "_102027_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102027_/l2/when" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    type Falsy = null | undefined | false | 0 | -0 | 0n | '';
    /**
     * When `condition` is true, returns the result of calling `trueCase()`, else
     * returns the result of calling `falseCase()` if `falseCase` is defined.
     *
     * This is a convenience wrapper around a ternary expression that makes it a
     * little nicer to write an inline conditional without an else.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${when(this.user, () => html`User: ${this.user.username}`, () => html`Sign In...`)}
     *   `;
     * }
     * ```
     */
    export function when<C extends Falsy, T, F = undefined>(condition: C, trueCase: (c: C) => T, falseCase?: (c: C) => F): F;
    export function when<C, T, F>(condition: C extends Falsy ? never : C, trueCase: (c: C) => T, falseCase?: (c: C) => F): T;
    export function when<C, T, F = undefined>(condition: C, trueCase: (c: Exclude<C, Falsy>) => T, falseCase?: (c: Extract<C, Falsy>) => F): C extends Falsy ? F : T;
    export {};
}
declare module "_102027_/l2/agents/skills/genTest" {
    export const skill = "\n    return only string 'genTest completed'\n";
}
declare module "_102027_/l2/agents/skills/jointendFields" {
    export const skill = "\n# Jointed Fields \u2014 UI Layout Skill\n\n**Style Name:** Jointed Fields\n**Also known as:** Conjoined Fields \u00B7 Fused Field Pair \u00B7 Borderless Split Input\n\n---\n\n## What Is It?\n\nJointed Fields is a form layout pattern that pairs two semantically related input fields in the same row by removing the margin between them and sharing a unified container border. Each field keeps its own inline label (positioned small, at the top-left inside the field) and its own validation logic, but visually the pair reads as a single cohesive unit. The result: a form with 18 fields feels like 9.\n\n---\n\n## Core Principles\n\n- **Pair by relationship** \u2014 only join fields with a natural sibling bond (e.g. First Name + Last Name, City + State, Check-in + Check-out).\n- **Label inside the field** \u2014 each field uses a small, muted label anchored at the top-left, above the typed value.\n- **No gap between joined fields** \u2014 the pair shares one outer border; only a thin internal vertical line separates them.\n- **Proportional widths** \u2014 do not force 50/50. Size each field to match the expected input length (e.g. Postal Code narrow, Address wide).\n- **Independent validation** \u2014 each field validates and shows errors on its own, without affecting the other.\n\n---\n\n## Anatomy\n\nThe group has a single rounded outer border. Inside, a vertical divider separates the two fields. Each cell contains a small label on top and the input value below. On focus, the outer border changes color to indicate the active state. On error, only the offending field changes background and label color; the error message appears below that specific cell.\n\n---\n\n## Common Field Pairings\n\n| Left Field      | Right Field      | Suggested Split |\n|-----------------|------------------|-----------------|\n| First Name      | Last Name        | 50 / 50         |\n| Phone           | Email            | 40 / 60         |\n| Check-in Date   | Check-out Date   | 50 / 50         |\n| Address         | Apartment/Suite  | 70 / 30         |\n| City            | State            | 65 / 35         |\n| Postal Code     | Country          | 30 / 70         |\n| Card Number     | Cardholder Name  | 50 / 50         |\n| Expiry Date     | CVV              | 60 / 40         |\n\n---\n\n## When to Use\n\nUse when fields share a clear data relationship and you want to reduce perceived form density. Avoid when fields are unrelated, when one requires a complex picker that disrupts the layout, or when the form is single-column on mobile.\n\n---\n\n## Responsive Behavior\n\nOn narrow viewports (mobile), jointed fields should stack vertically, reverting to individual full-width fields \u2014 each with its own border and label \u2014 so usability is not compromised.\n\n---\n\n## Accessibility Notes\n\n- Every input must have a programmatically associated label.\n- The focus ring should be visible on the group container when any child field is active.\n- Error messages must be linked to their input via aria-describedby.\n- Tab order must follow left-to-right, top-to-bottom reading sequence.\n- Never rely on color alone to communicate an error state.\n\n---\n\n## Summary\n\nJointed Fields leverages the Gestalt principle of proximity \u2014 elements with no gap between them are perceived as a single object. By removing margin between related fields and adding a shared border, users read two inputs as one unit, significantly reducing the cognitive weight of dense forms.\n";
}
