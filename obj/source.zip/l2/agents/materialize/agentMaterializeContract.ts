/// <mls fileReference="_102027_/l2/agents/materialize/agentMaterializeContract.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>

import { IAgentAsync, IAgentMeta } from '/_102027_/l2/aiAgentBase.js';
import { getMaterializeOrchestrator } from '/_102027_/l2/agents/materialize/materializeOrchestrator.js';  
 
export function createAgent(): IAgentAsync { 
  return {
    agentName: "agentMaterializeContract",
    agentProject: 102027,
    agentFolder: "agents/materialize",
    agentDescription: "new agent",
    visibility: "public",
    beforePromptImplicit,
    beforePromptStep,
    afterPromptStep
  };
}

async function beforePromptImplicit(
  agent: IAgentMeta,
  context: mls.msg.ExecutionContext,
  userPrompt: string,
): Promise<mls.msg.AgentIntent[]> {


  const paths: string[] = [];

  const inputs: mls.msg.IAMessageInputType[] = [{ type: "system", content: system1 }];

  const addMessageAI: mls.msg.AgentIntentAddMessageAI = {
    type: "add-message-ai",
    request: {
      action: 'addMessageAI',
      agentName: agent.agentName,
      inputAI: inputs,
      taskTitle: '',
      threadId: context.message.threadId,
      userMessage: context.message.content,
      longTermMemory: {},
    },
    executionMode: {
      type: 'parallel',
      args: paths
    }
  };
  return [addMessageAI];

}

async function beforePromptStep(
  agent: IAgentMeta,
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
  args?: string
): Promise<mls.msg.AgentIntent[]> {
  if (!args) throw new Error(`[beforePromptStep] args invalid`)

  if (args.startsWith("@@")) {
  
    const continueParallel1: mls.msg.AgentIntentPromptReady = {
      type: "prompt_ready",
      args,
      messageId: context.message.orderAt,
      threadId: context.message.threadId,
      taskId: context.task?.PK || '',
      hookSequential,
      parentStepId: parentStep.stepId,
      humanPrompt: '',
      systemPrompt: system1
    }
    return [continueParallel1];

  }

  console.info('--------agentMaterializeContract--------')
  const info = JSON.parse(args) as { path: string, item: mls.defs.MaterializeEntry, project?:number };
  info.project = mls.actualProject || 0;
  const orch = getMaterializeOrchestrator(info.path);
  const user = await orch.getVar(info.path, info.item.specVar);
  const skill = await orch.getSkill(info.item.skillPath);
  const prompt = `##Skill\n${skill}\n\n##User data\n${user}\n\n##User info\n${JSON.stringify(info)}`;
  const continueParallel: mls.msg.AgentIntentPromptReady = {
    type: "prompt_ready",
    args,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || '',
    hookSequential,
    parentStepId: parentStep.stepId,
    humanPrompt: prompt
  }
  return [continueParallel];

}

async function afterPromptStep(
  agent: IAgentMeta,
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
): Promise<mls.msg.AgentIntent[]> {
  if (!agent || !context || !step) throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
  const payload = (step.interaction?.payload?.[0]);
  if (payload?.type !== 'flexible' || !payload.result) throw new Error(`[afterPromptStep] invalid payload: ${payload}`)

  let status: mls.msg.AIStepStatus = 'completed';
  let intents: mls.msg.AgentIntent[] = [];

  const output = payload.result;
  intents = await processOutput(context, output, agent);

  
  

  const updateStatus: mls.msg.AgentIntentUpdateStatus = {
    type: 'update-status',
    hookSequential,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || '',
    parentStepId: parentStep.stepId,
    stepId: step.stepId,
    status
  };

  return [...intents, updateStatus];

}

async function processOutput(context: mls.msg.ExecutionContext, output: any, agent: IAgentMeta): Promise<mls.msg.AgentIntent[]> {

  const orch = getMaterializeOrchestrator(output.path); 
  await orch.createStorFile(output.outputPath, output.srcFile);

  const group = await orch.processGroup(output.id);
  const newSteps: mls.msg.AgentIntentAddStep[] = [];

  Object.keys(group).forEach((g) => {

    const info = group[g];

    const newStep: mls.msg.AgentIntentAddStep = {
      type: "add-step",
      messageId: context.message.orderAt,
      threadId: context.message.threadId,
      taskId: context.task?.PK || '',
      parentStepId: 1,
      stepTitle: g+" file {{completed}} of {{total}}, errors: {{failed}}",
      step:
      {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'waiting_human_input',
        nextSteps: [],
        agentName: g,
        prompt: '@@ ' + JSON.stringify(info),
        rags: [],
      },
      executionMode: { type: 'parallel', args: info.map((i: any) => JSON.stringify({ path: output.path, item: i })) }
    };

    newSteps.push(newStep)

  });
  
  return newSteps;
}


const system1 = `
<!-- modelType: code -->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You must return the result following the skill's steps. The return value should be sent in the srcFile attribute.

## Output format
You must return the object strictly as JSON
[[OutputSection]]

`

//#region OutputSection
export type Output =
  {
    type: "flexible";
    result: OutputResult; 
  }

export type OutputResult =
  {
    path: string; // same value by "User info";
    id: string; // same value by "User info";
    outputPath: string, // same value by "User info";
    srcFile: string
  }
//#endregion 


